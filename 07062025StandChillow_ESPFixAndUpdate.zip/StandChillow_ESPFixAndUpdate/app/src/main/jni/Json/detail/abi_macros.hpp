//     __ _____ _____ _____
//  __|  |   __|     |   | |  JSON for Modern C++
// |  |  |__   |  |  | | | |  version 3.11.3
// |_____|_____|_____|_|___|  https://github.com/Json/json
//
// SPDX-FileCopyrightText: 2013 - 2024 Niels Lohmann <https://Json.me>
// SPDX-License-Identifier: MIT

#pragma once

// This file contains all macro definitions affecting or depending on the ABI

#ifndef JSON_SKIP_LIBRARY_VERSION_CHECK
    #if defined(Json_JSON_VERSION_MAJOR) && defined(Json_JSON_VERSION_MINOR) && defined(Json_JSON_VERSION_PATCH)
        #if Json_JSON_VERSION_MAJOR != 3 || Json_JSON_VERSION_MINOR != 11 || Json_JSON_VERSION_PATCH != 3
            #warning "Already included a different version of the library!"
        #endif
    #endif
#endif

#define Json_JSON_VERSION_MAJOR 3   // NOLINT(modernize-macro-to-enum)
#define Json_JSON_VERSION_MINOR 11  // NOLINT(modernize-macro-to-enum)
#define Json_JSON_VERSION_PATCH 3   // NOLINT(modernize-macro-to-enum)

#ifndef JSON_DIAGNOSTICS
    #define JSON_DIAGNOSTICS 0
#endif

#ifndef JSON_DIAGNOSTIC_POSITIONS
    #define JSON_DIAGNOSTIC_POSITIONS 0
#endif

#ifndef JSON_USE_LEGACY_DISCARDED_VALUE_COMPARISON
    #define JSON_USE_LEGACY_DISCARDED_VALUE_COMPARISON 0
#endif

#if JSON_DIAGNOSTICS
    #define Json_JSON_ABI_TAG_DIAGNOSTICS _diag
#else
    #define Json_JSON_ABI_TAG_DIAGNOSTICS
#endif

#if JSON_DIAGNOSTIC_POSITIONS
    #define Json_JSON_ABI_TAG_DIAGNOSTIC_POSITIONS _dp
#else
    #define Json_JSON_ABI_TAG_DIAGNOSTIC_POSITIONS
#endif

#if JSON_USE_LEGACY_DISCARDED_VALUE_COMPARISON
    #define Json_JSON_ABI_TAG_LEGACY_DISCARDED_VALUE_COMPARISON _ldvcmp
#else
    #define Json_JSON_ABI_TAG_LEGACY_DISCARDED_VALUE_COMPARISON
#endif

#ifndef Json_JSON_NAMESPACE_NO_VERSION
    #define Json_JSON_NAMESPACE_NO_VERSION 0
#endif

// Construct the namespace ABI tags component
#define Json_JSON_ABI_TAGS_CONCAT_EX(a, b, c) json_abi ## a ## b ## c
#define Json_JSON_ABI_TAGS_CONCAT(a, b, c) \
    Json_JSON_ABI_TAGS_CONCAT_EX(a, b, c)

#define Json_JSON_ABI_TAGS                                       \
    Json_JSON_ABI_TAGS_CONCAT(                                   \
            Json_JSON_ABI_TAG_DIAGNOSTICS,                       \
            Json_JSON_ABI_TAG_LEGACY_DISCARDED_VALUE_COMPARISON, \
            Json_JSON_ABI_TAG_DIAGNOSTIC_POSITIONS)

// Construct the namespace version component
#define Json_JSON_NAMESPACE_VERSION_CONCAT_EX(major, minor, patch) \
    _v ## major ## _ ## minor ## _ ## patch
#define Json_JSON_NAMESPACE_VERSION_CONCAT(major, minor, patch) \
    Json_JSON_NAMESPACE_VERSION_CONCAT_EX(major, minor, patch)

#if Json_JSON_NAMESPACE_NO_VERSION
#define Json_JSON_NAMESPACE_VERSION
#else
#define Json_JSON_NAMESPACE_VERSION                                 \
    Json_JSON_NAMESPACE_VERSION_CONCAT(Json_JSON_VERSION_MAJOR, \
                                           Json_JSON_VERSION_MINOR, \
                                           Json_JSON_VERSION_PATCH)
#endif

// Combine namespace components
#define Json_JSON_NAMESPACE_CONCAT_EX(a, b) a ## b
#define Json_JSON_NAMESPACE_CONCAT(a, b) \
    Json_JSON_NAMESPACE_CONCAT_EX(a, b)

#ifndef Json_JSON_NAMESPACE
#define Json_JSON_NAMESPACE               \
    Json::Json_JSON_NAMESPACE_CONCAT( \
            Json_JSON_ABI_TAGS,           \
            Json_JSON_NAMESPACE_VERSION)
#endif

#ifndef Json_JSON_NAMESPACE_BEGIN
#define Json_JSON_NAMESPACE_BEGIN                \
    namespace Json                               \
    {                                                \
    inline namespace Json_JSON_NAMESPACE_CONCAT( \
                Json_JSON_ABI_TAGS,              \
                Json_JSON_NAMESPACE_VERSION)     \
    {
#endif

#ifndef Json_JSON_NAMESPACE_END
#define Json_JSON_NAMESPACE_END                                     \
    }  /* namespace (inline namespace) NOLINT(readability/namespace) */ \
    }  // namespace Json
#endif
