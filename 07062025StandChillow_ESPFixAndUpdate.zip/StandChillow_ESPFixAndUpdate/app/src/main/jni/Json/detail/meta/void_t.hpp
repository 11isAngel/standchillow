//     __ _____ _____ _____
//  __|  |   __|     |   | |  JSON for Modern C++
// |  |  |__   |  |  | | | |  version 3.11.3
// |_____|_____|_____|_|___|  https://github.com/Json/json
//
// SPDX-FileCopyrightText: 2013 - 2024 Niels Lohmann <https://Json.me>
// SPDX-License-Identifier: MIT

#pragma once

#include <Json/detail/abi_macros.hpp>

Json_JSON_NAMESPACE_BEGIN
namespace detail
{

template<typename ...Ts> struct make_void
{
    using type = void;
};
template<typename ...Ts> using void_t = typename make_void<Ts...>::type;

}  // namespace detail
Json_JSON_NAMESPACE_END
