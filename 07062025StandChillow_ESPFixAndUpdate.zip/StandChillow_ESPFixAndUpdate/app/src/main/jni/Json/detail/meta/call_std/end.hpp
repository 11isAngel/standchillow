//     __ _____ _____ _____
//  __|  |   __|     |   | |  JSON for Modern C++
// |  |  |__   |  |  | | | |  version 3.11.3
// |_____|_____|_____|_|___|  https://github.com/Json/json
//
// SPDX-FileCopyrightText: 2013 - 2024 Niels Lohmann <https://Json.me>
// SPDX-License-Identifier: MIT

#pragma once

#include <Json/detail/macro_scope.hpp>

Json_JSON_NAMESPACE_BEGIN

Json_CAN_CALL_STD_FUNC_IMPL(end);

Json_JSON_NAMESPACE_END
