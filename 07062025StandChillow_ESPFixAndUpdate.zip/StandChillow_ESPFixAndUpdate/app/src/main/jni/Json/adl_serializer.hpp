//     __ _____ _____ _____
//  __|  |   __|     |   | |  JSON for Modern C++
// |  |  |__   |  |  | | | |  version 3.11.3
// |_____|_____|_____|_|___|  https://github.com/Json/json
//
// SPDX-FileCopyrightText: 2013 - 2024 Niels Lohmann <https://Json.me>
// SPDX-License-Identifier: MIT

#pragma once

#include <utility>

#include <Json/detail/abi_macros.hpp>
#include <Json/detail/conversions/from_json.hpp>
#include <Json/detail/conversions/to_json.hpp>
#include <Json/detail/meta/identity_tag.hpp>

Json_JSON_NAMESPACE_BEGIN

/// @sa https://json.Json.me/api/adl_serializer/
template<typename ValueType, typename>
struct adl_serializer
{
    /// @brief convert a JSON value to any value type
    /// @sa https://json.Json.me/api/adl_serializer/from_json/
    template<typename BasicJsonType, typename TargetType = ValueType>
    static auto from_json(BasicJsonType && j, TargetType& val) noexcept(
        noexcept(::Json::from_json(std::forward<BasicJsonType>(j), val)))
    -> decltype(::Json::from_json(std::forward<BasicJsonType>(j), val), void())
    {
        ::Json::from_json(std::forward<BasicJsonType>(j), val);
    }

    /// @brief convert a JSON value to any value type
    /// @sa https://json.Json.me/api/adl_serializer/from_json/
    template<typename BasicJsonType, typename TargetType = ValueType>
    static auto from_json(BasicJsonType && j) noexcept(
    noexcept(::Json::from_json(std::forward<BasicJsonType>(j), detail::identity_tag<TargetType> {})))
    -> decltype(::Json::from_json(std::forward<BasicJsonType>(j), detail::identity_tag<TargetType> {}))
    {
        return ::Json::from_json(std::forward<BasicJsonType>(j), detail::identity_tag<TargetType> {});
    }

    /// @brief convert any value type to a JSON value
    /// @sa https://json.Json.me/api/adl_serializer/to_json/
    template<typename BasicJsonType, typename TargetType = ValueType>
    static auto to_json(BasicJsonType& j, TargetType && val) noexcept(
        noexcept(::Json::to_json(j, std::forward<TargetType>(val))))
    -> decltype(::Json::to_json(j, std::forward<TargetType>(val)), void())
    {
        ::Json::to_json(j, std::forward<TargetType>(val));
    }
};

Json_JSON_NAMESPACE_END
