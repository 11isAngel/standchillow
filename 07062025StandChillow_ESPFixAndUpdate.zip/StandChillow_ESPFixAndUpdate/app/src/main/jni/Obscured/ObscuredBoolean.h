__int64 CreateObscuredBoolTrue(void)
{
    return 0xAB000000AALL;
}

__int64 CreateObscuredBoolFalse(void)
{
    return 0xA1000000A1LL;
}
__int64 __fastcall SetBoolTrue(__int64 resultBuffer)
{
    *(_BYTE *)resultBuffer = -86;
    *(_DWORD *)(resultBuffer + 4) = 171;
    *(_WORD *)(resultBuffer + 8) = 257;
    *(_BYTE *)(resultBuffer + 10) = 0;
    return resultBuffer;
}
