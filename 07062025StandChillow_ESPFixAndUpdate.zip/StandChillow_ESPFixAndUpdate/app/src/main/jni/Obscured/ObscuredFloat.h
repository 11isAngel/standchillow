__int64 __usercall SetObscuredFloat(float floatValue, __int64 resultBuffer, __int64 dataBuffer)
{
    *(float *)(dataBuffer + 12) = floatValue;
    *(_BYTE *)(dataBuffer + 16) = 0;
    *(_DWORD *)dataBuffer = resultBuffer;
    *(_DWORD *)(dataBuffer + 4) = LODWORD(floatValue) ^ resultBuffer;
    *(_BYTE *)(dataBuffer + 8) = 1;
    return resultBuffer;
}