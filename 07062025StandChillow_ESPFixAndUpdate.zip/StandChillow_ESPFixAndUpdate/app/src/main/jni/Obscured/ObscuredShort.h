unsigned __int64 __fastcall CreateObscuredShort(unsigned __int16 shortValue)
{
    return ((unsigned __int16)(shortValue ^ 0xAA) << 16) | ((unsigned __int64)shortValue << 48) | 0x1000000AALL;
}