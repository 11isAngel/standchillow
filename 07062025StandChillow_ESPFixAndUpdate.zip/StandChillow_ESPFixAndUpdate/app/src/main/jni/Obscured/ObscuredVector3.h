#include <cstdint>
#include <cstring>
#include <unistd.h>
#include <sys/mman.h>

#pragma pack(push, 1)
struct ObscuredVector3_C
{
    int32_t currentCryptoKey;   // offset 0
    int32_t hiddenX;            // offset 4
    int32_t hiddenY;            // offset 8
    int32_t hiddenZ;            // offset 12
    uint8_t inited;             // offset 16
    uint8_t _pad1[3];           // offset 17–19
    float   fakeX;              // offset 20
    float   fakeY;              // offset 24
    float   fakeZ;              // offset 28
    uint8_t fakeActive;         // offset 32
    uint8_t _pad2[3];           // offset 33–35
};
#pragma pack(pop)

inline Vector3 DecryptObscuredVector3(void* addr)
{
    auto* p = reinterpret_cast<ObscuredVector3_C*>(addr);
    if (p->inited == 0) {
        return { 0.0f, 0.0f, 0.0f };
    }
    int32_t key   = p->currentCryptoKey;
    int32_t encX  = p->hiddenX;
    int32_t encY  = p->hiddenY;
    int32_t encZ  = p->hiddenZ;

    int32_t decXb = encX ^ key;
    int32_t decYb = encY ^ key;
    int32_t decZb = encZ ^ key;

    Vector3 out;
    std::memcpy(&out.x, &decXb, sizeof(float));
    std::memcpy(&out.y, &decYb, sizeof(float));
    std::memcpy(&out.z, &decZb, sizeof(float));
    return out;
}
