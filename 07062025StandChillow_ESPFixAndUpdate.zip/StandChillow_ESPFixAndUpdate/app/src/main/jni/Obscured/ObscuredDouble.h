void __usercall CreateObscuredDouble(double doubleValue, __int64 dataBuffer)
{
    *(double *)(dataBuffer + 24) = doubleValue;
    *(_BYTE *)(dataBuffer + 16) = 1;
    *(_QWORD *)dataBuffer = 43690LL;
    *(_QWORD *)(dataBuffer + 8) = *(_QWORD *)&doubleValue ^ 0xAAAALL;
    *(_BYTE *)(dataBuffer + 32) = 0;
}