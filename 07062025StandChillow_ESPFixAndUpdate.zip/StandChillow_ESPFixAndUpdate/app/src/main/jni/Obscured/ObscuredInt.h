struct ObscuredInt {
    uint32_t value;
    uint32_t key;
    bool initialized;
    uint8_t state;
    uint8_t reserved[3];
};

int32_t CreateObscuredInt(int32_t input, ObscuredInt& out) {
    out.value = input;
    out.key = input ^ 0xA0;
    out.initialized = true;
    out.state = 0;
    return input;
}
