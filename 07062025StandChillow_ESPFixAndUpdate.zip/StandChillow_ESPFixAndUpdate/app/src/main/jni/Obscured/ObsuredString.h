__int64 __usercall SetObscuredString(unsigned __int8 *sourceString, unsigned __int8 *destinationBuffer, __int64 dataBuffer)
{
unsigned int sourceSize;
void *sourceData;
__int64 sourceStart;
__int64 result;
__int64 currentData;
_QWORD *currentPointer;
__int64 currentPointerData;
unsigned int dataLength;
__int64 dataOffset;
unsigned __int64 totalLength;
__int64 dataEnd;
unsigned __int64 tempSize;
bool isDataProcessed;
unsigned int bitFlag;
int stringSize;
__int64 finalOffset;
bool isEndOfData;
unsigned __int64 byteOffset;
unsigned __int8 *byteData;
unsigned int index;
unsigned __int64 maxSize;
bool isNewDataProcessed;
unsigned __int8 finalByte;
unsigned __int64 tempSize2;
unsigned __int8 *finalData;
unsigned int newIndex;
unsigned __int64 totalProcessedSize;

memset((void *)dataBuffer, 0, 0x61u);
*(_QWORD *)(dataBuffer + 112) = 0LL;
*(_QWORD *)(dataBuffer + 120) = 0LL;
*(_QWORD *)(dataBuffer + 104) = 0LL;
*(_BYTE *)(dataBuffer + 128) = 0;

if ((unsigned __int8 *)dataBuffer == destinationBuffer)
{
currentData = 0LL;
currentPointerData = 0LL;
result = dataBuffer + 24;
currentPointer = (_QWORD *)(dataBuffer + 32);
}
else
{
sourceSize = *destinationBuffer;
if ((sourceSize & 1) != 0)
sourceData = (void *)*((_QWORD *)destinationBuffer + 2);
else
sourceData = destinationBuffer + 1;
if ((sourceSize & 1) != 0)
sourceStart = *((_QWORD *)destinationBuffer + 1);
else
LODWORD(sourceStart) = sourceSize >> 1;
std::string::assign(dataBuffer, sourceData, sourceStart);
result = dataBuffer + 24;
currentData = *(_QWORD *)(dataBuffer + 24);
currentPointer = (_QWORD *)(dataBuffer + 32);
currentPointerData = *(_QWORD *)(dataBuffer + 32);
}

dataLength = *sourceString;
dataOffset = *((_QWORD *)sourceString + 1);
totalLength = currentPointerData - currentData;
tempSize = dataLength >> 1;

if ((dataLength & 1) != 0)
maxSize = *((_QWORD *)sourceString + 1);
else
maxSize = dataLength >> 1;

isDataProcessed = maxSize >= totalLength;
if (maxSize <= totalLength)
{
stringSize = dataLength & 1;
if (!isDataProcessed)
*currentPointer = currentData + maxSize;
}
else
{
result = std::vector<unsigned char>::__append(result, (int)maxSize - (int)totalLength);
bitFlag = *sourceString;
dataOffset = *((_QWORD *)sourceString + 1);
stringSize = bitFlag & 1;
tempSize = bitFlag >> 1;
}

if (stringSize)
finalOffset = dataOffset;
else
finalOffset = tempSize;

isEndOfData = stringSize == 0;

if (finalOffset)
{
byteOffset = 0LL;
do
{
byteData = (unsigned __int8 *)*((_QWORD *)sourceString + 2);
isNewDataProcessed = !isEndOfData;
index = *destinationBuffer;
if (!isNewDataProcessed)
byteData = sourceString + 1;
tempSize2 = index >> 1;
isNewDataProcessed = (index & 1) == 0;
finalByte = byteData[byteOffset];
if (isNewDataProcessed)
totalProcessedSize = tempSize2;
else
totalProcessedSize = *((_QWORD *)destinationBuffer + 1);
if (isNewDataProcessed)
finalData = destinationBuffer + 1;
else
finalData = (unsigned __int8 *)*((_QWORD *)destinationBuffer + 2);
*(_BYTE *)(*(_QWORD *)(dataBuffer + 24) + byteOffset) = finalData[byteOffset % totalProcessedSize] ^ finalByte;
newIndex = *sourceString;
tempSize2 = *((_QWORD *)sourceString + 1);
++byteOffset;
if ((newIndex & 1) == 0)
tempSize2 = newIndex >> 1;
isEndOfData = (newIndex & 1) == 0;
} while (byteOffset < tempSize2);
}

*(_BYTE *)(dataBuffer + 96) = 1;
return result;
}
