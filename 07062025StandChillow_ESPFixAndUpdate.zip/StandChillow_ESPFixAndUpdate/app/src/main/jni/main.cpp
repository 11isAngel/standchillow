#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <bit>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include <codecvt>
#include <cstdint>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include "Includes/Obfuscate.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "includes/Dobby/dobby.h"
#include "includes/HTools.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#include "ImGui/box_shadow.cpp"
#include <stdio.h>
#include <stdlib.h>
#include <sys/system_properties.h>
#include <android/input.h>

#include "Unity/Vector3.h"
#include "Unity/Quaternion.h"
#include "Unity/Vector2.h"
#include "Unity/Color.h"
#include "Unity/Mono.h"

#include "Obscured/ObscuredVector3.h"

using namespace std;
using namespace ImGui;
using namespace BNM::UNITY_STRUCTS;

#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <string.h>
#include <iostream>
#include <linux/in.h>
#include <sys/endian.h>
#include <libraries/Rainbow.h>
#include "Includes/Chams.h"
#include <Json/json.hpp>
#include <filesystem>
#include <fstream>
#define STB_IMAGE_IMPLEMENTATION
#include "Init/stb_image.h"
#include <IL2CPP.h>
#include <Fonts/esp.h>
#include "Fonts/general.h"
#include "Fonts/weapon.h"
#include <Fonts/iconcpp.h>
#include <Fonts/Icon.h>
#include <Fonts/Font.h>
#include "Fonts/pixel.h"

#include "Icons/eye.h"
#include "Icons/gear.h"
#include "Icons/user.h"

JavaVM* vm_j = nullptr;
jobject object = nullptr;
jobject activity = nullptr;
const char* str;

#include "Init/write.h"
#include "Init/desing.h"
#include "Init/bools.h"
#include "Init/env.h"
#include "Init/config.h"
#include "Init/hooks.h"
#include "Init/esp.h"
#include "Init/style.h"
#include "Init/menu.h"

#include "Init/android15_support.h"
#include "Init/rendering.h"

uintptr_t address;
uintptr_t il2cpp_base;

#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac){
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_MainActivity_initClipboardAccess(JNIEnv* env, jobject thiz, jobject context) {
    if (object != nullptr) {
        env->DeleteGlobalRef(object);
    }
    object = env->NewGlobalRef(context);
}

void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    if (!menu::c_init) {
        Mamix::theme();

        menu::general = io.Fonts->AddFontFromMemoryTTF(&_font, sizeof _font, 24.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
        menu::weapon = io.Fonts->AddFontFromMemoryTTF(&_weapon, sizeof _weapon, 21.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
        menu::pixel = io.Fonts->AddFontFromMemoryTTF(&_pixel, sizeof _pixel, 15.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic());

        ImFontConfig icons_config;
        icons_config.MergeMode = false;
        icons_config.PixelSnapH = true;

        static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
        menu::icons = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 37.0f, &icons_config, icons_ranges);
        menu::iconssmall = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 30.0f, &icons_config, icons_ranges);
    }

    io.ConfigWindowsMoveFromTitleBarOnly = false;
    io.IniFilename = nullptr;

    ImGui_ImplOpenGL3_Init("#version 100");
    ImGui::GetStyle().ScaleAllSizes(3.0f);

    menu::c_init = true;
}

void* CallCrash(void*) {
    sleep(999999999999);
    abort();
    return 0;
}

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    static bool first = true;
    if (first) {
        eglQuerySurface(dpy, surface, EGL_WIDTH, &menu::glWidth);
        eglQuerySurface(dpy, surface, EGL_HEIGHT, &menu::glHeight);
        SetupImgui();
        menu::setup = true;
        first = false;
    }

    if (ImGui::GetCurrentContext() == nullptr) {
        SetupImgui();
        return old_eglSwapBuffers(dpy, surface);
    }

    GLint last_program, last_texture, last_array_buffer;
    glGetIntegerv(GL_CURRENT_PROGRAM, &last_program);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &last_texture);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &last_array_buffer);
    GLint last_viewport[4];
    glGetIntegerv(GL_VIEWPORT, last_viewport);

    if (!glIsProgram(last_program)) {
        SetupImgui();
        return old_eglSwapBuffers(dpy, surface);
    }

    GLboolean blend = glIsEnabled(GL_BLEND);
    GLboolean scissor = glIsEnabled(GL_SCISSOR_TEST);
    GLboolean depth = glIsEnabled(GL_DEPTH_TEST);

    GLint blend_src_rgb, blend_dst_rgb, blend_src_alpha, blend_dst_alpha;
    glGetIntegerv(GL_BLEND_SRC_RGB, &blend_src_rgb);
    glGetIntegerv(GL_BLEND_DST_RGB, &blend_dst_rgb);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &blend_src_alpha);
    glGetIntegerv(GL_BLEND_DST_ALPHA, &blend_dst_alpha);

    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)menu::glWidth, (float)menu::glHeight);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    if (!menu::setup2) {
        setStyle(DARK);
        if (!vm_j) {
            LOGI(OBFUSCATE("Waiting for JNI initialization..."));
            return old_eglSwapBuffers(dpy, surface);
        }
        
        if (!object) {
            LOGI(OBFUSCATE("Waiting for context initialization..."));
            return old_eglSwapBuffers(dpy, surface);
        }
        
        if (isCurrentVersion()) {
            LOGI(OBFUSCATE("Ver. is now"));
        } else {
            LOGI(OBFUSCATE("Ver. is old!"));
            openUrlInBrowser(OBFUSCATE("https://t.me/MamixCheats"));
            showToast(object, OBFUSCATE("Версия устрела, пожалуйста установите новую версию в канале!"), 0);
            CallCrash(nullptr);
        }
        menu::setup2 = true;
    }

    if (!v1) Mamix::drawWater();
    RenderJumpCircle();
    DrawESP();
    RenderOpenButton();
    R3nderKey();
    R3nderMenu();
    RenderTrace();
    if (showm) Mamix::Watermark();
    Rainbow::Update();

    ImGui::Render();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    glUseProgram(last_program);
    glBindTexture(GL_TEXTURE_2D, last_texture);
    glBindBuffer(GL_ARRAY_BUFFER, last_array_buffer);
    glBlendFuncSeparate(blend_src_rgb, blend_dst_rgb, blend_src_alpha, blend_dst_alpha);

    blend ? glEnable(GL_BLEND) : glDisable(GL_BLEND);
    scissor ? glEnable(GL_SCISSOR_TEST) : glDisable(GL_SCISSOR_TEST);
    depth ? glEnable(GL_DEPTH_TEST) : glDisable(GL_DEPTH_TEST);
    glViewport(last_viewport[0], last_viewport[1], last_viewport[2], last_viewport[3]);

    return old_eglSwapBuffers(dpy, surface);
}

int get_android_sdk_version() {
    char sdk_ver_str[PROP_VALUE_MAX];
    __system_property_get("ro.build.version.sdk", sdk_ver_str);
    return atoi(sdk_ver_str);
}

void (*old_bypass)(void *instance);
void bypass(void *instance) {
    if (instance != NULL)
        instance = NULL;

    return old_bypass(instance);
}

HOOK(void, InputA15, void *thiz, void *ex_ab, void *ex_ac, void *ex_ad){
    origInputA15(thiz, ex_ab, ex_ac, ex_ad);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}

std::mutex mtx;
static void (*old_InputMessage)(AInputEvent *, void *, void *);
static void new_InputMessage(AInputEvent *input_event, void *arg1, void *arg2) {
    old_InputMessage(input_event, arg1, arg2);
    mtx.lock();
    ImGui_ImplAndroid_HandleInputEvent(input_event);
    mtx.unlock();
}

static int32_t (*old_consume)(void *thiz, void *, bool, long, uint32_t *, AInputEvent **);
static int32_t new_consume(void *thiz, void *arg1, bool arg2, long arg3, uint32_t *arg4, AInputEvent **input_event) {
    auto result = old_consume(thiz, arg1, arg2, arg3, arg4, input_event);
    if(result != 0 || *input_event == nullptr) return result;
    mtx.lock();
    ImGui_ImplAndroid_HandleInputEvent(*input_event);
    mtx.unlock();
    return result;
}
void LogMethodStatus(const char* methodName, void* methodPtr) {
    if (methodPtr) {
        LOGI("Successfully loaded method: %s", methodName);
    } else {
        LOGI("Failed to load method: %s", methodName);
    }
}

std::mutex Android15Input::input_mutex;

EGLBoolean (*orig_eglMakeCurrent)(EGLDisplay, EGLSurface, EGLSurface, EGLContext);
EGLBoolean hook_eglMakeCurrent(EGLDisplay dpy, EGLSurface draw, EGLSurface read, EGLContext ctx) {
    menu::display = dpy;
    menu::surface = draw;
    return orig_eglMakeCurrent(dpy, draw, read, ctx);
}

void (*old_SurfaceRender)(void* thiz);
void hook_SurfaceRender(void* thiz) {
    static bool first = true;
    if (first) {
        JNIEnv *env = nullptr;
        vm_j->GetEnv((void **) &env, JNI_VERSION_1_6);
        if (env && thiz) {
            ANativeWindow *window = ANativeWindow_fromSurface(env, (jobject) thiz);
            if (window) {
                menu::glWidth = ANativeWindow_getWidth(window);
                menu::glHeight = ANativeWindow_getHeight(window);
                ANativeWindow_release(window);
            }
        }
        SetupImgui();
        menu::setup = true;
        first = false;
    }
    if (ImGui::GetCurrentContext() == nullptr) {
        SetupImgui();
        return old_SurfaceRender(thiz);
    }
    Rendering::GLState state;
    Rendering::SaveGLState(state);
    GLint current_program;
    glGetIntegerv(GL_CURRENT_PROGRAM, &current_program);
    if (!glIsProgram(current_program)) {
        Rendering::RestoreGLState(state);
        return old_SurfaceRender(thiz);
    }
    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float) menu::glWidth, (float) menu::glHeight);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    if (!menu::setup2) {
        setStyle(DARK);
        menu::setup2 = true;
    }
    if (!v1) Mamix::drawWater();
    RenderJumpCircle();
    DrawESP();
    RenderOpenButton();
    R3nderKey();
    R3nderMenu();
    RenderTrace();
    if (showm) Mamix::Watermark();
    Rainbow::Update();
    ImGui::Render();
    glViewport(0, 0, (int) io.DisplaySize.x, (int) io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    Rendering::RestoreGLState(state);
    old_SurfaceRender(thiz);
}

std::mutex input_mutex;

static int32_t (*orig_consume)(void* thiz, void*, bool, long, uint32_t*, AInputEvent**);
static int32_t hook_consume(void* thiz, void* arg1, bool arg2, long arg3, uint32_t* arg4, AInputEvent** input_event) {
    int32_t result = orig_consume(thiz, arg1, arg2, arg3, arg4, input_event);
    if (result != 0 || !input_event || !*input_event) return result;
    input_mutex.lock();
    ImGui_ImplAndroid_HandleInputEvent(*input_event);
    input_mutex.unlock();
    return result;
}


void *init_hooks(void *) {
    do {
        sleep(1);
    } while (!isLibraryLoaded(OBFUSCATE("libil2cpp.so")));

    LOGI("0");
    int sdk_version = get_android_sdk_version();
#if defined(__aarch64__)
    const char* egl_path = "/system/lib64/libEGL.so";
    const char* libinput_path = sdk_version >= 33 ? "/apex/com.android.input/lib64/libinput.so" : "/system/lib64/libinput.so";
    const char* surface_path = "/system/lib64/libGLESv2.so";
#else
    const char* egl_path = "/system/lib/libEGL.so";
    const char* libinput_path = sdk_version >= 33 ? "/apex/com.android.input/lib/libinput.so" : "/system/lib/libinput.so";
    const char* surface_path = "/system/lib/libGLESv2.so";
#endif

    /* auto surface_render = DobbySymbolResolver(surface_path, "_ZN7android6Surface4lockEPNS_11SurfaceInfoEPNS_11Region_constE");
     if (surface_render) {
         eglstatus = false;
         DobbyHook((void*)surface_render, (void*)hook_SurfaceRender, (void**)&old_SurfaceRender);
         LOGI("Using Surface render for ImGui rendering");
     } else {*/
    auto egl = DobbySymbolResolver(egl_path, "eglSwapBuffers");
    if (egl) {
        eglstatus = true;
        DobbyHook((void*)egl, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
        LOGI("Using eglSwapBuffers for ImGui rendering");
    }
    //}

    /*void* eglmake = DobbySymbolResolver(egl_path, "eglMakeCurrent");
    if (eglmake) DobbyHook(eglmake, (void*)hook_eglMakeCurrent, (void**)&orig_eglMakeCurrent);
    */
    LOGI("Android SDK Version: %d", sdk_version);

    if (sdk_version >= 35) {
        if (!Android15Input::init_android15_support(libinput_path)) {
            LOGI("Failed to initialize Android 15 input support, falling back to legacy input handling");
            /* void* libandroid = dlopen("libandroid.so", RTLD_NOW);
             if (libandroid) {
                 void* AInputQueue_getEvent = dlsym(libandroid, "AInputQueue_getEvent");
                 if (AInputQueue_getEvent) {
                     DobbyHook(AInputQueue_getEvent, (void*)myInput, (void**)&origInput);
                     LOGI("Using AInputQueue_getEvent for input handling");
                 }
                 dlclose(libandroid);
             }*/
            void* consume_ptr = DobbySymbolResolver(libinput_path, "_ZN7android13InputConsumer7consumeEv");

            if (consume_ptr) {
                DobbyHook((void *) consume_ptr, (void *) hook_consume,
                          (void **) &orig_consume);
            }
        }
    } else {
        void* sym_input = DobbySymbolResolver(libinput_path,
                                              "_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE");
        if (!sym_input) {
            sym_input = DobbySymbolResolver(libinput_path,
                                            "_ZN7android13InputConsumer7consumeEPNS_26InputEventFactoryInterfaceEblPjPPNS_10InputEventE");
        }
        if (sym_input) {
            DobbyHook(sym_input, (void*)myInput, (void**)&origInput);
        }
    }

    void* consume_ptr = DobbySymbolResolver(libinput_path, "_ZN7android13InputConsumer7consumeEv"); // либо другая сигнатура

    if (consume_ptr) {
        DobbyHook((void*)consume_ptr, (void*)hook_consume, (void**)&orig_consume);
        LOGI("✅ Input hook for Android 15+ installed");
    } else {
        LOGI("❌ Failed to hook InputConsumer::consume");
    }

    mlovinit();
    setShader("_BumpMap");
    LogShaders();
    Wallhack();

    Il2Cpp::il2cpp_string_new = (Il2CppString *(*)(const char *)) DobbySymbolResolver("libil2cpp.so",
                                                                                      OBFUSCATE("il2cpp_string_new"));

    Il2Cpp::il2cpp_string_new_utf16 = (Il2CppString *(*)(const wchar_t *, int32_t)) DobbySymbolResolver("libil2cpp.so",
                                                                                                        OBFUSCATE("il2cpp_string_new"));

#if defined(__aarch64__)
    hexPatches.invisibles = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F0D04")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.infinitydrop = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1850458")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.movebefore = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x110CDD8")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.noscope = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10B6688")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.antig = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xCF5080")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.buyanywht = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFBAAE0")), OBFUSCATE("20 00 80 52 C0 03 5F D6"));
    hexPatches.buyanywhct = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFBA81C")), OBFUSCATE("20 00 80 52 C0 03 5F D6"));
    hexPatches.shophack = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFB474C")), OBFUSCATE("20 00 80 52 C0 03 5F D6"));
    hexPatches.radar = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFA04BC")), OBFUSCATE("20 00 80 52 C0 03 5F D6"));

    hexPatches.ChamsBypass = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F77C8")), OBFUSCATE("C0 03 5F D6"));
    hexPatches.ChamsBypass.Modify();

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x30016a4"))), (void *) Grounded, (void **) &old_Grounded); // фикс
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb2960"))), (void *) FovHack1, (void **) &old_FovHack1);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb2924"))), (void *) FovHack2, (void **) &old_FovHack2);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17f7c54"))), (void *) PlayerControllerUpdate, (void **) &old_PlayerControllerUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x180E53C"))), (void *) PlayerControllerLateUpdate, (void **) &old_PlayerControllerLateUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10C63E4"))), (void *) JoystickOnWalk, (void **) &old_JoystickOnWalk);

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xDEEE58"))), (void *) AttrCtor, (void **) &old_AttrCtor);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x18DF9D0"))), (void*)OnLand, (void**)&old_OnLand);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xC52090"))), (void*)CastBullet, (void**)&old_CastBullet);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1238E20"))), (void*)InfGrenades, (void**)&old_InfGrenades);
    //DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xD9ED18"))), (void*)GameFinished, (void**)&old_GameFinished);
    //DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xDAB110"))), (void*)InitG, (void**)&old_InitG);

    WorldToScreenPoint = (Vector3 (*)(void*, Vector3))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb363c")));
    set_localScale = (void (*)(void *, Vector3)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fbf514")));
    get_transform = (void *(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb7834")));
    set_position = (void (*)(void *, Vector3)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fbee08")));
    get_position = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fbed68")));
    get_forward = (Vector3 (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fbf2e8")));
    get_right = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2FBF1F0")));
    get_camera = (void *(*)()) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb39c0")));
    set_TpsView3 = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17FB3E4")));
    set_clearFlags = (void (*)(void*, int)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb2e18")));
    set_backgroundColor = (void (*)(void*, ImColor)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fb2d44")));
    GetDeltaTime = (float (*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2FB2390")));
    isMine = (bool (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1647488")));
    GetHealth = (int (*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F95AC")));
    IsPlayerDead = (bool (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17FB0DC")));
    DieViaServer = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17FB2A8")));
    Die = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F920C")));
    getAxis = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10C6850")));

    Linecast = (bool (*)(Vector3, Vector3, int)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2FFF344")));

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xc66f0c"))), (void *) GunControllerUpdate, (void **)&old_GunControllerUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x123E500"))), (void *) MagazineCapacity, (void **)&old_MagazineCapacity);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x2fafb18"))), (void *) New_Screen$$SetResolution, (void **) &Old_Screen$$SetResolution);
#else
    hexPatches.invisibles  = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F0D04")), OBFUSCATE("1E FF 2F E1"));
    hexPatches.infinitydrop = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1850458")), OBFUSCATE("1E FF 2F E1"));
    hexPatches.movebefore   = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x110CDD8")), OBFUSCATE("1E FF 2F E1"));
    hexPatches.noscope      = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10B6688")), OBFUSCATE("1E FF 2F E1"));
    hexPatches.antig        = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xCF5080")), OBFUSCATE("1E FF 2F E1"));

    hexPatches.buyanywht    = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFBAAE0")), OBFUSCATE("01 00 A0 E3 1E FF 2F E1"));
    hexPatches.buyanywhct   = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFBA81C")), OBFUSCATE("01 00 A0 E3 1E FF 2F E1"));
    hexPatches.shophack     = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFB474C")), OBFUSCATE("01 00 A0 E3 1E FF 2F E1"));
    hexPatches.radar        = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xFA04BC")), OBFUSCATE("01 00 A0 E3 1E FF 2F E1"));

    hexPatches.ChamsBypass  = MemoryPatch::createWithHex(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17F77C8")), OBFUSCATE("1E FF 2F E1"));
    hexPatches.ChamsBypass.Modify();

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x35373C4"))), (void *) Grounded, (void **) &old_Grounded); // фикс
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CA60C"))), (void *) FovHack1, (void **) &old_FovHack1);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CA5C0"))), (void *) FovHack2, (void **) &old_FovHack2);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B31A4"))), (void *) PlayerControllerUpdate, (void **) &old_PlayerControllerUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16D19A8"))), (void *) PlayerControllerLateUpdate, (void **) &old_PlayerControllerLateUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xD95098"))), (void *) JoystickOnWalk, (void **) &old_JoystickOnWalk);

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x9DA2A4"))), (void *) AttrCtor, (void **) &old_AttrCtor);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x17E9964"))), (void*)OnLand, (void**)&old_OnLand);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7BCAD4"))), (void*)CastBullet, (void**)&old_CastBullet);
    DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xF696DC"))), (void*)InfGrenades, (void**)&old_InfGrenades);
    //DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xD9ED18"))), (void*)GameFinished, (void**)&old_GameFinished);
    //DobbyHook((void*)getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xDAB110"))), (void*)InitG, (void**)&old_InitG);

    WorldToScreenPoint = (Vector3 (*)(void*, Vector3))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CB6C8")));
    set_localScale = (void (*)(void *, Vector3)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34DAC10")));
    get_transform = (void *(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34D0918")));
    set_position = (void (*)(void *, Vector3)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34D9FAC")));
    get_position = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34D9EDC")));
    get_forward = (Vector3 (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34DA8DC")));
    get_right = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34DA6B4")));
    get_camera = (void *(*)()) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CBEE8")));
    set_TpsView3 = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B7D98")));
    set_clearFlags = (void (*)(void*, int)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CABCC")));
    set_backgroundColor = (void (*)(void*, ImColor)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34CAAC8")));
    GetDeltaTime = (float (*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34C9CF0")));
    isMine = (bool (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1486BE8")));
    GetHealth = (int (*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B52E0")));
    IsPlayerDead = (bool (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B795C")));
    DieViaServer = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B7BAC")));
    Die = (void (*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x16B4E20")));
    getAxis = (Vector3(*)(void *)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xD95574")));

    Linecast = (bool (*)(Vector3, Vector3, int)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x3534764")));

    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7D65B8"))), (void *) GunControllerUpdate, (void **)&old_GunControllerUpdate);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xF6FC0C"))), (void *) MagazineCapacity, (void **)&old_MagazineCapacity);
    DobbyHook((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x34C6420"))), (void *) New_Screen$$SetResolution, (void **) &Old_Screen$$SetResolution);
#endif
    pthread_exit(nullptr);
    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t hacks;
    pthread_create(&hacks, NULL, init_hooks, NULL);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void * reserved)
{
    JNIEnv *env;
    vm_j = vm;

    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}
