#include <stdio.h>
#include <cassert>
#include <codecvt>
#include <cstdint>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <elf.h>
#include <dlfcn.h>
#include <sys/system_properties.h>
#include <android/log.h>
#include <random>
#include <ctime>

// Реализация класса Random для ObscuredFloat
class Random {
private:
    static std::mt19937 generator;

public:
    static int Range(int min, int max) {
        std::uniform_int_distribution<int> distribution(min, max);
        return distribution(generator);
    }

    static float Range(float min, float max) {
        std::uniform_real_distribution<float> distribution(min, max);
        return distribution(generator);
    }
};

// Инициализация генератора случайных чисел
std::mt19937 Random::generator(static_cast<unsigned>(time(nullptr)));

struct Il2CppString {
    void *klass;
    void *monitor;
    int32_t length;
    uint16_t start_char;

    const char *CString();

    const wchar_t *WCString();

    static Il2CppString *CreateMonoString(const char *s);
    static Il2CppString *CreateMonoString(const wchar_t *s, int len);

    int getLength() {
        return length;
    }
};
typedef Il2CppString MonoString;

namespace Il2Cpp {
    const void *(*il2cpp_assembly_get_image)(const void *assembly) = NULL;
    void **(*il2cpp_domain_get_assemblies)(const void *domain, size_t *size) = NULL;
    void *(*il2cpp_domain_get)() = NULL;
    const char *(*il2cpp_image_get_name)(void *image) = NULL;
    void *(*il2cpp_class_from_name)(const void *image, const char *namespaze, const char *name) = NULL;
    void *(*il2cpp_class_get_method_from_name)(void *klass, const char *name, int argsCount) = NULL;
    Il2CppString *(*il2cpp_string_new)(const char *str) = NULL;
    Il2CppString *(*il2cpp_string_new_utf16)(const wchar_t *str, int32_t length) = NULL;
}

void Il2CppAttach(const char *name = "libil2cpp.so") {
    void *handle = dlopen(name, 0);
    while (!handle) {
        handle = dlopen(name, 0);
        sleep(1);
    }

    Il2Cpp::il2cpp_assembly_get_image = (const void *(*)(const void *)) dlsym(handle, "il2cpp_assembly_get_image");
    Il2Cpp::il2cpp_domain_get = (void *(*)()) dlsym(handle, "il2cpp_domain_get");
    Il2Cpp::il2cpp_domain_get_assemblies = (void **(*)(const void* , size_t*)) dlsym(handle, "il2cpp_domain_get_assemblies");
    Il2Cpp::il2cpp_image_get_name = (const char *(*)(void *)) dlsym(handle, "il2cpp_image_get_name");
    Il2Cpp::il2cpp_class_from_name = (void* (*)(const void*, const char*, const char *)) dlsym(handle, "il2cpp_class_from_name");
    Il2Cpp::il2cpp_class_get_method_from_name = (void* (*)(void *, const char*, int)) dlsym(handle, "il2cpp_class_get_method_from_name");
    Il2Cpp::il2cpp_string_new = (Il2CppString *(*)(const char *)) dlsym(handle, "il2cpp_string_new");
    Il2Cpp::il2cpp_string_new_utf16 = (Il2CppString *(*)(const wchar_t *, int32_t)) dlsym(handle, "il2cpp_string_new");

    dlclose(handle);
}

void *Il2CppGetImageByName(const char *image) {
    size_t size;
    void **assemblies = Il2Cpp::il2cpp_domain_get_assemblies(Il2Cpp::il2cpp_domain_get(), &size);
    for(int i = 0; i < size; ++i) {
        void *img = (void *)Il2Cpp::il2cpp_assembly_get_image(assemblies[i]);

        const char *img_name = Il2Cpp::il2cpp_image_get_name(img);

        if(strcmp(img_name, image) == 0) {
            return img;
        }
    }
    return 0;
}

void *Il2CppGetClassType(const char *image, const char *namespaze, const char *clazz) {
    static std::map<std::string, void *> cache;

    std::string s = image;
    s += namespaze;
    s += clazz;

    if (cache.count(s) > 0)
        return cache[s];

    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return 0;
    }

    void *klass = Il2Cpp::il2cpp_class_from_name(img, namespaze, clazz);
    if(!klass) {
        return 0;
    }

    cache[s] = klass;
    return klass;
}

void *Il2CppGetMethodOffset(const char *image, const char *namespaze, const char *clazz, const char *name, int argsCount) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return 0;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return 0;
    }

    void **method = (void**)Il2Cpp::il2cpp_class_get_method_from_name(klass, name, argsCount);
    if(!method) {
        return 0;
    }
    return *method;
}

template<typename T> struct Il2CppArray {
    void *klass;
    void *monitor;
    void *bounds;
    int max_length;
    T m_Items[1];

    int getLength() {
        return max_length;
    }

    T *getPointer() {
        return (T *)m_Items;
    }

    T &operator[](int i) {
        return m_Items[i];
    }

    T &operator[](int i) const {
        return m_Items[i];
    }
};

template<typename T>
using MonoArray = Il2CppArray<T>;

typedef unsigned short UTF16;
typedef wchar_t UTF32;
typedef char UTF8;

int is_surrogate(UTF16 uc) {
    return (uc - 0xd800u) < 2048u;
}

int is_high_surrogate(UTF16 uc) {
    return (uc & 0xfffffc00) == 0xd800;
}

int is_low_surrogate(UTF16 uc) {
    return (uc & 0xfffffc00) == 0xdc00;
}

UTF32 surrogate_to_utf32(UTF16 high, UTF16 low) {
    return (high << 10) + low - 0x35fdc00;
}

const char* utf16_to_utf8(const UTF16* source, size_t len) {
    std::u16string s(source, source + len);
    std::wstring_convert<std::codecvt_utf8_utf16<char16_t>, char16_t> convert;
    return convert.to_bytes(s).c_str();
}

const wchar_t* utf16_to_utf32(const UTF16* source, size_t len) {
    auto output = new UTF32[len + 1];

    for (int i = 0; i < len; i++) {
        const UTF16 uc = source[i];
        if (!is_surrogate(uc)) {
            output[i] = uc;
        }
        else {
            if (is_high_surrogate(uc) && is_low_surrogate(source[i]))
                output[i] = surrogate_to_utf32(uc, source[i]);
            else
                output[i] = L'?';
        }
    }

    output[len] = L'\0';
    return output;
}

const char* Il2CppString::CString() {
    return utf16_to_utf8(&this->start_char, this->length);
}

const wchar_t* Il2CppString::WCString() {
    return utf16_to_utf32(&this->start_char, this->length);
}

Il2CppString *Il2CppString::CreateMonoString(const char *s) {
    return Il2Cpp::il2cpp_string_new(s);
}

Il2CppString *Il2CppString::CreateMonoString(const wchar_t *s, int len) {
    return Il2Cpp::il2cpp_string_new_utf16(s, len);
}

template<typename T> struct Il2CppList {
    void *klass;
    void *unk1;
    Il2CppArray<T> *items;
    int size;
    int version;

    T *getItems() {
        return items->getPointer();
    }

    int getSize() {
        return size;
    }

    int getVersion() {
        return version;
    }

    T &operator[](int i) {
        return items->m_Items[i];
    }

    T &operator[](int i) const {
        return items->m_Items[i];
    }
};

template<typename T>
using MonoList = Il2CppList<T>;

template<typename K, typename V> struct Il2CppDictionary {
    void *klass;
    void *unk1;
    Il2CppArray<int **> *table;
    Il2CppArray<void **> *linkSlots;
    Il2CppArray<K> *keys;
    Il2CppArray<V> *values;
    int touchedSlots;
    int emptySlot;
    int size;

    K *getKeys() {
        return keys->getPointer();
    }

    V *getValues() {
        return values->getPointer();
    }

    int getNumKeys() {
        return keys->getLength();
    }

    int getNumValues() {
        return values->getLength();
    }

    int getSize() {
        return size;
    }
};

template<typename K, typename V>
using Dictionary = Il2CppDictionary<K, V>;

bool IsPtrValid(void *addr) {
    static int fd = -1;
    if (fd == -1) {
        fd = open("/dev/random", O_WRONLY);
    }
    return write(fd, addr, 4) >= 0;
}
