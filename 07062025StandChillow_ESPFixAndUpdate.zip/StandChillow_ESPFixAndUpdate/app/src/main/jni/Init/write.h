struct SafeBool {
    int key;
    int enc_value;

    bool get() {
        return (enc_value ^ key) == 1;
    }
};

void WriteSafeBool(uintptr_t ptr, int value) {
    auto curVal = *reinterpret_cast<SafeBool*>(ptr);
    SafeBool newVal;
    newVal.key = curVal.key;
    newVal.enc_value = value ^ curVal.key;
    memcpy(reinterpret_cast<void*>(ptr), &newVal, sizeof(SafeBool));
}

struct SafeInt {
    int key;
    int enc_value;

    int get() {
        return enc_value ^ key;
    }
};

void WriteSafeInt(uintptr_t ptr, int value) {
    auto curVal = *reinterpret_cast<SafeInt*>(ptr);
    SafeInt newVal;
    newVal.key = curVal.key;
    newVal.enc_value = value ^ curVal.key;
    memcpy(reinterpret_cast<void*>(ptr), &newVal, sizeof(SafeInt));
}

struct SafeFloat {
    int key;
    int enc_value;

    union fi {
        float f;
        int i;
    };

    float get() {
        fi v;
        v.i = (enc_value ^ key);
        return v.f;
    }
};

void WriteSafeFloat(uintptr_t ptr, float value) {
    auto curVal = *reinterpret_cast<SafeFloat*>(ptr);
    SafeFloat::fi eVal;
    eVal.f = value;
    SafeFloat newVal;
    newVal.key = curVal.key;
    newVal.enc_value = eVal.i ^ curVal.key;
    memcpy(reinterpret_cast<void*>(ptr), &newVal, sizeof(SafeFloat));
}

struct SafeShort {
    short key;
    short enc_value;

    short get() {
        return enc_value ^ key;
    }
};

void WriteSafeShort(uintptr_t ptr, short value) {
    auto curVal = *reinterpret_cast<SafeShort*>(ptr);
    SafeShort newVal;
    newVal.key = curVal.key;
    newVal.enc_value = value ^ curVal.key;
    memcpy(reinterpret_cast<void*>(ptr), &newVal, sizeof(SafeShort));
}

union FloatInt {
    float f;
    uint32_t i;
};

struct safe_float {
    float key;
    float enc_value;

    float get() {
        FloatInt a, b, c;
        a.f = key;
        b.f = enc_value;
        c.i = b.i ^ a.i;
        return c.f;
    }
};

void write_float(uintptr_t ptr, float value) {
    auto curVal = *reinterpret_cast<safe_float*>(ptr);
    safe_float newVal;
    newVal.key = curVal.key;
    FloatInt a, b, c;
    a.f = value;
    b.f = curVal.key;
    c.i = a.i ^ b.i;
    newVal.enc_value = c.f;
    memcpy(reinterpret_cast<void*>(ptr), &newVal, sizeof(safe_float));
}

class ObscuredFloat {
private:
    // 0x10 - Ключ шифрования
    std::vector<uint8_t> hiddenValue; // 0x18 - Зашифрованное значение (байтовый массив)
    std::vector<char> cryptoKey;  // 0x20 - Ключ шифрования (char[])
    std::vector<char> hiddenChars;// 0x28 - Зашифрованные символы (char[])
    bool inited;                  // 0x30 - Флаг инициализации
    float fakeValue;               // 0x38 - Фейковое значение для античита
    bool fakeValueActive;          // 0x40 - Флаг активности фейкового значения

    static std::vector<uint8_t> Encrypt(float value, float key) {
        uint32_t intValue;
        std::memcpy(&intValue, &value, sizeof(value));
        intValue ^= *reinterpret_cast<uint32_t*>(&key);

        std::vector<uint8_t> encrypted(sizeof(intValue));
        std::memcpy(encrypted.data(), &intValue, sizeof(intValue));
        return encrypted;
    }

    static float Decrypt(const std::vector<uint8_t>& encrypted, float key) {
        uint32_t intValue;
        std::memcpy(&intValue, encrypted.data(), sizeof(intValue));
        intValue ^= *reinterpret_cast<const uint32_t*>(&key);

        float result;
        std::memcpy(&result, &intValue, sizeof(result));
        return result;
    }

public:
    ObscuredFloat(float value = 0.0f) {
        currentCryptoKey = GenerateKey();
        SetNewValue(value);
        cryptoKey.resize(8, '0');  // Пример начальной инициализации ключа
        hiddenChars.resize(8, '0'); // Пример инициализации скрытых символов
        inited = true;
    }

    void SetNewValue(float value) {
        hiddenValue = Encrypt(value, currentCryptoKey);
        fakeValue = value;
        fakeValueActive = true;
    }

    float GetValue() const {
        return Decrypt(hiddenValue, currentCryptoKey);
    }

    void SetValue(float value) {
        SetNewValue(value);
    }

    static float GenerateKey() {
        return 1234.5678f; // Можно заменить на более сложное рандомное число
    }

    // Перегрузка операторов
    operator float() const { return GetValue(); }

    ObscuredFloat& operator=(float value) {
        SetValue(value);
        return *this;
    }

    bool operator==(const ObscuredFloat& other) const {
        return GetValue() == other.GetValue();
    }

    bool operator!=(const ObscuredFloat& other) const {
        return !(*this == other);
    }

    float currentCryptoKey;
};