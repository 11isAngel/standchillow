namespace menu {
    int glWidth, glHeight = 0;
    int page = 0;
    bool c_init;
    ImFont *general;
    ImFont *weapon;
    ImFont *icons;
    ImFont *iconssmall;
    ImFont *pixel;
    inline EGLDisplay display = EGL_NO_DISPLAY;
    inline EGLSurface surface = EGL_NO_SURFACE;
    bool setup;
    bool setup2;
    bool setup3;
}

namespace esp {
    namespace player {
        bool enable;
        bool box;
        bool skeleton;
        bool chinahat;
        bool nickname;
        bool distance;
        bool money;
        bool weapon;
        bool health;
        bool line;
        bool circle;
        namespace settings {
            bool boxRGB;
            bool boxCorner;
            float cornerRadius = 1;
            bool lineRGB;
            bool lineglow;
            bool boxGradientRGB;
            bool boxoutline = true;
            bool lineoutline = true;
            bool distanceoutline = true;
            bool boxgradient = true;
            bool boxglow;
            bool nicknameoutline = true;
            bool moneyoutline = true;;
            bool weaponoutline = true;
            bool healthoutline = true;
            bool skeletonoutline;
            bool healthglow;
            bool healthgradient;
            bool boxfilled;

        }
    }
}

namespace colors {
    namespace esp {
        namespace player {
            ImVec4 lineColor = {1.f,1.f,1.f,1.f};
            ImVec4 skeletonColor = {1.f,1.f,1.f,1.f};
            ImVec4 healthColor = {0.0f, 1.0f, 0.0f, 1.0f};
            ImVec4 healthGradientStartColor = {0.0f, 1.0f, 0.0f, 1.0f};
            ImVec4 healthGradientEndColor = {1.0f, 0.0f, 0.0f, 1.0f};
            ImVec4 circleColor = {1.f,1.f,1.f,1.f};
            float chinahatColor[] = {0,0,0};
            float boxColor[] = {1,1,1};

        }
    }
}

float fillAlpha = 0.47f;
ImVec4 fillColorVec = ImVec4(1.0f, 1.0f, 1.0f, fillAlpha);
std::string key;
bool isValid;

std::string ver = OBFUSCATE("1.6.1");
std::string uriver = OBFUSCATE("https://fiksam.pythonanywhere.com/ver.txt");

bool open4 = true;
bool open5;
int health = 1;
bool hideid = true;
bool respawnhack;

bool hidename = true;
float windowWidth = 855.0f;
float windowHeight = 630.0f;
float speedspam = 8.0f;
bool silentaim,drawfov;
bool nicknamespoof;\
bool damagehack;
bool norecoil;
bool esppreview;
bool airJump = false;
bool v1 = true; //1
int currentgloves = 3039;
static int grenade_type = 0;
bool nuke, nuke_me, nuke_enemy, nuke_team;
const char* grenades[] = {
        OBFUSCATE("HE"), OBFUSCATE("Smoke"), OBFUSCATE("Flash")
};
bool unityChams = true;
float unityChamsColor[4] = {1,1,1,1};
float materialGlossiness, materialMetallic = 255;
bool hitmessage;
bool removeTexture;
bool JumpCircle;
bool pulsejumpc;
bool glowjumpc = true;
bool pulsecolorc;
bool wallshot;
float radiusc = 0.2f;
float thiknessc = 2.0f;
float silentfovsize = 50.0f;
bool lineglow;
const char* configNames[] = {
        "config_1", "config_2", "config_3", "config_4", "config_5", "config_6", "config_7", "config_8", "config_9", "config_10",
        "config_11", "config_12", "config_13", "config_14", "config_15", "config_16", "config_17", "config_18", "config_19", "config_20",
        "config_21", "config_22", "config_23", "config_24", "config_25"
};

int selectedConfigIndex = 0;

float bunnyvalue = 5.0f;
bool invsi, movebef, infdrop;
float speedvalue = 5.0f;
bool speedhack;
bool fovFeature;
bool radarhack;
bool antigrenade;
ImVec4 watermark_accent = ImVec4(0.0f, 0.5f, 1.0f, 1.0f);
ImVec4 watertext_accent = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
bool watermarkRainbow;
float fovValue = 0;
bool showm = true;
bool test = true;

int pup;
bool bunnyhop;
bool noclip;
bool telekill, masskill;
bool traceEnable;
bool traceRainbow;
float traceColor[4]={1,1,1,1};
bool traceTriple;
bool traceLine = true;
bool enemyscale;
bool RCS;
bool infammo;
bool firerate;
bool visible;
bool ArmPos;
float xx, yy, zz;
float espstroke = 2;
int scalex = 15, scaley = 15, scalez = 15;
float esphptextsize = 0;
bool circleOutlines = true;
bool circleRGBs;
float esphpsize = 3;
bool ESP;
float hatalpha = 0.200f;
float hatradius = 0.25f;
float hatsegments = 60.f;
bool slaim = false;
bool circleRGB;
bool circleOutline;
bool v2;
bool autojump;
bool silentfov;
bool fastdefuse;
bool ifvisibleaim = false;
bool jumpRGB;
bool dontret;
ImVec4 jumpcclr = ImVec4(255,255,255,255);
ImVec4 silentaimclr = ImVec4(255,255,255,255);
ImVec4 aimclr = ImVec4(255,0,0,255);
bool eglstatus;

//colorsky
bool skyEnable;
bool skyRainbow;
ImVec4 skyColor = ImVec4(255,255,255,255);
bool antiwinct;
bool antigodmode;
bool AutoWinCT;
bool AutoWinT;

bool snowflakes = true;

bool SpamChat = false;
bool triggerbot;
bool drawfovtrigger;

bool linep;
bool buttonp = true;

bool circleRGBt;
bool circleOutlinet;
ImVec4 aimclrt = ImVec4(0.0f, 0.0f, 0.545f, 1.0f);
float triggerfov = 20.0f;
bool stopm;
bool fastm;
bool ThirdPerson;
bool spoofid;
bool buyhack;
bool shopanywhere;
float thirdfloat = 1.0f;
bool hostme;
bool destroyenemy;
bool aim, aimbot_visiblecheck; float aimbotfov = 20.0f;
float jitterspeed;
bool aastatic, aajitter;
float aastaticxpos, aastaticypos, aastaticzpos;
bool antiaim;
float x2,y2,z2;
bool noscope;
bool infgrenade;
volatile bool matchisfinish = false;
bool drawSilentFOV = false;
bool silentvis = false;
bool silentgradient;
bool silentfill = true;

bool fly = false;
void* joystickinstance = nullptr;
float xu = 0.0f;
float yu = 0.0f;
float flyspeed = 10.0f;
Vector3 flypos = Vector3(0, 0, 0);