#ifndef RENDERING_H
#define RENDERING_H

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"

namespace Rendering {
    struct GLState {
        GLint program;
        GLint texture;
        GLint array_buffer;
        GLint viewport[4];
        GLboolean blend;
        GLboolean scissor;
        GLboolean depth;
        GLint blend_src_rgb;
        GLint blend_dst_rgb;
        GLint blend_src_alpha;
        GLint blend_dst_alpha;
    };

    inline void SaveGLState(GLState& state) {
        glGetIntegerv(GL_CURRENT_PROGRAM, &state.program);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &state.texture);
        glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &state.array_buffer);
        glGetIntegerv(GL_VIEWPORT, state.viewport);
        
        state.blend = glIsEnabled(GL_BLEND);
        state.scissor = glIsEnabled(GL_SCISSOR_TEST);
        state.depth = glIsEnabled(GL_DEPTH_TEST);
        
        glGetIntegerv(GL_BLEND_SRC_RGB, &state.blend_src_rgb);
        glGetIntegerv(GL_BLEND_DST_RGB, &state.blend_dst_rgb);
        glGetIntegerv(GL_BLEND_SRC_ALPHA, &state.blend_src_alpha);
        glGetIntegerv(GL_BLEND_DST_ALPHA, &state.blend_dst_alpha);
    }

    inline void RestoreGLState(const GLState& state) {
        glUseProgram(state.program);
        glBindTexture(GL_TEXTURE_2D, state.texture);
        glBindBuffer(GL_ARRAY_BUFFER, state.array_buffer);
        
        glBlendFuncSeparate(state.blend_src_rgb, state.blend_dst_rgb,
                           state.blend_src_alpha, state.blend_dst_alpha);
        
        state.blend ? glEnable(GL_BLEND) : glDisable(GL_BLEND);
        state.scissor ? glEnable(GL_SCISSOR_TEST) : glDisable(GL_SCISSOR_TEST);
        state.depth ? glEnable(GL_DEPTH_TEST) : glDisable(GL_DEPTH_TEST);
        
        glViewport(state.viewport[0], state.viewport[1],
                  state.viewport[2], state.viewport[3]);
    }

    inline bool RenderFrame() {
        if (ImGui::GetCurrentContext() == nullptr) {
            return false;
        }

        GLState gl_state;
        SaveGLState(gl_state);

        if (!glIsProgram(gl_state.program)) {
            return false;
        }

        ImGuiIO &io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)menu::glWidth, (float)menu::glHeight);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui::NewFrame();

        if (!menu::setup2) {
            setStyle(DARK);
            menu::setup2 = true;
        }

        if (!v1) Mamix::drawWater();
        RenderJumpCircle();
        DrawESP();
        RenderOpenButton();
        R3nderKey();
        R3nderMenu();
        if (showm) Mamix::Watermark();
        RenderTrace();
        Rainbow::Update();

        ImGui::Render();
        glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        RestoreGLState(gl_state);
        return true;
    }
}

#endif // RENDERING_H 