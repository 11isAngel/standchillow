#define IM_TRUNC(_VAL) ((float)(int)(_VAL))

bool selectedLanguage = true; // true = русский, false = английский

const char* GetLang(const char* eng, const char* rus) {
    return selectedLanguage ? rus : eng;
}

namespace ImDesing {
    void RenderToast(const char* text, const float timerValue, float maxTime) {
        if (timerValue <= 0.0f) return;
        
        float localTimer = timerValue;
        
        ImGuiIO& io = ImGui::GetIO();
        float delta = io.DeltaTime;
        float currentTimer = localTimer - delta;

        float progress = 1.0f;
        if (currentTimer < 0.1f)
            progress = currentTimer * 10.0f;
        else if (currentTimer > maxTime - 0.1f)
            progress = (maxTime - currentTimer) * 10.0f;

        float width = io.DisplaySize.x;
        float height = io.DisplaySize.y;
        float toastWidth = 300.0f;
        float toastHeight = 50.0f;
        float x = (width - toastWidth) * 0.5f;
        float y = height * 0.8f - 5.0f * progress;

        ImDrawList* draw = ImGui::GetForegroundDrawList();
        ImVec2 posMin(x, y);
        ImVec2 posMax(x + toastWidth, y + toastHeight);

        ImU32 bgColor = ImColor(0.1f, 0.1f, 0.1f, progress);
        ImU32 textColor = ImColor(1.0f, 1.0f, 1.0f, progress);

        draw->AddRectFilled(posMin, posMax, bgColor, 8.0f);

        ImVec2 textSize = ImGui::CalcTextSize(text);
        ImVec2 textPos = ImVec2(
                x + (toastWidth - textSize.x) * 0.5f,
                y + (toastHeight - textSize.y) * 0.5f
        );

        draw->AddText(textPos, textColor, text);
    }

    bool AnimatedCheckbox(const char* label, bool* v)
    {
        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems)
            return false;
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        const ImVec2 label_size = CalcTextSize(label, NULL, true);
        const float square_sz = GetFrameHeight();
        const ImVec2 pos = window->DC.CursorPos;
        const ImRect total_bb(pos, pos + ImVec2(square_sz + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), label_size.y + style.FramePadding.y * 2.0f));
        ItemSize(total_bb, style.FramePadding.y);
        if (!ItemAdd(total_bb, id))
        {
            IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
            return false;
        }
        bool hovered, held;
        bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
        if (pressed)
        {
            *v = !(*v);
            MarkItemEdited(id);
        }
        const ImRect check_bb(pos, pos + ImVec2(square_sz, square_sz));
        RenderNavHighlight(total_bb, id);
        RenderFrame(check_bb.Min, check_bb.Max, GetColorU32((held && hovered) ? ImGuiCol_FrameBgActive : hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg), true, style.FrameRounding);
        ImU32 check_col = GetColorU32(ImGuiCol_CheckMark);
        bool mixed_value = (g.LastItemData.InFlags & ImGuiItemFlags_MixedValue) != 0;
        if (mixed_value)
        {
            ImVec2 pad(ImMax(1.0f, IM_TRUNC(square_sz / 3.6f)), ImMax(1.0f, IM_TRUNC(square_sz / 3.6f)));
            window->DrawList->AddRectFilled(check_bb.Min + pad, check_bb.Max - pad, check_col, style.FrameRounding);
        }
        else
        {
            static std::unordered_map<ImGuiID, float> animMap;
            float& animVal = animMap[id];
            float target = *v ? 1.0f : 0.0f;
            float delta = ImGui::GetIO().DeltaTime;
            float speed = 10.0f;
            animVal = animVal + (target - animVal) * ImClamp(delta * speed, 0.0f, 1.0f);
            if (animVal > 0.001f)
            {
                const float pad = ImMax(1.0f, IM_TRUNC(square_sz / 6.0f));
                float fullSize = square_sz - pad * 2.0f;
                float animSize = fullSize * animVal;
                ImVec2 checkMarkPos = check_bb.Min + ImVec2(pad, pad) + (ImVec2(fullSize, fullSize) - ImVec2(animSize, animSize)) * 0.5f;
                RenderCheckMark(window->DrawList, checkMarkPos, check_col, animSize);
            }
        }
        ImVec2 label_pos = ImVec2(check_bb.Max.x + style.ItemInnerSpacing.x, check_bb.Min.y + style.FramePadding.y);
        if (g.LogEnabled)
            LogRenderedText(&label_pos, mixed_value ? "[~]" : *v ? "[x]" : "[ ]");
        if (label_size.x > 0.0f)
            RenderText(label_pos, label);
        IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
        return pressed;
    }

    void ColorPicker(const char *name, ImVec4 &color) {
        static ImVec4 backup_color;

        bool open_popup = ImGui::ColorButton((std::string(name) + std::string("##3b")).c_str(),
                                             color);

        if (open_popup) {
            ImGui::OpenPopup(name);
            backup_color = color;
        }
        static bool animate;
        if (ImGui::BeginPopup(name)) {
            ImGui::ColorPicker4((std::string(name) + std::string("##picker")).c_str(),
                                (float *) &color, ImGuiColorEditFlags_NoSidePreview |
                                                  ImGuiColorEditFlags_NoSmallPreview |
                                                  ImGuiColorEditFlags_NoLabel |
                                                  ImGuiColorEditFlags_NoTooltip |
                                                  ImGuiColorEditFlags_NoInputs);
            ImGui::EndPopup();
        }
    }

    void ColorPicker(const char *name, ImColor &color) {
        static ImColor backup_color;

        ImVec4 color_vec4 = color;
        bool open_popup = ImGui::ColorButton((std::string(name) + "##3b").c_str(), color_vec4);

        if (open_popup) {
            ImGui::OpenPopup(name);
            backup_color = color;
        }

        if (ImGui::BeginPopup(name)) {
            ImGui::ColorPicker4((std::string(name) + "##picker").c_str(),
                                (float *) &color.Value,
                                ImGuiColorEditFlags_NoSidePreview |
                                ImGuiColorEditFlags_NoSmallPreview |
                                ImGuiColorEditFlags_NoLabel |
                                ImGuiColorEditFlags_NoTooltip |
                                ImGuiColorEditFlags_NoInputs);
            ImGui::EndPopup();
        }
    }

    void ColorPickerImColor(const char *label, ImVec4 &color) {
        std::string popupId = std::string("ColorPickerPopup_") + label;

        ImGui::Text("%s", label);
        ImGui::SameLine();

        ImGui::ColorButton(label, color,
                           ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoDragDrop,
                           ImVec2(20, 20));
        if (ImGui::IsItemClicked())
            ImGui::OpenPopup(popupId.c_str());

        if (ImGui::BeginPopup(popupId.c_str())) {
            ImGui::ColorPicker4("##picker", (float *) &color, ImGuiColorEditFlags_NoSidePreview |
                                                              ImGuiColorEditFlags_NoSmallPreview);
            ImGui::EndPopup();
        }
    }

    void ColorPicker2(const char *name, ImVec4 &color) {
        static ImVec4 backup_color;
        std::string unique_id = std::string(name) + "##3b";
        bool open_popup = ImGui::ColorButton(unique_id.c_str(), color);

        if (open_popup) {
            ImGui::OpenPopup(name);
            backup_color = color;
        }

        ImGui::AlignTextToFramePadding();
        ImGui::Text("%s", name);

        ImGui::SameLine();

        if (ImGui::BeginPopup(name)) {
            ImGui::ColorPicker4((std::string(name) + "##picker").c_str(),
                                (float *) &color, ImGuiColorEditFlags_NoSidePreview);
            ImGui::EndPopup();
        }
    }

    void ColorPicker(const char *name, float color[4]) {
        static float backup_color[4];

        bool open_popup = ImGui::ColorButton((std::string(name) + "##3b").c_str(),
                                             ImVec4(color[0], color[1], color[2], color[3]));
        if (open_popup) {
            ImGui::OpenPopup(name);
            std::copy(color, color + 4, backup_color);
        }
        if (ImGui::BeginPopup(name)) {
            ImGui::ColorPicker4((std::string(name) + "##picker").c_str(), color,
                                ImGuiColorEditFlags_NoSidePreview |
                                ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_NoLabel |
                                ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
            ImGui::EndPopup();
        }
    }

    void DrawLineGlowW(ImVec2 start, ImVec2 end, ImColor col, float size, int gsize) {
        ImGui::GetBackgroundDrawList()->AddLine(start, end, col, size);
        for (int i = 0; i < gsize; i++) {
            ImGui::GetBackgroundDrawList()->AddLine(start, end,
                                                    ImColor(col.Value.x, col.Value.y, col.Value.z,
                                                            col.Value.w * (1.0f / (float) gsize) *
                                                            (((float) (gsize - i)) /
                                                             (float) gsize)), size + i);
        }
    }

    void DrawLineGlow(ImVec2 start, ImVec2 end, ImVec4 col, float size, int gsize) {
        ImGui::GetBackgroundDrawList()->AddLine(start, end, ImGui::GetColorU32(col), size);
        for (int i = 0; i < gsize; i++) {
            ImGui::GetBackgroundDrawList()->AddLine(start, end, ImGui::GetColorU32(
                                                            ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float) gsize) *
                                                                                        (((float) (gsize - i)) / (float) gsize))),
                                                    size + i);
        }
    }

    void DrawRectGlow(ImVec2 min, ImVec2 max, ImVec4 color, float glowStrength, float round = 0.0f) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);

        for (float i = glowStrength; i > 0.0f; i -= 2.0f) {
            float alpha = (i / glowStrength) * color.w;
            ImU32 glowCol = ImGui::ColorConvertFloat4ToU32(ImVec4(color.x, color.y, color.z, alpha));

            drawList->AddRect(min - ImVec2(i, i), max + ImVec2(i, i), glowCol, round, 0, i);
        }
    }

    Vector2 ImV_to_UV(ImVec2 v) {
        return Vector2(v.x, v.y);
    };

    ImVec2 UV_to_ImV(Vector2 v) {
        return ImVec2(v.x, v.y);
    };
    
    void DrawIconFromByteArray(const unsigned char *image_data, int width, int height, ImVec2 pos) {
        ImDrawList *draw_list = ImGui::GetWindowDrawList();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int idx = (y * width + x) * 4;
                ImVec4 color = ImVec4(
                        image_data[idx] / 255.0f,
                        image_data[idx + 1] / 255.0f,
                        image_data[idx + 2] / 255.0f,
                        image_data[idx + 3] / 255.0f
                );
                draw_list->AddRectFilled(ImVec2(pos.x + x, pos.y + y),
                                         ImVec2(pos.x + x + 1, pos.y + y + 1),
                                         ImGui::ColorConvertFloat4ToU32(color));
            }
        }
    }

    void AddColorPicker(const char* name, ImVec4 &color, bool prd = false, bool* rainbow = nullptr, bool* pulse = nullptr, bool* dark = nullptr) {
        ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
        static ImVec4 backup_color;
        bool open_popup = ImGui::ColorButton((std::string(name) + std::string(OBFUSCATE("##3b"))).c_str(), color, misc_flags);
        if (open_popup) {
            ImGui::OpenPopup(name);
            backup_color = color;
        }
        if (ImGui::BeginPopup(name)) {
            ImGui::Spacing();
            ImGui::Text(OBFUSCATE("%s"), std::string(name).c_str());
            ImGui::Separator();
            ImGui::ColorPicker4(OBFUSCATE("##picker"), (float *) &color,misc_flags | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_AlphaBar);
            ImGui::SameLine();
            ImGui::BeginGroup();
            ImGui::Text(OBFUSCATE("%s"),std::string(OBFUSCATE("Current")).c_str());
            ImGui::ColorButton(OBFUSCATE("##current"), color,ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf,ImVec2(60, 40));
            ImGui::Text(OBFUSCATE("%s"),std::string(OBFUSCATE("Previous")).c_str());
            if (ImGui::ColorButton(OBFUSCATE("##previous"), backup_color,ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf,ImVec2(60, 40)))color = backup_color;
            ImGui::EndGroup();
            if (prd) {
                if (rainbow) ImGui::Checkbox(OBFUSCATE("rainbow"), rainbow);
                if (pulse) ImGui::Checkbox(OBFUSCATE("pulse"), pulse);
                if (dark) ImGui::Checkbox(OBFUSCATE("dark"), dark);
            }
            ImGui::Spacing();
            ImGui::EndPopup();
        }
    }

    void TextCentered(const char *text) {
        ImVec2 windowSize = ImGui::GetWindowSize();
        ImVec2 textSize = ImGui::CalcTextSize(text);
        ImGui::SetCursorPosX((windowSize.x - textSize.x) * 0.5f);
        ImGui::Text("%s", text);
    }
}
