#include <random>
#include <bitset>
#include <array>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>

template<typename T, size_t N>
class SecureContainer {
    std::array<T, N> data;
    uint32_t key;

    T transform(T value) {
        return value ^ (T)key;
    }

public:
    SecureContainer() : key(std::random_device{}()) {}

    void store(T value, size_t index) {
        if (index < N) data[index] = transform(value);
    }

    T load(size_t index) {
        return index < N ? transform(data[index]) : T{};
    }
};

class RuntimeIntegrityCheck {
    static constexpr uint32_t INTEGRITY_KEY = 0xDEADBEEF;
    volatile uint32_t checksum;

public:
    RuntimeIntegrityCheck() : checksum(INTEGRITY_KEY) {}

    bool validate() {
        return checksum == INTEGRITY_KEY;
    }

    void update() {
        checksum = INTEGRITY_KEY ^ std::chrono::steady_clock::now().time_since_epoch().count();
    }
};

template<typename T>
class ObfuscatedType {
private:
    T value;
    uint64_t key;

    T decode() const {
        if constexpr (std::is_pointer_v<T>) {
            return reinterpret_cast<T>(reinterpret_cast<uintptr_t>(value) ^ key);
        } else {
            return static_cast<T>(static_cast<uintptr_t>(value) ^ key);
        }
    }

    void encode(T val) {
        key = std::random_device{}();
        if constexpr (std::is_pointer_v<T>) {
            value = reinterpret_cast<T>(reinterpret_cast<uintptr_t>(val) ^ key);
        } else {
            value = static_cast<T>(static_cast<uintptr_t>(val) ^ key);
        }
    }

public:
    ObfuscatedType(T val) { encode(val); }
    T get() const { return decode(); }
    void set(T val) { encode(val); }
    operator T() const { return decode(); }
};

std::string http_get(const char* host, const char* path) {
    struct hostent* server = gethostbyname(host);
    if (!server) {
        LOGE(OBFUSCATE("Failed to resolve host"));
        return "";
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        LOGE(OBFUSCATE("Failed to create socket"));
        return "";
    }

    struct timeval timeout;
    timeout.tv_sec = 5;
    timeout.tv_usec = 0;
    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout)) < 0) {
        LOGE(OBFUSCATE("Failed to set receive timeout"));
        close(sock);
        return "";
    }
    if (setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char*)&timeout, sizeof(timeout)) < 0) {
        LOGE(OBFUSCATE("Failed to set send timeout"));
        close(sock);
        return "";
    }

    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(80);
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length);

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        LOGE(OBFUSCATE("Connection failed"));
        close(sock);
        return "";
    }

    char request[1024];
    snprintf(request, sizeof(request),
             "GET %s HTTP/1.1\r\n"
             "Host: %s\r\n"
             "User-Agent: Mozilla/5.0\r\n"
             "Accept: text/plain\r\n"
             "Connection: close\r\n\r\n",
             path, host);

    if (send(sock, request, strlen(request), 0) < 0) {
        LOGE(OBFUSCATE("Failed to send request"));
        close(sock);
        return "";
    }

    std::string response;
    char buffer[1024];
    int bytes_received;
    int total_size = 0;
    const int MAX_RESPONSE_SIZE = 10240; // Максимальный размер ответа 10KB

    while ((bytes_received = recv(sock, buffer, sizeof(buffer) - 1, 0)) > 0) {
        total_size += bytes_received;
        if (total_size > MAX_RESPONSE_SIZE) {
            LOGE(OBFUSCATE("Response too large"));
            close(sock);
            return "";
        }
        buffer[bytes_received] = 0;
        response += buffer;
    }

    close(sock);

    if (response.empty()) {
        LOGE(OBFUSCATE("Empty response"));
        return "";
    }

    // Ищем начало тела ответа
    size_t body_pos = response.find("\r\n\r\n");
    if (body_pos == std::string::npos) {
        LOGE(OBFUSCATE("Invalid response format"));
        return "";
    }

    // Проверяем код ответа
    if (response.find("HTTP/1.1 200") == std::string::npos) {
        LOGE(OBFUSCATE("Invalid response code"));
        return "";
    }

    std::string body = response.substr(body_pos + 4);
    if (body.find("http://") != 0 && body.find("https://") != 0) {
        LOGE(OBFUSCATE("Invalid URL in response"));
        return "";
    }

    return body;
}

void openUrlInBrowser(const std::string &url) {
    JNIEnv *env;
    vm_j->AttachCurrentThread(&env, 0);
    {
        jclass intentClass = env->FindClass("android/content/Intent");
        jmethodID intentConstructor = env->GetMethodID(intentClass, "<init>", "(Ljava/lang/String;)V");
        jstring actionView = env->NewStringUTF("android.intent.action.VIEW");
        jobject intent = env->NewObject(intentClass, intentConstructor, actionView);

        jmethodID setDataMethod = env->GetMethodID(intentClass, "setData", "(Landroid/net/Uri;)Landroid/content/Intent;");
        jclass uriClass = env->FindClass("android/net/Uri");
        jmethodID parseMethod = env->GetStaticMethodID(uriClass, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
        jstring jUrl = env->NewStringUTF(url.c_str());
        jobject uri = env->CallStaticObjectMethod(uriClass, parseMethod, jUrl);
        env->CallObjectMethod(intent, setDataMethod, uri);

        jmethodID addFlagsMethod = env->GetMethodID(intentClass, "addFlags", "(I)Landroid/content/Intent;");
        const jint FLAG_ACTIVITY_NEW_TASK = 0x10000000;
        env->CallObjectMethod(intent, addFlagsMethod, FLAG_ACTIVITY_NEW_TASK);

        jclass contextClass = env->FindClass("android/content/Context");
        jmethodID startActivityMethod = env->GetMethodID(contextClass, "startActivity", "(Landroid/content/Intent;)V");
        env->CallVoidMethod(object, startActivityMethod, intent);

        env->DeleteLocalRef(actionView);
        env->DeleteLocalRef(jUrl);
        env->DeleteLocalRef(uri);
        env->DeleteLocalRef(intent);
        env->DeleteLocalRef(intentClass);
        env->DeleteLocalRef(uriClass);
        env->DeleteLocalRef(contextClass);
    }
    vm_j->DetachCurrentThread();
}

#include <jni.h>
#include <string>

extern JavaVM* vm_j;
extern jobject object;

std::string GetAndroidId() {
    JNIEnv *env = nullptr;
    if (vm_j->AttachCurrentThread(&env, nullptr) != JNI_OK) return "";
    if (!env || !object) return "";
    jclass contextClass = env->GetObjectClass(object);
    if (!contextClass) return "";
    jmethodID midGetContentResolver = env->GetMethodID(contextClass, "getContentResolver", "()Landroid/content/ContentResolver;");
    if (!midGetContentResolver) {
        env->DeleteLocalRef(contextClass);
        return "";
    }
    jobject contentResolver = env->CallObjectMethod(object, midGetContentResolver);
    if (!contentResolver) {
        env->DeleteLocalRef(contextClass);
        return "";
    }
    jclass secureClass = env->FindClass("android/provider/Settings$Secure");
    if (!secureClass) {
        env->DeleteLocalRef(contentResolver);
        env->DeleteLocalRef(contextClass);
        return "";
    }
    jmethodID midGetString = env->GetStaticMethodID(secureClass, "getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    if (!midGetString) {
        env->DeleteLocalRef(secureClass);
        env->DeleteLocalRef(contentResolver);
        env->DeleteLocalRef(contextClass);
        return "";
    }
    jstring key = env->NewStringUTF("android_id");
    jstring androidId = (jstring)env->CallStaticObjectMethod(secureClass, midGetString, contentResolver, key);
    std::string result;
    if (androidId) {
        const char* idChars = env->GetStringUTFChars(androidId, nullptr);
        if (idChars) {
            result = idChars;
            env->ReleaseStringUTFChars(androidId, idChars);
        }
    }
    env->DeleteLocalRef(key);
    if (androidId) env->DeleteLocalRef(androidId);
    env->DeleteLocalRef(secureClass);
    env->DeleteLocalRef(contentResolver);
    env->DeleteLocalRef(contextClass);
    return result;
}

std::string getClipboardText() {
    std::string result;
    JNIEnv *env;
    vm_j->AttachCurrentThread(&env, 0);
    {
        jclass contextClass = env->FindClass("android/content/Context");
        jmethodID getSystemServiceMethod = env->GetMethodID(contextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        jstring clipboardService = env->NewStringUTF("clipboard");
        jobject clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, clipboardService);
        env->DeleteLocalRef(clipboardService);

        jclass clipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        jmethodID getPrimaryClipMethod = env->GetMethodID(clipboardManagerClass, "getPrimaryClip", "()Landroid/content/ClipData;");
        jobject clipData = env->CallObjectMethod(clipboardManager, getPrimaryClipMethod);

        if (clipData) {
            jclass clipDataClass = env->FindClass("android/content/ClipData");
            jmethodID getItemAtMethod = env->GetMethodID(clipDataClass, "getItemAt", "(I)Landroid/content/ClipData$Item;");
            jobject item = env->CallObjectMethod(clipData, getItemAtMethod, 0);

            jclass clipDataItemClass = env->FindClass("android/content/ClipData$Item");
            jmethodID coerceToTextMethod = env->GetMethodID(clipDataItemClass, "coerceToText", "(Landroid/content/Context;)Ljava/lang/CharSequence;");
            jobject text = env->CallObjectMethod(item, coerceToTextMethod, object);
            if (text) {
                jclass charSequenceClass = env->FindClass("java/lang/CharSequence");
                jmethodID toStringMethod = env->GetMethodID(charSequenceClass, "toString", "()Ljava/lang/String;");
                jstring textString = (jstring) env->CallObjectMethod(text, toStringMethod);
                if (textString) {
                    const char* utfChars = env->GetStringUTFChars(textString, nullptr);
                    result = utfChars;
                    env->ReleaseStringUTFChars(textString, utfChars);
                    env->DeleteLocalRef(textString);
                }
                env->DeleteLocalRef(charSequenceClass);
                env->DeleteLocalRef(text);
            }
            env->DeleteLocalRef(clipDataItemClass);
            env->DeleteLocalRef(item);
            env->DeleteLocalRef(clipDataClass);
            env->DeleteLocalRef(clipData);
        }
        env->DeleteLocalRef(clipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(contextClass);
    }
    vm_j->DetachCurrentThread();
    return result;
}

JNIEnv* getJNIEnv() {
    JNIEnv* env;
    if (vm_j->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm_j->AttachCurrentThread(&env, nullptr) != JNI_OK) {
            LOGI("Failed to attach current thread");
            return nullptr;
        }
    }
    return env;
}

void showToast(jobject activity, const char* text, int length) {
    if (!activity || !text) {
        LOGI("showToast: Invalid parameters");
        return;
    }

    JNIEnv* env = getJNIEnv();
    if (!env) {
        LOGI("showToast: Failed to get JNIEnv");
        return;
    }

    // Находим класс Toast
    jclass toastClass = env->FindClass("android/widget/Toast");
    if (!toastClass) {
        LOGI("showToast: Failed to find Toast class");
        return;
    }

    // Находим метод makeText
    jmethodID makeTextMethod = env->GetStaticMethodID(toastClass, "makeText", 
        "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    if (!makeTextMethod) {
        LOGI("showToast: Failed to find makeText method");
        env->DeleteLocalRef(toastClass);
        return;
    }

    // Создаем строку
    jstring jText = env->NewStringUTF(text);
    if (!jText) {
        LOGI("showToast: Failed to create jstring");
        env->DeleteLocalRef(toastClass);
        return;
    }

    // Создаем Toast
    jobject toast = env->CallStaticObjectMethod(toastClass, makeTextMethod, activity, jText, length);
    if (!toast) {
        LOGI("showToast: Failed to create Toast object");
        env->DeleteLocalRef(jText);
        env->DeleteLocalRef(toastClass);
        return;
    }

    // Находим метод show
    jmethodID showMethod = env->GetMethodID(toastClass, "show", "()V");
    if (!showMethod) {
        LOGI("showToast: Failed to find show method");
        env->DeleteLocalRef(toast);
        env->DeleteLocalRef(jText);
        env->DeleteLocalRef(toastClass);
        return;
    }

    // Показываем Toast
    env->CallVoidMethod(toast, showMethod);

    // Очищаем исключения
    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        env->ExceptionClear();
    }

    // Освобождаем ресурсы
    env->DeleteLocalRef(toast);
    env->DeleteLocalRef(jText);
    env->DeleteLocalRef(toastClass);
}

bool isKeyValid(const std::string& key) {
    static RuntimeIntegrityCheck integrityCheck;
    if (!integrityCheck.validate()) return false;

    const char* host = OBFUSCATE("fiksam.pythonanywhere.com");
    const int port = 80;

    std::string fullRequest = "GET /api/check_key?key=" + key + " HTTP/1.1\r\n"
                                                                "Host: " + std::string(host) + "\r\n"
                                                                                               "Connection: close\r\n\r\n";

    struct hostent* server = gethostbyname(host);
    if (!server) return false;

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) return false;

    struct sockaddr_in serveraddr;
    std::memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    std::memcpy(&serveraddr.sin_addr.s_addr, server->h_addr, server->h_length);
    serveraddr.sin_port = htons(port);

    if (connect(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0) {
        close(sockfd);
        return false;
    }

    write(sockfd, fullRequest.c_str(), fullRequest.length());

    std::string response;
    char buffer[1024];

    while (true) {
        int n = read(sockfd, buffer, sizeof(buffer) - 1);
        if (n <= 0) break;
        buffer[n] = '\0';
        response += buffer;
    }

    close(sockfd);

    // Находим начало JSON-ответа
    size_t pos = response.find("\r\n\r\n");
    if (pos != std::string::npos) {
        response = response.substr(pos + 4);
    }

    // Убираем все пробелы и переносы строк
    response.erase(std::remove_if(response.begin(), response.end(),
                                  [](unsigned char c) { return std::isspace(c); }),
                   response.end());

    // Проверяем точное совпадение с ожидаемым ответом
    const std::string expectedResponse = "{\"exists\":true}";
    bool isValid = (response == expectedResponse);

    if (isValid) {
        LOGI("Key validation successful. Response: %s", response.c_str());
    } else {
        LOGI("Key validation failed. Response: %s", response.c_str());
    }

    return isValid;
}

bool isCurrentVersion() {
    /*static RuntimeIntegrityCheck integrityCheck;
    if (!integrityCheck.validate()) {
        LOGI("Integrity check failed");
        return false;
    }*/

    const char* host = OBFUSCATE("fiksam.pythonanywhere.com");
    std::string request = "GET /ver.txt HTTP/1.1\r\nHost: " + std::string(host) + "\r\nConnection: close\r\n\r\n";

    hostent* server = gethostbyname(host);
    if (!server) {
        LOGI("Failed to resolve host");
        return false;
    }

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        LOGI("Failed to create socket");
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    std::memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    addr.sin_port = htons(80);

    if (connect(sockfd, (sockaddr*)&addr, sizeof(addr)) < 0) {
        LOGI("Failed to connect");
        close(sockfd);
        return false;
    }

    if (write(sockfd, request.c_str(), request.length()) < 0) {
        LOGI("Failed to write request");
        close(sockfd);
        return false;
    }

    std::string response;
    char buf[512];
    int len;
    while ((len = read(sockfd, buf, sizeof(buf))) > 0) response.append(buf, len);
    close(sockfd);

    auto pos = response.find("\r\n\r\n");
    if (pos == std::string::npos) {
        LOGI("Invalid response format");
        return false;
    }
    response = response.substr(pos + 4);
    response.erase(std::remove_if(response.begin(), response.end(), ::isspace), response.end());

    LOGI("Received version: %s, Current version: %s", response.c_str(), ver.c_str());
    bool valid = (response == ver);
    LOGI("Version check: %s", valid ? "OK" : "FAIL");
    return valid;
}

std::string cachedKeyTime;
std::chrono::steady_clock::time_point lastUpdateTime;
const std::chrono::seconds updateInterval(60);
bool keyExpired = false;

struct LicenseTime {
    int years;
    int days;
    int hours;
    int minutes;
    int seconds;
    std::chrono::system_clock::time_point lastUpdate;
    bool isValid;
};

class LicenseManager {
private:
    static LicenseManager* instance;
    static std::mutex mtx;
    LicenseTime currentTime;
    std::thread* updateThread;
    bool shouldRun;
    std::atomic<bool> isInitialized;

    void decrementTime() {
        try {
            if (!currentTime.isValid) return;

            auto now = std::chrono::system_clock::now();
            auto diff = std::chrono::duration_cast<std::chrono::seconds>(now - currentTime.lastUpdate).count();

            if (diff <= 0) return;

            currentTime.lastUpdate = now;

            int64_t totalSeconds = currentTime.seconds +
                                   currentTime.minutes * 60 +
                                   currentTime.hours * 3600 +
                                   currentTime.days * 86400 +
                                   currentTime.years * 31536000;

            totalSeconds -= diff;

            if (totalSeconds <= 0) {
                currentTime.isValid = false;
                currentTime.years = 0;
                currentTime.days = 0;
                currentTime.hours = 0;
                currentTime.minutes = 0;
                currentTime.seconds = 0;
                return;
            }

            currentTime.years = totalSeconds / 31536000;
            totalSeconds %= 31536000;

            currentTime.days = totalSeconds / 86400;
            totalSeconds %= 86400;

            currentTime.hours = totalSeconds / 3600;
            totalSeconds %= 3600;

            currentTime.minutes = totalSeconds / 60;
            currentTime.seconds = totalSeconds % 60;

            LOGI("Time updated: %d y, %d d, %d h, %d m, %d s",
                 currentTime.years, currentTime.days, currentTime.hours,
                 currentTime.minutes, currentTime.seconds);
        } catch (const std::exception& e) {
            LOGI("Error in decrementTime: %s", e.what());
        } catch (...) {
            LOGI("Unknown error in decrementTime");
        }
    }

    void updateLoop() {
        while (shouldRun) {
            try {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                std::lock_guard<std::mutex> lock(mtx);
                decrementTime();
            } catch (const std::exception& e) {
                LOGI("Error in updateLoop: %s", e.what());
            } catch (...) {
                LOGI("Unknown error in updateLoop");
            }
        }
    }

    LicenseManager() : shouldRun(true), isInitialized(false) {
        currentTime.isValid = false;
    }

public:
    static LicenseManager* getInstance() {
        if (!instance) {
            std::lock_guard<std::mutex> lock(mtx);
            if (!instance) {
                instance = new LicenseManager();
            }
        }
        return instance;
    }

    void initialize() {
        if (!isInitialized.exchange(true)) {
            updateThread = new std::thread(&LicenseManager::updateLoop, this);
        }
    }

    void updateLicenseFromServer(const std::string& response) {
        try {
            std::lock_guard<std::mutex> lock(mtx);

            auto extractValue = [](const std::string& json, const char* key) -> int {
                std::string keyPattern = "\"" + std::string(key) + "\":";
                size_t pos = json.find(keyPattern);
                if (pos != std::string::npos) {
                    pos += keyPattern.length();
                    size_t endPos = json.find_first_of(",}", pos);
                    if (endPos != std::string::npos) {
                        try {
                            return std::stoi(json.substr(pos, endPos - pos));
                        } catch (...) {
                            return 0;
                        }
                    }
                }
                return 0;
            };

            currentTime.years = extractValue(response, "y");
            currentTime.days = extractValue(response, "d");
            currentTime.hours = extractValue(response, "h");
            currentTime.minutes = extractValue(response, "m");
            currentTime.seconds = extractValue(response, "s");
            currentTime.lastUpdate = std::chrono::system_clock::now();
            currentTime.isValid = (currentTime.years > 0 || currentTime.days > 0 ||
                                   currentTime.hours > 0 || currentTime.minutes > 0 ||
                                   currentTime.seconds > 0);

            LOGI("License updated: %d y, %d d, %d h, %d m, %d s, valid: %d",
                 currentTime.years, currentTime.days, currentTime.hours,
                 currentTime.minutes, currentTime.seconds, currentTime.isValid);

            initialize();
        } catch (const std::exception& e) {
            LOGI("Error in updateLicenseFromServer: %s", e.what());
        } catch (...) {
            LOGI("Unknown error in updateLicenseFromServer");
        }
    }

    std::string getCurrentTime() {
        try {
            std::lock_guard<std::mutex> lock(mtx);

            if (!currentTime.isValid) {
                return "License expired";
            }

            char timeStr[128];
            snprintf(timeStr, sizeof(timeStr), "License time: %d y, %d d, %d h, %d m, %d s",
                     currentTime.years, currentTime.days, currentTime.hours,
                     currentTime.minutes, currentTime.seconds);

            LOGI("Current time: %s", timeStr);
            return std::string(timeStr);
        } catch (const std::exception& e) {
            LOGI("Error in getCurrentTime: %s", e.what());
            return "Error getting time";
        } catch (...) {
            LOGI("Unknown error in getCurrentTime");
            return "Error getting time";
        }
    }

    ~LicenseManager() {
        shouldRun = false;
        if (updateThread && updateThread->joinable()) {
            updateThread->join();
            delete updateThread;
        }
    }
};

LicenseManager* LicenseManager::instance = nullptr;
std::mutex LicenseManager::mtx;

std::string getTime(const std::string& k) {
    static bool firstRun = true;
    static RuntimeIntegrityCheck integrityCheck;

    if (!integrityCheck.validate()) exit(1);

    if (!firstRun) {
        return LicenseManager::getInstance()->getCurrentTime();
    }

    const char* host = OBFUSCATE("fiksam.pythonanywhere.com");
    const int port = 80;

    std::string fullRequest = "GET /api/check_license?key=" + k + " HTTP/1.1\r\n"
                                                                  "Host: " + std::string(host) + "\r\n"
                                                                                                 "Connection: close\r\n\r\n";

    struct hostent* server = gethostbyname(host);
    if (!server) return "Error 0x1";

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) return "Error 0x2";

    struct sockaddr_in serveraddr;
    std::memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    std::memcpy(&serveraddr.sin_addr.s_addr, server->h_addr, server->h_length);
    serveraddr.sin_port = htons(port);

    if (connect(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0) {
        close(sockfd);
        return "Error 0x3";
    }

    write(sockfd, fullRequest.c_str(), fullRequest.length());

    std::string response;
    char buffer[1024];

    while (true) {
        int n = read(sockfd, buffer, sizeof(buffer) - 1);
        if (n <= 0) break;
        buffer[n] = '\0';
        response += buffer;
    }

    close(sockfd);

    // Находим начало JSON
    size_t pos = response.find("\r\n\r\n");
    if (pos != std::string::npos) {
        response = response.substr(pos + 4);

        // Убираем пробелы
        response.erase(std::remove_if(response.begin(), response.end(),
                                      [](unsigned char c) { return std::isspace(c); }),
                       response.end());

        LOGI("License response: %s", response.c_str());

        auto extractValue = [](const std::string& json, const char* key) -> int {
            std::string keyPattern = "\"" + std::string(key) + "\":";
            size_t pos = json.find(keyPattern);
            if (pos != std::string::npos) {
                pos += keyPattern.length();
                size_t endPos = json.find_first_of(",}", pos);
                if (endPos != std::string::npos) {
                    try {
                        return std::stoi(json.substr(pos, endPos - pos));
                    } catch (...) {
                        return 0;
                    }
                }
            }
            return 0;
        };

        LicenseTime time;
        time.years = extractValue(response, "y");
        time.days = extractValue(response, "d");
        time.hours = extractValue(response, "h");
        time.minutes = extractValue(response, "m");
        time.seconds = extractValue(response, "s");
        time.lastUpdate = std::chrono::system_clock::now();
        time.isValid = (time.years > 0 || time.days > 0 || time.hours > 0 || time.minutes > 0 || time.seconds > 0);

        LOGI("Parsed time: %d years, %d days, %d hours, %d minutes, %d seconds",
             time.years, time.days, time.hours, time.minutes, time.seconds);

        if (time.isValid) {
            LicenseManager::getInstance()->updateLicenseFromServer(response);
            firstRun = false;
            return LicenseManager::getInstance()->getCurrentTime();
        }
    }

    return "License expired";
}

std::string getCachedKeyTime(const std::string& k) {
    auto now = std::chrono::steady_clock::now();
    if (cachedKeyTime.empty() || k != key || now - lastUpdateTime > updateInterval) {
        cachedKeyTime = getTime(k);
        lastUpdateTime = now;
    }
    return cachedKeyTime;
}

void Toast(JNIEnv *env, jobject thiz, const char *text, int length) {
    jstring jstr = env->NewStringUTF(text);
    jclass toast = env->FindClass(OBFUSCATE("android/widget/Toast"));
    jmethodID methodMakeText =env->GetStaticMethodID(toast,OBFUSCATE("makeText"),OBFUSCATE("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"));
    jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText,thiz, jstr, length);
    jmethodID methodShow = env->GetMethodID(toast, OBFUSCATE("show"), OBFUSCATE("()V"));
    env->CallVoidMethod(toastobj, methodShow);
}

void callShowToast(JNIEnv* env, jobject context, const char *text, int time) {
    Toast(env, context, text, time);
}

