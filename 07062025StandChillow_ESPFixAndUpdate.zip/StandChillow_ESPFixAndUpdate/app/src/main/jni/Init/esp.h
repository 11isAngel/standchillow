#include <map>

void DrawChinaHat(Vector3 pos, float segments, float radius, ImColor color, float lcolor[3]) {
    if (!lcolor || segments <= 0 || radius <= 0) return;
    if (pos == Vector3(0, 0, 0)) return;
    
    if (!ImGui::GetCurrentContext()) return;
    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;
    bool topposValid;
    Vector3 topPos = pos + Vector3(0, radius, 0);
    ImVec2 toppos = world2screen_c(topPos, topposValid);
    if (!topposValid) return;
    ImColor lcolorConverted = ImColor(lcolor[0], lcolor[1], lcolor[2], 1.0f);
    if (lcolorConverted.Value.w <= 0.0f) return;

    const float angleStep = (M_PI * 2) / segments;
    const float radiusCos = radius * cosf(angleStep);
    const float radiusSin = radius * sinf(angleStep);

    for (float i = 0; i < segments; i++) {
        float currentAngle = i * angleStep;
        float nextAngle = (i + 1) * angleStep;
        
        Vector3 pos1 = Vector3(
            pos.x + radius * cosf(currentAngle),
                pos.y,
            pos.z + radius * sinf(currentAngle)
        );

        Vector3 pos2 = Vector3(
            pos.x + radius * cosf(nextAngle),
                pos.y,
            pos.z + radius * sinf(nextAngle)
        );

        bool checker1, checker2;
        ImVec2 vPos = world2screen_c(pos1, checker1);
        ImVec2 vNextPos = world2screen_c(pos2, checker2);

        if (!checker1 || !checker2) continue;

            float gradFactor = (segments - i) / segments;
            ImColor gradColor = ImColor(
                    color.Value.x * gradFactor,
                    color.Value.y * gradFactor,
                    color.Value.z * gradFactor,
                    color.Value.w
            );
        if (gradColor.Value.w <= 0.0f) continue;

            draw->AddLine(vPos, vNextPos, lcolorConverted, 3);
        draw->AddTriangleFilled(toppos, vPos, vNextPos, gradColor);
    }
}

void DrawSkeleton(void* player, ImVec4 color, bool skeletonoutline) {
    if (!isValidPlayer(player)) return;

    if (!ImGui::GetCurrentContext()) return;
    
    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    void* bones = GetBones(player);
    if (!bones || (uintptr_t)bones < 0x10000) return;

    Vector3 headPos = GetPlayerHead(player);
    Vector3 neckPos = GetPlayerNeck(player);
    Vector3 hipPos = GetPlayerHip(player);
    Vector3 leftUpperArmPos = GetPlayerLeftUpperArm(player);
    Vector3 leftLowerArmPos = GetPlayerLeftLowerArm(player);
    Vector3 leftHandPos = GetPlayerLeftHand(player);
    Vector3 rightUpperArmPos = GetPlayerRightUpperArm(player);
    Vector3 rightLowerArmPos = GetPlayerRightLowerArm(player);
    Vector3 rightHandPos = GetPlayerRightHand(player);
    Vector3 leftUpperLegPos = GetPlayerLeftUpperLeg(player);
    Vector3 leftLowerLegPos = GetPlayerLeftLowerLeg(player);
    Vector3 rightUpperLegPos = GetPlayerRightUpperLeg(player);
    Vector3 rightLowerLegPos = GetPlayerRightLowerLeg(player);

    if (headPos == Vector3(0, 0, 0) || neckPos == Vector3(0, 0, 0) || 
        hipPos == Vector3(0, 0, 0) || leftUpperArmPos == Vector3(0, 0, 0) ||
        leftLowerArmPos == Vector3(0, 0, 0) || leftHandPos == Vector3(0, 0, 0) ||
        rightUpperArmPos == Vector3(0, 0, 0) || rightLowerArmPos == Vector3(0, 0, 0) ||
        rightHandPos == Vector3(0, 0, 0) || leftUpperLegPos == Vector3(0, 0, 0) ||
        leftLowerLegPos == Vector3(0, 0, 0) || rightUpperLegPos == Vector3(0, 0, 0) ||
        rightLowerLegPos == Vector3(0, 0, 0)) {
        return;
    }

    bool headUpValid, headValid, neckValid, hipValid, leftUpperArmValid, leftLowerArmValid,
         leftHandValid, rightUpperArmValid, rightLowerArmValid, rightHandValid,
         leftUpperLegValid, leftLowerLegValid, rightUpperLegValid, rightLowerLegValid;

    ImVec2 headUpPos = world2screen_c(headPos + Vector3(0, 0.3f, 0), headUpValid);
    ImVec2 headPos2D = world2screen_c(headPos, headValid);
    ImVec2 neckPos2D = world2screen_c(neckPos, neckValid);
    ImVec2 hipPos2D = world2screen_c(hipPos, hipValid);
    ImVec2 leftUpperArmPos2D = world2screen_c(leftUpperArmPos, leftUpperArmValid);
    ImVec2 leftLowerArmPos2D = world2screen_c(leftLowerArmPos, leftLowerArmValid);
    ImVec2 leftHandPos2D = world2screen_c(leftHandPos, leftHandValid);
    ImVec2 rightUpperArmPos2D = world2screen_c(rightUpperArmPos, rightUpperArmValid);
    ImVec2 rightLowerArmPos2D = world2screen_c(rightLowerArmPos, rightLowerArmValid);
    ImVec2 rightHandPos2D = world2screen_c(rightHandPos, rightHandValid);
    ImVec2 leftUpperLegPos2D = world2screen_c(leftUpperLegPos, leftUpperLegValid);
    ImVec2 leftLowerLegPos2D = world2screen_c(leftLowerLegPos, leftLowerLegValid);
    ImVec2 rightUpperLegPos2D = world2screen_c(rightUpperLegPos, rightUpperLegValid);
    ImVec2 rightLowerLegPos2D = world2screen_c(rightLowerLegPos, rightLowerLegValid);

    if (!headUpValid || !headValid || !neckValid || !hipValid || !leftUpperArmValid || 
        !leftLowerArmValid || !leftHandValid || !rightUpperArmValid || !rightLowerArmValid || 
        !rightHandValid || !leftUpperLegValid || !leftLowerLegValid || !rightUpperLegValid || 
        !rightLowerLegValid) {
        return;
    }

        if (skeletonoutline) {
        draw->AddLine(headPos2D, neckPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(neckPos2D, hipPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(neckPos2D, leftUpperArmPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(leftUpperArmPos2D, leftLowerArmPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(leftLowerArmPos2D, leftHandPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(neckPos2D, rightUpperArmPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(rightUpperArmPos2D, rightLowerArmPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(rightLowerArmPos2D, rightHandPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(hipPos2D, leftUpperLegPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(leftUpperLegPos2D, leftLowerLegPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(hipPos2D, rightUpperLegPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);
        draw->AddLine(rightUpperLegPos2D, rightLowerLegPos2D, ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 2);

        float headRadius = ((headPos2D.y - headUpPos.y) * 0.8f) / 2;
        if (headRadius > 0) {
            draw->AddCircle(
                ImVec2(headPos2D.x, headPos2D.y - headRadius),
                headRadius,
                    ImGui::GetColorU32(ImVec4(0, 0, 0, 1)), 30, 2);
        }
    }

    draw->AddLine(headPos2D, neckPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(neckPos2D, hipPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(neckPos2D, leftUpperArmPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(leftUpperArmPos2D, leftLowerArmPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(leftLowerArmPos2D, leftHandPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(neckPos2D, rightUpperArmPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(rightUpperArmPos2D, rightLowerArmPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(rightLowerArmPos2D, rightHandPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(hipPos2D, leftUpperLegPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(leftUpperLegPos2D, leftLowerLegPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(hipPos2D, rightUpperLegPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);
    draw->AddLine(rightUpperLegPos2D, rightLowerLegPos2D, ImGui::ColorConvertFloat4ToU32(color), 1);

    float headRadius = ((headPos2D.y - headUpPos.y) * 0.8f) / 2;
    if (headRadius > 0) {
        draw->AddCircle(
            ImVec2(headPos2D.x, headPos2D.y - headRadius),
            headRadius,
                ImGui::ColorConvertFloat4ToU32(color), 30, 1);
    }
}

std::string ConvertIl2CppMonoStringToString(Il2CppString* str) {
    if (!str) return "";

    const char* cstr = str->CString();
    if (!cstr) return "";

    std::string result;
    while (*cstr) {
        if (static_cast<unsigned char>(*cstr) < 128) {
            result += *cstr;
        } else {
            result += '?';
        }
        cstr++;
    }

    return result;
}

void Draw3DCircle_esp(ImDrawList* draw, void* player, void* camera, Vector3 pos, int screenHeight, float deltaTime) {
    if (!draw || !player || !camera || screenHeight <= 0 || deltaTime <= 0) return;
    if (pos == Vector3(0, 0, 0)) return;

    if (circleMap.find(player) == circleMap.end()) {
        circleMap[player] = CircleData();
    }
    auto& circle = circleMap[player];

    circle.timer += deltaTime;

    float t = circle.timer / 1.2f;
    if (t > 1.0f) {
        circle.timer = 0.0f;
        t = 0.0f;
    }

    circle.alpha = (1.0f - t) * 255.0f;
    circle.radius = 0.5f + t * 1.f;

    const int segments = 48;
    Vector3 base = pos;
    base.y -= 0.1f;

    for (int s = 0; s < segments; ++s) {
        float angle1 = (2 * M_PI / segments) * s;
        float angle2 = (2 * M_PI / segments) * (s + 1);

        Vector3 p1 = {
                base.x + cosf(angle1) * circle.radius,
                base.y,
                base.z + sinf(angle1) * circle.radius
        };
        Vector3 p2 = {
                base.x + cosf(angle2) * circle.radius,
                base.y,
                base.z + sinf(angle2) * circle.radius
        };

        Vector3 sp1 = WorldToScreenPoint(camera, p1);
        Vector3 sp2 = WorldToScreenPoint(camera, p2);

        if (sp1.z > 0.f && sp2.z > 0.f) {
            draw->AddLine(
                    {sp1.x, screenHeight - sp1.y},
                    {sp2.x, screenHeight - sp2.y},
                    IM_COL32(colors::esp::player::circleColor.x * 255, colors::esp::player::circleColor.y * 255, colors::esp::player::circleColor.z * 255, (int)circle.alpha),
                    1.5f
            );
        }
    }
}

void DrawESP() {
    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw || !ImGui::GetCurrentContext()) return;

    if (drawfov) {
        if (!ImGui::GetIO().DisplaySize.x || !ImGui::GetIO().DisplaySize.y) return;
        
        ImGui::Begin("##aim", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                                       ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                                       ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                                       ImGuiWindowFlags_NoScrollbar |
                                       ImGuiWindowFlags_NoBackground |
                                       ImGuiWindowFlags_NoMouseInputs);
        if (!ImGui::GetCurrentWindow()) return;
        ImU32 color = circleRGB ? ImGui::ColorConvertFloat4ToU32(
                ImVec4(Rainbow::GetColor().x, Rainbow::GetColor().y, Rainbow::GetColor().z,
                       Rainbow::GetColor().w))
                                : ImGui::ColorConvertFloat4ToU32(aimclr);
        if (circleOutline) {
            draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                      aimbotfov + 1.2f, IM_COL32(0, 0, 0, 255), 100,
                                                      3.0f);
        }
        draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                  aimbotfov, color, 100, 1.5f);
        ImGui::End();
    }

    if (drawfovtrigger) {
        ImGui::Begin("##triggerbot", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        ImU32 color = circleRGBt ? ImGui::ColorConvertFloat4ToU32(
                ImVec4(Rainbow::GetColor().x, Rainbow::GetColor().y, Rainbow::GetColor().z,
                       Rainbow::GetColor().w))
                                 : ImGui::ColorConvertFloat4ToU32(aimclrt);
        if (circleOutlinet) {
            draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                      triggerfov + 1.2f, IM_COL32(0, 0, 0, 255),
                                                      100,
                                                      3.0f);
        }
        draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                  triggerfov, color, 100, 1.5f);
        ImGui::End();
    }

    if (silentfov) {
        ImGui::Begin("##silentaim", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        ImU32 color1 = circleRGBs ? ImGui::ColorConvertFloat4ToU32(
                ImVec4(Rainbow::GetColor().x, Rainbow::GetColor().y, Rainbow::GetColor().z,
                       Rainbow::GetColor().w))
                                  : ImGui::ColorConvertFloat4ToU32(silentaimclr);

        if (silentfill) {
            draw->AddCircleFilled(
                    ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                    silentfovsize,
                    ImGui::ColorConvertFloat4ToU32(ImVec4(
                            silentaimclr.x, silentaimclr.y, silentaimclr.z, 0.3f
                    )),
                    100
            );
        }
        if (silentgradient) {
            ImVec2 center = ImVec2(menu::glWidth / 2, menu::glHeight / 2);
            float radius = silentfovsize;

            for (float r = radius; r > 0; r -= 1.0f) {
                float alpha = (r / radius) * 0.3f;
                ImU32 fillColor = ImGui::ColorConvertFloat4ToU32(
                        ImVec4(silentaimclr.x, silentaimclr.y, silentaimclr.z, alpha)
                );
                draw->AddCircleFilled(center, r, fillColor, 100);
            }
        }
        if (circleOutlines) {
            draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                      silentfovsize + 1.2f, IM_COL32(0, 0, 0, 255),
                                                      100, 3.0f);
        }
        draw->AddCircle(ImVec2(menu::glWidth / 2, menu::glHeight / 2),
                                                  silentfovsize, color1, 100, 1.5f);
        ImGui::End();
    }
    if (esp::player::enable) {
        clearPlayers();

        for (int i = 0; i < players.size(); i++) {
            void* Player = players[i];
            if (!isValidPlayer(Player)) continue;
            if (!isValidPhoton(get_photon(Player))) continue;

            /*if (IsMatchEnding()) {
                esp::player::enable = false;
            }*/

            void* playerTransform = get_transform(Player);
            if (!playerTransform) continue;

            void* camera = get_camera();
            if (!camera) continue;

            void* cameraTransform = get_transform(camera);
            if (!cameraTransform) continue;

            Vector3 playerpos = get_position(playerTransform);
            if (playerpos == Vector3(0, 0, 0)) continue;

            Vector3 viewpos = get_position(cameraTransform);
            if (viewpos == Vector3(0, 0, 0)) continue;

            Vector3 lower_pos = WorldToScreenPoint(camera, playerpos);
            if (lower_pos == Vector3(0, 0, 0) || lower_pos.z <= 0) continue;
            
            auto checker = false;
            ImVec2 screenPos = world2screen_c(playerpos, checker);
            if (!checker) continue;

            Vector3 playerpos_up = playerpos + Vector3(0, 1.9f, 0);
            Vector3 upper_pos = WorldToScreenPoint(camera, playerpos_up);
            if (upper_pos == Vector3(0, 0, 0) || upper_pos.z <= 0) continue;

            auto render = ImGui::GetBackgroundDrawList();
            if (!render) continue;

            int Height = upper_pos.y - lower_pos.y;
            if (Height <= 0) continue;
            
            int Width = Height * 0.6;
            if (Width <= 0) continue;

            auto distance = Vector3::Distance(viewpos, playerpos);

            float healthL = (float) health;

            const auto hayasaka = (clamp1<float>(healthL, 25, 75) - 25.f) / 50.f;
            auto hpcolor = ImColor(int(120 + 135 * (1 - hayasaka)), int(50.f + 175.f * hayasaka), 80);
            auto minhpcolor = ImColor(120 + 135, 50, 80);

            if (healthL > 100) {
                hpcolor = ImColor(100, 150, 255);
                minhpcolor = ImColor(100, 150, 255);
            }

            healthL = clamp1<float>(healthL, 0, 100);

            auto w2sC = world2screen_c(playerpos + Vector3(0, 0.9, 0), checker);
            auto w2sTop = world2screen_i(playerpos + Vector3(0, 1.9, 0));
            auto w2sBottom = world2screen_i(playerpos + Vector3(0, 0, 0));

            float pmtXtop = std::min(w2sTop.x, w2sBottom.x);
            float pmtXbottom = std::max(w2sTop.x, w2sBottom.x);

            if (upper_pos.z > 1.0f) {
                if (esp::player::line) {
                    ImVec2 lineStart = ImVec2(menu::glWidth / 2, menu::glHeight / 2);
                    ImVec2 lineEnd = ImVec2(lower_pos.x, menu::glHeight - lower_pos.y);

                    if (esp::player::settings::lineoutline) {
                        render->AddLine(lineStart, lineEnd, ImColor(0, 0, 0), 2.5f);
                    }

                    if (esp::player::settings::lineRGB) {
                        render->AddLine(
                                lineStart,
                                lineEnd,
                                ImGui::ColorConvertFloat4ToU32(
                                        ImVec4(Rainbow::GetColor().x, Rainbow::GetColor().y,
                                               Rainbow::GetColor().z, 1.0f)),
                                1.2f
                        );
                    } else {
                        render->AddLine(
                                lineStart,
                                lineEnd,

                                ImGui::ColorConvertFloat4ToU32(colors::esp::player::lineColor)


                        );
                    }
                    if (esp::player::settings::lineglow) {
                        ImDesing::DrawLineGlowW(lineStart, lineEnd,
                                                colors::esp::player::lineColor, 2.5f, 10);
                    }
                }

                if (esp::player::skeleton) {
                    DrawSkeleton(Player, colors::esp::player::skeletonColor,
                                 esp::player::settings::skeletonoutline);
                }

                if (esp::player::circle) {
                        Draw3DCircle_esp(render, Player, camera, playerpos, menu::glHeight, ImGui::GetIO().DeltaTime);
                    }

                    if (esp::player::box) {

                        ImU32 fillColor = ImGui::ColorConvertFloat4ToU32(
                                ImVec4(fillColorVec.x, fillColorVec.y, fillColorVec.z, fillAlpha));

                        float radius = esp::player::settings::boxCorner
                                       ? esp::player::settings::cornerRadius : 0.0f;

                        if (esp::player::settings::boxfilled) {
                            render->AddRectFilled(
                                    ImVec2(upper_pos.x - (Width / 2),
                                           menu::glHeight - upper_pos.y),
                                    ImVec2(upper_pos.x + (Width / 2),
                                           menu::glHeight - upper_pos.y + Height),
                                    fillColor, radius
                            );
                        }


                        if (esp::player::settings::boxgradient) {
                            if (esp::player::settings::boxGradientRGB) {
                                ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(
                                        ImVec2(upper_pos.x - Width / 2,
                                               menu::glHeight - upper_pos.y),
                                        ImVec2(upper_pos.x + Width / 2,
                                               menu::glHeight - upper_pos.y + Height),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 0)),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 0)),
                                        fillColor,
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(Rainbow::GetColor().x,
                                                                              Rainbow::GetColor().y,
                                                                              Rainbow::GetColor().z *
                                                                              0.78f,
                                                                              0.74f))
                                );
                            } else {
                                ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(
                                        ImVec2(upper_pos.x - Width / 2,
                                               menu::glHeight - upper_pos.y),
                                        ImVec2(upper_pos.x + Width / 2,
                                               menu::glHeight - upper_pos.y + Height),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 0)),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 0)),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(
                                                colors::esp::player::boxColor[0] * 0.5f,
                                                colors::esp::player::boxColor[1] * 0.5f,
                                                colors::esp::player::boxColor[2] * 0.5f,
                                                fillAlpha
                                        )),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(
                                                colors::esp::player::boxColor[0] * 0.5f,
                                                colors::esp::player::boxColor[1] * 0.5f,
                                                colors::esp::player::boxColor[2] * 0.5f,
                                                fillAlpha
                                        ))
                                );
                            }
                        }
                        if (esp::player::settings::boxglow) {
                            ImDesing::DrawRectGlow(
                                    ImVec2(upper_pos.x - (Width / 2), menu::glHeight - upper_pos.y),
                                    ImVec2(upper_pos.x + (Width / 2),
                                           menu::glHeight - upper_pos.y + Height),
                                    ImVec4(colors::esp::player::boxColor[0],
                                           colors::esp::player::boxColor[1],
                                           colors::esp::player::boxColor[2], 1.0f),
                                    2, radius
                            );
                        } else {
                            if (esp::player::settings::boxoutline) {
                                render->AddRect(
                                        ImVec2(upper_pos.x - (Width / 2),
                                               menu::glHeight - upper_pos.y),
                                        ImVec2(upper_pos.x + (Width / 2),
                                               menu::glHeight - upper_pos.y + Height),
                                        ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1.0f)),
                                        radius, 0, 2.5f
                                );
                            }
                            render->AddRect(
                                    ImVec2(upper_pos.x - (Width / 2),
                                           menu::glHeight - upper_pos.y),
                                    ImVec2(upper_pos.x + (Width / 2),
                                           menu::glHeight - upper_pos.y + Height),
                                    esp::player::settings::boxRGB
                                    ? ImGui::ColorConvertFloat4ToU32(ImVec4(Rainbow::GetColor().x,
                                                                            Rainbow::GetColor().y,
                                                                            Rainbow::GetColor().z,
                                                                            1.0f))
                                    : ImGui::ColorConvertFloat4ToU32(ImVec4(
                                            colors::esp::player::boxColor[0],
                                            colors::esp::player::boxColor[1],
                                            colors::esp::player::boxColor[2],
                                            1.0f
                                    )),
                                    radius, 0, 1.2f
                            );
                        }

                    }

                    if (esp::player::chinahat) {
                        DrawChinaHat(Vector3(GetPlayerHead(Player).x,
                                             GetPlayerHead(Player).y + 0.22f,
                                             GetPlayerHead(Player).z), hatsegments,
                                     hatradius, ImVec4(colors::esp::player::chinahatColor[1],
                                                       colors::esp::player::chinahatColor[2],
                                                       colors::esp::player::chinahatColor[2],
                                                       hatalpha),
                                     colors::esp::player::chinahatColor);
                    }

                    if (esp::player::health) {
                        ImGui::PushFont(menu::general);
                        health = GetHealth(Player);
                        float boxHeight = abs(w2sTop.y - w2sBottom.y);
                        float barX = pmtXtop - abs(boxHeight / 4) - esphpsize / 2 - 10;
                        float barYTop = w2sTop.y;
                        float barYBottom = w2sBottom.y;
                        float healthPercentage = healthL / 100.0f;
                        float healthBarY = barYBottom - (barYBottom - barYTop) * healthPercentage;

                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(barX, barYBottom),
                                                                ImVec2(barX, barYTop),
                                                                ImColor(0, 0, 0, 120),
                                                                esphpsize + 2);

                        if (esp::player::settings::healthoutline) {
                            ImGui::GetBackgroundDrawList()->AddRect(
                                    ImVec2(barX - 1, barYTop - 1),
                                    ImVec2(barX + esphpsize + 1,
                                           barYBottom + 1),
                                    ImColor(0, 0, 0, 200), 0, 0, 1);
                        }

                        if (!esp::player::settings::healthgradient) {
                            if (esp::player::settings::healthglow) {
                                ImDesing::DrawLineGlowW(ImVec2(barX, barYBottom),
                                                        ImVec2(barX, healthBarY),
                                                        colors::esp::player::healthColor,
                                                        esphpsize,
                                                        15 + esphpsize);
                            } else {
                                ImGui::GetBackgroundDrawList()->AddLine(
                                        ImVec2(barX, barYBottom),
                                        ImVec2(barX, healthBarY),
                                        ImGui::ColorConvertFloat4ToU32(
                                                colors::esp::player::healthColor),
                                        esphpsize);
                            }
                        } else {
                            ImU32 gradientStart = ImGui::ColorConvertFloat4ToU32(
                                    colors::esp::player::healthGradientStartColor);
                            ImU32 gradientEnd = ImGui::ColorConvertFloat4ToU32(
                                    colors::esp::player::healthGradientEndColor);
                            ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(
                                    ImVec2(barX, barYBottom),
                                    ImVec2(barX + esphpsize, healthBarY),
                                    gradientStart, gradientStart, gradientEnd, gradientEnd);
                        }

                        if (health < 90 || health > 100) {
                            ImVec2 healthTextPos = ImVec2(barX - ImGui::CalcTextSize(
                                    std::to_string(health).c_str()).x / 2, healthBarY -
                                                                           ImGui::CalcTextSize(
                                                                                   std::to_string(
                                                                                           health).c_str()).y /
                                                                           2);

                            for (int dx = -1; dx <= 1; dx += 2) {
                                for (int dy = -1; dy <= 1; dy += 2) {
                                    ImGui::GetBackgroundDrawList()->AddText(
                                            healthTextPos + ImVec2(dx, dy),
                                            ImColor(0, 0, 0, 200),
                                            std::to_string(health).c_str());
                                }
                            }
                            ImGui::GetBackgroundDrawList()->AddText(healthTextPos,
                                                                    ImColor(255, 255, 255),
                                                                    std::to_string(
                                                                            health).c_str());

                        }
                        ImGui::PopFont();
                    }

                    if (esp::player::nickname) {
                        ImGui::PushFont(menu::general);
                        std::string displayName = OBFUSCATE("t.me/MamixCheats");

                        if (esp::player::settings::nicknameoutline) {
                            ImGui::GetBackgroundDrawList()->AddText(
                                    ImVec2(upper_pos.x - ImGui::CalcTextSize(displayName.c_str()).x / 2,
                                           menu::glHeight - upper_pos.y - 15),
                                    ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)),
                                    displayName.c_str());
                        }
                        ImGui::GetBackgroundDrawList()->AddText(
                                ImVec2(upper_pos.x - 1 - ImGui::CalcTextSize(displayName.c_str()).x / 2,
                                       menu::glHeight - upper_pos.y - 14),
                                ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)),
                                displayName.c_str());
                        ImGui::PopFont();
                    }

                    if (esp::player::distance) {
                        float mOffset = 0;
                        if (esp::player::money) {
                            mOffset = 12.5;
                        } else {
                            mOffset = 0;
                        }
                        ImGui::PushFont(menu::pixel);
                        std::string dist = (std::to_string((int) distance) +
                                            "m");
                        if (esp::player::settings::distanceoutline) {
                            ImGui::GetBackgroundDrawList()->AddText(
                                    ImGui::GetFont(),
                                    ImGui::GetFontSize() + esphptextsize,
                                    ImVec2(pmtXbottom +
                                           abs((w2sTop.y - w2sBottom.y) / 4) +
                                           8 - 1,
                                           w2sTop.y + mOffset - 1),
                                    ImColor(0, 0, 0, 200),
                                    dist.c_str());
                            ImGui::GetBackgroundDrawList()->AddText(
                                    ImGui::GetFont(),
                                    ImGui::GetFontSize() + esphptextsize,
                                    ImVec2(pmtXbottom +
                                           abs((w2sTop.y - w2sBottom.y) / 4) +
                                           8 - 1,
                                           w2sTop.y + mOffset + 1),
                                    ImColor(0, 0, 0, 200),
                                    dist.c_str());
                            ImGui::GetBackgroundDrawList()->AddText(
                                    ImGui::GetFont(),
                                    ImGui::GetFontSize() + esphptextsize,
                                    ImVec2(pmtXbottom +
                                           abs((w2sTop.y - w2sBottom.y) / 4) +
                                           8 + 1,
                                           w2sTop.y + mOffset - 1),
                                    ImColor(0, 0, 0, 200),
                                    dist.c_str());
                            ImGui::GetBackgroundDrawList()->AddText(
                                    ImGui::GetFont(),
                                    ImGui::GetFontSize() + esphptextsize,
                                    ImVec2(pmtXbottom +
                                           abs((w2sTop.y - w2sBottom.y) / 4) +
                                           8 + 1,
                                           w2sTop.y + mOffset + 1),
                                    ImColor(0, 0, 0, 200),
                                    dist.c_str());
                        }

                        ImGui::GetBackgroundDrawList()->AddText(
                                ImGui::GetFont(),
                                ImGui::GetFontSize() + esphptextsize,
                                ImVec2(pmtXbottom +
                                       abs((w2sTop.y - w2sBottom.y) / 4) + 8,
                                       w2sTop.y + mOffset),
                                ImColor(255, 255, 255, 255),
                                dist.c_str());
                        ImGui::PopFont();
                    }

                    if (esp::player::weapon) {
                        Il2CppString* pixelWeaponName = GetWeaponId(Player);
                    if (!pixelWeaponName) continue;
                    
                        std::string weaponid_str = getWeaponString(Player);
                    if (weaponid_str.empty()) continue;

                        const char* iconWeaponId = weaponid_str.c_str();
                    if (!iconWeaponId) continue;

                        float centerX = pmtXtop + (pmtXbottom - pmtXtop) / 2;
                    if (centerX <= 0) continue;

                        ImGui::PushFont(menu::pixel);
                    if (!ImGui::GetFont()) {
                        ImGui::PopFont();
                        continue;
                    }
                        std::string pixelName = pixelWeaponName->CString();
                        ImVec2 pixelTextSize = ImGui::CalcTextSize(pixelName.c_str());
                        float pixelTextX = centerX - pixelTextSize.x / 2;
                        float pixelTextY = w2sBottom.y + 2; // ближе к иконке

                        if (esp::player::settings::weaponoutline) {
                            ImDrawList* drawList = ImGui::GetBackgroundDrawList();
                            ImColor outlineColor(0, 0, 0, 200);
                            for (int dx = -1; dx <= 1; dx++) {
                                for (int dy = -1; dy <= 1; dy++) {
                                    if (dx != 0 || dy != 0) {
                                        drawList->AddText(
                                                menu::pixel,
                                                ImGui::GetFontSize(),
                                                ImVec2(pixelTextX + dx, pixelTextY + dy),
                                                outlineColor,
                                                pixelName.c_str()
                                        );
                                    }
                                }
                            }
                        }

                        ImGui::GetBackgroundDrawList()->AddText(
                                menu::pixel,
                                ImGui::GetFontSize(),
                                ImVec2(pixelTextX, pixelTextY),
                                ImColor(255, 255, 255, 255),
                                pixelName.c_str()
                        );
                        ImGui::PopFont();

                        ImGui::PushFont(menu::weapon);
                        ImVec2 weaponTextSize = ImGui::CalcTextSize(iconWeaponId);
                        float weaponTextX = centerX - weaponTextSize.x / 2;
                        float weaponTextY = pixelTextY + pixelTextSize.y + 1; // ближе к тексту над иконкой

                        if (esp::player::settings::weaponoutline) {
                            ImDrawList* drawList = ImGui::GetBackgroundDrawList();
                            ImColor outlineColor(0, 0, 0, 200);
                            for (int dx = -1; dx <= 1; dx++) {
                                for (int dy = -1; dy <= 1; dy++) {
                                    if (dx != 0 || dy != 0) {
                                        drawList->AddText(
                                                menu::weapon,
                                                ImGui::GetFontSize() + esphptextsize,
                                                ImVec2(weaponTextX + dx, weaponTextY + dy),
                                                outlineColor,
                                                iconWeaponId
                                        );
                                    }
                                }
                            }
                        }

                        ImGui::GetBackgroundDrawList()->AddText(
                                menu::weapon,
                                ImGui::GetFontSize() + esphptextsize,
                                ImVec2(weaponTextX, weaponTextY),
                                ImColor(255, 255, 255, 255),
                                iconWeaponId
                        );
                        ImGui::PopFont();
                }
            }
        }
    }
}