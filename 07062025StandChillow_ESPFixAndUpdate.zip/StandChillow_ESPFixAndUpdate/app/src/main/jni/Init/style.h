namespace Mamix {
    void theme() {
        ImGuiStyle &style = ImGui::GetStyle();
        style.WindowPadding = ImVec2(9.00f, 8.00f);
        style.FramePadding = ImVec2(6.00f, 5.00f);
        style.CellPadding = ImVec2(4.00f, 2.00f);
        style.ItemSpacing = ImVec2(8.00f, 4.00f);
        style.ItemInnerSpacing = ImVec2(4.00f, 4.00f);
        style.TouchExtraPadding = ImVec2(0.00f, 0.00f);
        style.IndentSpacing = 21.00f;
        style.ScrollbarSize = 7.00f;
        style.GrabMinSize = 10.00f;
        style.WindowBorderSize = 1.00f;
        style.ChildBorderSize = 1.00f;
        style.PopupBorderSize = 1.00f;
        style.FrameBorderSize = 0.00f;
        style.TabBorderSize = 0.00f;
        style.WindowRounding = 1.00f;
        style.ChildRounding = 6.00f;
        style.FrameRounding = 5.00f;
        style.PopupRounding = 5.00f;
        style.ScrollbarRounding = 5.00f;
        style.GrabRounding = 7.00f;
        style.LogSliderDeadzone = 6.00f;
        style.TabRounding = 7.00f;
        style.WindowTitleAlign = ImVec2(0.02f, 0.45f);
        style.WindowMenuButtonPosition = 0;
        style.ColorButtonPosition = 1;
        style.ButtonTextAlign = ImVec2(0.50f, 0.50f);
        style.SelectableTextAlign = ImVec2(0.00f, 0.00f);
        style.DisplaySafeAreaPadding = ImVec2(3.00f, 3.00f);

        auto *colors = ImGui::GetStyle().Colors;
        colors[ImGuiCol_Text] = ImVec4(0.92f, 0.92f, 0.92f, 1.00f);
        colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
        colors[ImGuiCol_WindowBg] = ImVec4(0.05f, 0.05f, 0.05f, 0.94f);
        colors[ImGuiCol_ChildBg] = ImVec4(0.12f, 0.12f, 0.12f, 0.00f);
        colors[ImGuiCol_PopupBg] = ImVec4(0.10f, 0.10f, 0.10f, 0.94f);
        colors[ImGuiCol_Border] = ImVec4(0.18f, 0.35f, 0.58f, 0.50f); // Голубой
        colors[ImGuiCol_BorderShadow] = ImVec4(0.10f, 0.20f, 0.40f, 0.00f); // Голубой
        colors[ImGuiCol_FrameBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.54f);
        colors[ImGuiCol_FrameBgHovered] = ImVec4(0.09f, 0.09f, 0.09f, 0.40f);
        colors[ImGuiCol_FrameBgActive] = ImVec4(0.09f, 0.09f, 0.09f, 0.67f);
        colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
        colors[ImGuiCol_TitleBgActive] = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
        colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.16f, 0.16f, 0.16f, 0.51f);
        colors[ImGuiCol_MenuBarBg] = ImVec4(0.07f, 0.07f, 0.07f, 1.00f);
        colors[ImGuiCol_ScrollbarBg] = ImVec4(0.07f, 0.07f, 0.07f, 0.53f);
        colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.18f, 0.35f, 0.58f, 1.00f); // Голубой
        colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f); // Голубой
        colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.30f, 0.60f, 1.00f, 0.68f); // Голубой
        colors[ImGuiCol_CheckMark] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f); // Голубой
        colors[ImGuiCol_SliderGrab] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f); // Голубой
        colors[ImGuiCol_SliderGrabActive] = ImVec4(0.30f, 0.60f, 1.00f, 1.00f); // Голубой
        colors[ImGuiCol_Button] = ImVec4(0.26f, 0.59f, 0.98f, 0.40f); // Голубой
        colors[ImGuiCol_ButtonHovered] = ImVec4(0.30f, 0.60f, 1.00f, 1.00f); // Голубой
        colors[ImGuiCol_ButtonActive] = ImVec4(0.20f, 0.50f, 0.90f, 1.00f); // Голубой
        colors[ImGuiCol_Header] = ImVec4(0.00f, 0.00f, 0.00f, 0.31f);
        colors[ImGuiCol_HeaderHovered] = ImVec4(0.08f, 0.08f, 0.08f, 0.80f);
        colors[ImGuiCol_HeaderActive] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
        colors[ImGuiCol_Separator] = ImVec4(0.18f, 0.35f, 0.58f, 0.50f); // Голубой
        colors[ImGuiCol_SeparatorHovered] = ImVec4(0.13f, 0.13f, 0.13f, 0.78f);
        colors[ImGuiCol_SeparatorActive] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
        colors[ImGuiCol_ResizeGrip] = ImVec4(0.18f, 0.35f, 0.58f, 0.20f); // Голубой
        colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.26f, 0.59f, 0.98f, 0.67f); // Голубой
        colors[ImGuiCol_ResizeGripActive] = ImVec4(0.30f, 0.60f, 1.00f, 0.95f); // Голубой
        colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f); // Голубой
        colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.30f, 0.60f, 1.00f, 1.00f); // Голубой
        colors[ImGuiCol_TableRowBgAlt] = ImVec4(0.18f, 0.35f, 0.58f, 0.06f); // Голубой
        colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f); // Голубой
        colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f); // Голубой
    }

    const std::string currentDateTime() {
        time_t now = time(0);
        struct tm tstruct;
        char buft[80];
        tstruct = *localtime(&now);
        strftime(buft, sizeof(buft), "%H:%M", &tstruct);
        return buft;
    }

    void drawWater() {
        if (key != "" && isValid) {
            std::string baseText = OBFUSCATE("t.me/MamixCheats | ");
            std::string keyTime = getCachedKeyTime(key);
            ImVec2 baseTextSize = ImGui::CalcTextSize(baseText.c_str());
            ImVec2 keyTimeSize = ImGui::CalcTextSize(keyTime.c_str());
            float totalTextWidth = baseTextSize.x + keyTimeSize.x;
            float startX = menu::glWidth - totalTextWidth - 30.0f;  // 15 pixels from the right
            float startY = menu::glHeight - baseTextSize.y - 15.0f;  // 15 pixels from the bottom
            ImU32 textColor = keyExpired ? IM_COL32(255, 0, 0, 255) : IM_COL32(0, 255, 0, 255);

            ImGui::GetForegroundDrawList()->AddText(ImVec2(startX, startY),
                                                    IM_COL32(255, 255, 255, 255), baseText.c_str());
            ImGui::GetForegroundDrawList()->AddText(ImVec2(startX + baseTextSize.x, startY),
                                                    textColor, keyTime.c_str());
        }
    }

    void Watermark() {
        auto draw_list = ImGui::GetForegroundDrawList();
        std::string cheatname, paid, free, beta, datatime, mynameplayer, myping, myfps;
        int FPS = ImGui::GetIO().Framerate;
        datatime = currentDateTime();
        auto watertext0 = std::string(
                OBFUSCATE("t.me/MamixCheats | "));

        auto watertext = std::string(watertext0
                + datatime + " | fps: " + std::to_string(FPS) + " ").c_str();

        ImVec2 watersize = ImGui::CalcTextSize(watertext);
        ImGui::SetNextWindowSize(ImVec2(watersize.x + 10, watersize.y * 2 - 6));
        ImGui::SetNextWindowPos(ImVec2(30, 15));

        ImGui::Begin("##dadada", NULL, ImGuiWindowFlags_NoScrollWithMouse |
                                       ImGuiWindowFlags_NoDecoration |
                                       ImGuiWindowFlags_NoBackground);

        ImU32 linecolor, glowcolorfirst;
        if (watermarkRainbow) {
            ImVec4 rainbowColor = Rainbow::GetColor();
            linecolor = ImColor(rainbowColor.x, rainbowColor.y, rainbowColor.z, rainbowColor.w);
            glowcolorfirst = linecolor;
        } else {
            linecolor = ImColor(watermark_accent);
            glowcolorfirst = linecolor;
        }

        auto waterpos = ImGui::GetWindowPos();
        auto backcolor = ImColor(0, 0, 0, 145);
        auto textcolor = ImColor(watertext_accent);
        auto glowcolorsecond = ImColor(0, 0, 0, 0);

        draw_list->AddRectFilled(waterpos, ImVec2(waterpos.x + watersize.x + 10, waterpos.y + watersize.y * 2 - 6), backcolor);
        draw_list->AddRectFilled(waterpos, ImVec2(waterpos.x + watersize.x + 10, waterpos.y + 2), linecolor);
        draw_list->AddText(ImVec2(waterpos.x + 5, waterpos.y + watersize.y / 2 - 2), textcolor, watertext);
        draw_list->AddRectFilledMultiColor(waterpos, ImVec2(waterpos.x + watersize.x + 10, waterpos.y + watersize.y),
                                           glowcolorfirst, glowcolorfirst, glowcolorsecond, glowcolorsecond);

        ImGui::End();
    }


}

