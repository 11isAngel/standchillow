/*
  ________  ________  ________   ________ ___  ________
|\   ____\|\   __  \|\   ___  \|\  _____\\  \|\   ____\
\ \  \___|\ \  \|\  \ \  \\ \  \ \  \__/\ \  \ \  \___|
 \ \  \    \ \  \\\  \ \  \\ \  \ \   __\\ \  \ \  \  ___
  \ \  \____\ \  \\\  \ \  \\ \  \ \  \_| \ \  \ \  \|\  \
   \ \_______\ \_______\ \__\\ \__\ \__\   \ \__\ \_______\
    \|_______|\|_______|\|__| \|__|\|__|    \|__|\|_______|
                                   By @destroyhack 19.12.24
 */


using namespace std;
using json = Json::json;

static const string WAY_FOR_CFG = "/storage/emulated/0/Android/data/com.Chillow.StandChillowRework/";
static const string TYPE_CFG = ".json";

void saveCFG(int configNumber) {
    json jsonFile;

    jsonFile["esp"] = {
            {"enable", esp::player::enable},
            {"box", esp::player::box},
            {"skeleton", esp::player::skeleton},
            {"chinahat", esp::player::chinahat},
            {"nickname", esp::player::nickname},
            {"distance", esp::player::distance},
            {"money", esp::player::money},
            {"weapon", esp::player::weapon},
            {"health", esp::player::health},
            {"line", esp::player::line},
            {"circle", esp::player::circle}
    };

    jsonFile["esp"]["settings"] = {
            {"boxRGB", esp::player::settings::boxRGB},
            {"lineRGB", esp::player::settings::lineRGB},
            {"boxGradientRGB", esp::player::settings::boxGradientRGB},
            {"boxoutline", esp::player::settings::boxoutline},
            {"lineoutline", esp::player::settings::lineoutline},
            {"distanceoutline", esp::player::settings::distanceoutline},
            {"boxgradient", esp::player::settings::boxgradient},
            {"moneyoutline", esp::player::settings::moneyoutline},
            {"weaponoutline", esp::player::settings::weaponoutline},
            {"healthoutline", esp::player::settings::healthoutline},
            {"skeletonoutline", esp::player::settings::skeletonoutline},
            {"healthglow", esp::player::settings::healthglow},
            {"healthgradient", esp::player::settings::healthgradient},
            {"boxfilled", esp::player::settings::boxfilled},
            {"boxCorner", esp::player::settings::boxCorner},
            {"boxglow", esp::player::settings::boxglow},
            {"nicknameoutline", esp::player::settings::nicknameoutline}
    };

    jsonFile["colors"] = {
            {"skyColor", {skyColor.x, skyColor.y, skyColor.z, skyColor.w}},
            {"lineColor", {colors::esp::player::lineColor.x, colors::esp::player::lineColor.y, colors::esp::player::lineColor.z, colors::esp::player::lineColor.w}},
            {"skeletonColor", {colors::esp::player::skeletonColor.x, colors::esp::player::skeletonColor.y, colors::esp::player::skeletonColor.z, colors::esp::player::skeletonColor.w}},
            {"chinahatColor", {colors::esp::player::chinahatColor[0], colors::esp::player::chinahatColor[1], colors::esp::player::chinahatColor[2]}},
            {"boxColor", {colors::esp::player::boxColor[0], colors::esp::player::boxColor[1], colors::esp::player::boxColor[2]}},
            {"circleColor", {colors::esp::player::circleColor.x, colors::esp::player::circleColor.y, colors::esp::player::circleColor.z, colors::esp::player::circleColor.w}},
            {"healthGradientStartColor", {colors::esp::player::healthGradientStartColor.x, colors::esp::player::healthGradientStartColor.y, colors::esp::player::healthGradientStartColor.z, colors::esp::player::healthGradientStartColor.w}},
            {"healthGradientEndColor", {colors::esp::player::healthGradientEndColor.x, colors::esp::player::healthGradientEndColor.y, colors::esp::player::healthGradientEndColor.z, colors::esp::player::healthGradientEndColor.w}},
            {"healthColor", {colors::esp::player::healthColor.x, colors::esp::player::healthColor.y, colors::esp::player::healthColor.z, colors::esp::player::healthColor.w}}
    };

    jsonFile["generalSettings"] = {
            {"skyEnable", skyEnable},
            {"skyRainbow", skyRainbow},
            {"antiwinct", antiwinct},
            {"antigodmode", antigodmode},
            {"AutoWinCT", AutoWinCT},
            {"AutoWinT", AutoWinT},
            {"triggerbot", triggerbot},
            {"drawfovtrigger", drawfovtrigger},
            {"circleRGBt", circleRGBt},
            {"circleOutlinet", circleOutlinet},
            {"aimclrt", {aimclrt.x, aimclrt.y, aimclrt.z, aimclrt.w}},
            {"triggerfov", triggerfov},
            {"silentaim", silentaim},
            {"drawfov", drawfov},
            {"nicknamespoof", nicknamespoof},
            {"airJump", airJump},
            {"currentgloves", currentgloves},
            {"grenade_type", grenade_type},
            {"nuke", nuke},
            {"nuke_me", nuke_me},
            {"nuke_enemy", nuke_enemy},
            {"nuke_team", nuke_team},
            { "JumpCircle", JumpCircle },
            { "pulsejumpc", pulsejumpc },
            { "glowjumpc", glowjumpc },
            { "pulsecolorc", pulsecolorc },
            { "radiusc", radiusc },
            { "thiknessc", thiknessc },
            { "silentfovsize", silentfovsize },
            { "lineglow", lineglow },
            { "bunnyvalue", bunnyvalue },
            { "invsi", invsi },
            { "movebef", movebef },
            { "infdrop", infdrop },
            { "speedvalue", speedvalue },
            { "speedhack", speedhack },
            { "fovFeature", fovFeature },
            {
                    "watermark_accent", {watermark_accent.x, watermark_accent.y, watermark_accent.z,
                                                          watermark_accent.w}
            },
            {
                    "watertext_accent", {watertext_accent.x, watertext_accent.y, watertext_accent.z,
                                                          watertext_accent.w}
            },
            { "watermarkRainbow", watermarkRainbow },
            { "fovValue", fovValue },
            { "showm", showm },
            { "test", test },
            { "pup", pup },
            { "bunnyhop", bunnyhop },
            { "noclip", noclip },
            { "telekill", telekill },
            { "masskill", masskill },
            { "traceEnable", traceEnable },
            { "traceRainbow", traceRainbow },
            { "traceColor", {traceColor[0], traceColor[1], traceColor[2], traceColor[3]}},
            { "traceTriple", traceTriple },
            { "traceLine", traceLine },
            { "enemyscale", enemyscale },
            { "RCS", norecoil },
            { "infammo", infammo },
            { "firerate", firerate },
            { "visible", visible },
            { "ArmPos", ArmPos },
            { "xx", xx },
            { "yy", yy },
            { "zz", zz },
            { "espstroke", espstroke },
            { "scalex", scalex },
            { "scaley", scaley },
            { "scalez", scalez },
            { "esphptextsize", esphptextsize },
            { "circleOutlines", circleOutlines },
            { "circleRGBs", circleRGBs },
            { "esphpsize", esphpsize },
            { "ESP", ESP },
            { "hatalpha", hatalpha },
            { "hatradius", hatradius },
            { "hatsegments", hatsegments },
            { "slaim", slaim },
            { "circleRGB", circleRGB },
            { "circleOutline", circleOutline },
            { "silentfov", silentfov },
            { "silentfill", silentfill },
            { "silentgradient", silentgradient },
            { "silentvis", silentvis },
            { "ifvisibleaim", ifvisibleaim },
            { "jumpRGB", jumpRGB },
            { "jumpcclr", {jumpcclr.x, jumpcclr.y, jumpcclr.z, jumpcclr.w}},
            { "silentaimclr", {silentaimclr.x, silentaimclr.y, silentaimclr.z, silentaimclr.w}},
            { "aimclr", {aimclr.x, aimclr.y, aimclr.z, aimclr.w}},
            { "stopm", stopm },
            { "fastm", fastm },
            { "ThirdPerson", ThirdPerson },
            { "thirdfloat", thirdfloat },
            { "hostme", hostme },
            { "destroyenemy", destroyenemy },
            { "aim", aim },
            { "aimbot_visiblecheck", aimbot_visiblecheck },
            { "aimbotfov", aimbotfov },
            { "jitterspeed", jitterspeed },
            { "aastatic", aastatic },
            { "aajitter", aajitter },
            { "aastaticxpos", aastaticxpos },
            { "aastaticypos", aastaticypos },
            { "aastaticzpos", aastaticzpos },
            { "fly", fly },
            { "flyspeed", flyspeed },
            { "antiaim", antiaim },
            { "x2", x2 },
            { "y2", y2 },
            { "z2", z2 },
            { "opacityChams", opacityChams },
            { "flatChams", flatChams },
            { "flatChamsColor", {flatChamsColor.x, flatChamsColor.y, flatChamsColor.z, flatChamsColor.w} },
            { "flatChamsRainbow", flatChamsRainbow },
            { "flatChamsPulse", flatChamsPulse },
            { "flatChamsWallhack", flatChamsWallhack },

            { "texturedChams", texturedChams },
            { "visibleTexturedChamsColor", {visibleTexturedChamsColor.x, visibleTexturedChamsColor.y, visibleTexturedChamsColor.z, visibleTexturedChamsColor.w} },
            { "invisibleTexturedChamsColor", {invisibleTexturedChamsColor.x, invisibleTexturedChamsColor.y, invisibleTexturedChamsColor.z, invisibleTexturedChamsColor.w} },
            { "visibleTexturedChamsRainbow", visibleTexturedChamsRainbow },
            { "invisibleTexturedChamsRainbow", invisibleTexturedChamsRainbow },
            { "visibleTexturedChamsPulse", visibleTexturedChamsPulse },
            { "invisibleTexturedChamsPulse", invisibleTexturedChamsPulse },

            { "wireframeChams", wireframeChams },
            { "wireframeChamsColor", {wireframeChamsColor.x, wireframeChamsColor.y, wireframeChamsColor.z, wireframeChamsColor.w} },
            { "wireframeChamsRainbow", wireframeChamsRainbow },
            { "wireframeChamsPulse", wireframeChamsPulse },
            { "wireframeWallhackChams", wireframeWallhackChams },
            { "wireframeWidthChams", wireframeWidthChams },

            { "shadingChams", shadingChams },
            { "shadingChamsColor", {shadingChamsColor.x, shadingChamsColor.y, shadingChamsColor.z, shadingChamsColor.w} },
            { "shadingWallhackChams", shadingWallhackChams },

            { "outlineChams", outlineChams },
            { "outlineChamsColor", {outlineChamsColor.x, outlineChamsColor.y, outlineChamsColor.z, outlineChamsColor.w} },
            { "outlineChamsRainbow", outlineChamsRainbow },
            { "outlineChamsPulse", outlineChamsPulse },
            { "outlineWallhackChams", outlineWallhackChams },
            { "outlineWidthChams", outlineWidthChams },

            { "glowChams", glowChams },
            { "glowChamsColor", {glowChamsColor.x, glowChamsColor.y, glowChamsColor.z, glowChamsColor.w} },
            { "glowChamsRainbow", glowChamsRainbow },
            { "glowChamsPulse", glowChamsPulse },

            { "nightmode", nightmode },
            { "worldChamsColor", {worldChamsColor.x, worldChamsColor.y, worldChamsColor.z, worldChamsColor.w} },
            { "worldChamsRainbow", worldChamsRainbow },
            { "worldChamsPulse", worldChamsPulse },

            { "fillColorVec", {fillColorVec.x, fillColorVec.y, fillColorVec.z, fillColorVec.w} },
            { "fillAlpha", fillAlpha },
            { "wallshot", wallshot },
            {"snowflakes", snowflakes},
            {"esppreview", esppreview},
            {"open4", open4},
            {"v1", v1},
            {"open5", open5},
            {"buttonp", buttonp},
            {"linep", linep},
            {"shopanywhere", shopanywhere},
            {"buyhack", buyhack},
            {"spoofid", spoofid},
            {"windowWidth", windowWidth},
            {"windowHeight", windowHeight},
            {"selectedConfigIndex", selectedConfigIndex},
            {"selectedLanguage", selectedLanguage},
            {"radarhack", radarhack},
            {"antigrenade", antigrenade}
    };
    string filename = WAY_FOR_CFG + "config_" + to_string(configNumber) + TYPE_CFG;
    if (!filesystem::exists(WAY_FOR_CFG)) {
        LOGE(OBFUSCATE("FILE NOT EXIST"));
        return;
    }

    ofstream file(filename);
    if (file.is_open()) {
        file << jsonFile.dump(4);
        file.close();
        LOGI(OBFUSCATE("Saved"));
    } else {
        LOGE(OBFUSCATE("Error4"));
    }
}

void loadCFG(int configNumber) {
    string filename = WAY_FOR_CFG + "config_" + to_string(configNumber) + TYPE_CFG;

    if (!filesystem::exists(filename)) {
        LOGI(OBFUSCATE("file not exits"));
        return;
    }

    ifstream file(filename);
    if (file.is_open()) {
        json jsonFile;
        file >> jsonFile;
        file.close();

        esp::player::enable = jsonFile["esp"]["enable"];
        esp::player::box = jsonFile["esp"]["box"];
        esp::player::skeleton = jsonFile["esp"]["skeleton"];
        esp::player::chinahat = jsonFile["esp"]["chinahat"];
        esp::player::nickname = jsonFile["esp"]["nickname"];
        esp::player::distance = jsonFile["esp"]["distance"];
        esp::player::money = jsonFile["esp"]["money"];
        esp::player::weapon = jsonFile["esp"]["weapon"];
        esp::player::health = jsonFile["esp"]["health"];
        esp::player::line = jsonFile["esp"]["line"];
        esp::player::circle = jsonFile["esp"]["circle"];

        esp::player::settings::boxRGB = jsonFile["esp"]["settings"]["boxRGB"];
        esp::player::settings::lineRGB = jsonFile["esp"]["settings"]["lineRGB"];
        esp::player::settings::boxGradientRGB = jsonFile["esp"]["settings"]["boxGradientRGB"];
        esp::player::settings::boxoutline = jsonFile["esp"]["settings"]["boxoutline"];
        esp::player::settings::lineoutline = jsonFile["esp"]["settings"]["lineoutline"];
        esp::player::settings::distanceoutline = jsonFile["esp"]["settings"]["distanceoutline"];
        esp::player::settings::boxgradient = jsonFile["esp"]["settings"]["boxgradient"];
        esp::player::settings::moneyoutline = jsonFile["esp"]["settings"]["moneyoutline"];
        esp::player::settings::weaponoutline = jsonFile["esp"]["settings"]["weaponoutline"];
        esp::player::settings::healthoutline = jsonFile["esp"]["settings"]["healthoutline"];
        esp::player::settings::skeletonoutline = jsonFile["esp"]["settings"]["skeletonoutline"];
        esp::player::settings::healthglow = jsonFile["esp"]["settings"]["healthglow"];
        esp::player::settings::healthgradient = jsonFile["esp"]["settings"]["healthgradient"];
        esp::player::settings::boxfilled = jsonFile["esp"]["settings"]["boxfilled"];
        esp::player::settings::boxCorner = jsonFile["esp"]["settings"]["boxCorner"];
        esp::player::settings::boxglow = jsonFile["esp"]["settings"]["boxglow"];
        esp::player::settings::nicknameoutline = jsonFile["esp"]["settings"]["nicknameoutline"];

        colors::esp::player::lineColor = ImVec4(jsonFile["colors"]["lineColor"][0], jsonFile["colors"]["lineColor"][1], jsonFile["colors"]["lineColor"][2], jsonFile["colors"]["lineColor"][3]);
        colors::esp::player::skeletonColor = ImVec4(jsonFile["colors"]["skeletonColor"][0], jsonFile["colors"]["skeletonColor"][1], jsonFile["colors"]["skeletonColor"][2], jsonFile["colors"]["skeletonColor"][3]);
        colors::esp::player::chinahatColor[0] = jsonFile["colors"]["chinahatColor"][0];
        colors::esp::player::chinahatColor[1] = jsonFile["colors"]["chinahatColor"][1];
        colors::esp::player::chinahatColor[2] = jsonFile["colors"]["chinahatColor"][2];
        colors::esp::player::boxColor[0] = jsonFile["colors"]["boxColor"][0];
        colors::esp::player::boxColor[1] = jsonFile["colors"]["boxColor"][1];
        colors::esp::player::boxColor[2] = jsonFile["colors"]["boxColor"][2];
        colors::esp::player::circleColor = ImVec4(jsonFile["colors"]["circleColor"][0], jsonFile["colors"]["circleColor"][1], jsonFile["colors"]["circleColor"][2], jsonFile["colors"]["circleColor"][3]);
        colors::esp::player::healthGradientStartColor = ImVec4(jsonFile["colors"]["healthGradientStartColor"][0], jsonFile["colors"]["healthGradientStartColor"][1], jsonFile["colors"]["healthGradientStartColor"][2], jsonFile["colors"]["healthGradientStartColor"][3]);
        colors::esp::player::healthGradientEndColor = ImVec4(jsonFile["colors"]["healthGradientEndColor"][0], jsonFile["colors"]["healthGradientEndColor"][1], jsonFile["colors"]["healthGradientEndColor"][2], jsonFile["colors"]["healthGradientEndColor"][3]);
        colors::esp::player::healthColor = ImVec4(jsonFile["colors"]["healthColor"][0], jsonFile["colors"]["healthColor"][1], jsonFile["colors"]["healthColor"][2], jsonFile["colors"]["healthColor"][3]);

        skyColor = ImVec4(jsonFile["colors"]["skyColor"][0], jsonFile["colors"]["skyColor"][1], jsonFile["colors"]["skyColor"][2], jsonFile["colors"]["skyColor"][3]);
        skyEnable = jsonFile["generalSettings"]["skyEnable"];
        skyRainbow = jsonFile["generalSettings"]["skyRainbow"];
        antiwinct = jsonFile["generalSettings"]["antiwinct"];
        antigodmode = jsonFile["generalSettings"]["antigodmode"];
        AutoWinCT = jsonFile["generalSettings"]["AutoWinCT"];
        AutoWinT = jsonFile["generalSettings"]["AutoWinT"];

        triggerbot = jsonFile["generalSettings"]["triggerbot"];
        drawfovtrigger = jsonFile["generalSettings"]["drawfovtrigger"];
        circleRGBt = jsonFile["generalSettings"]["circleRGBt"];
        circleOutlinet = jsonFile["generalSettings"]["circleOutlinet"];
        silentaim = jsonFile["generalSettings"]["silentaim"];
        drawfov = jsonFile["generalSettings"]["drawfov"];
        nicknamespoof = jsonFile["generalSettings"]["nicknamespoof"];
        airJump = jsonFile["generalSettings"]["airJump"];
        currentgloves = jsonFile["generalSettings"]["currentgloves"];
        grenade_type = jsonFile["generalSettings"]["grenade_type"];
        nuke = jsonFile["generalSettings"]["nuke"];
        nuke_me = jsonFile["generalSettings"]["nuke_me"];
        nuke_enemy = jsonFile["generalSettings"]["nuke_enemy"];
        nuke_team = jsonFile["generalSettings"]["nuke_team"];
        JumpCircle = jsonFile["generalSettings"]["JumpCircle"];
        pulsejumpc = jsonFile["generalSettings"]["pulsejumpc"];
        glowjumpc = jsonFile["generalSettings"]["glowjumpc"];
        pulsecolorc = jsonFile["generalSettings"]["pulsecolorc"];
        radiusc = jsonFile["generalSettings"]["radiusc"];
        thiknessc = jsonFile["generalSettings"]["thiknessc"];
        silentfovsize = jsonFile["generalSettings"]["silentfovsize"];
        lineglow = jsonFile["generalSettings"]["lineglow"];
        bunnyvalue = jsonFile["generalSettings"]["bunnyvalue"];
        infdrop = jsonFile["generalSettings"]["infdrop"];
        triggerfov = jsonFile["generalSettings"]["triggerfov"];
        speedvalue = jsonFile["generalSettings"]["speedvalue"];
        speedhack = jsonFile["generalSettings"]["speedhack"];
        fovFeature = jsonFile["generalSettings"]["fovFeature"];
        watermark_accent = ImVec4(jsonFile["generalSettings"]["watermark_accent"][0], jsonFile["generalSettings"]["watermark_accent"][1], jsonFile["generalSettings"]["watermark_accent"][2], jsonFile["generalSettings"]["watermark_accent"][3]);
        watertext_accent = ImVec4(jsonFile["generalSettings"]["watertext_accent"][0], jsonFile["generalSettings"]["watertext_accent"][1], jsonFile["generalSettings"]["watertext_accent"][2], jsonFile["generalSettings"]["watertext_accent"][3]);
        watermarkRainbow = jsonFile["generalSettings"]["watermarkRainbow"];
        fovValue = jsonFile["generalSettings"]["fovValue"];
        showm = jsonFile["generalSettings"]["showm"];
        test = jsonFile["generalSettings"]["test"];
        pup = jsonFile["generalSettings"]["pup"];
        bunnyhop = jsonFile["generalSettings"]["bunnyhop"];
        noclip = jsonFile["generalSettings"]["noclip"];
        telekill = jsonFile["generalSettings"]["telekill"];
        traceEnable = jsonFile["generalSettings"]["traceEnable"];
        traceRainbow = jsonFile["generalSettings"]["traceRainbow"];
        traceColor[0] = jsonFile["generalSettings"]["traceColor"][0];
        traceColor[1] = jsonFile["generalSettings"]["traceColor"][1];
        traceColor[2] = jsonFile["generalSettings"]["traceColor"][2];
        traceColor[3] = jsonFile["generalSettings"]["traceColor"][3];
        traceTriple = jsonFile["generalSettings"]["traceTriple"];
        traceLine = jsonFile["generalSettings"]["traceLine"];
        norecoil = jsonFile["generalSettings"]["RCS"];
        infammo = jsonFile["generalSettings"]["infammo"];
        firerate = jsonFile["generalSettings"]["firerate"];
        visible = jsonFile["generalSettings"]["visible"];
        ArmPos = jsonFile["generalSettings"]["ArmPos"];
        xx = jsonFile["generalSettings"]["xx"];
        yy = jsonFile["generalSettings"]["yy"];
        zz = jsonFile["generalSettings"]["zz"];
        espstroke = jsonFile["generalSettings"]["espstroke"];
        scalex = jsonFile["generalSettings"]["scalex"];
        scaley = jsonFile["generalSettings"]["scaley"];
        scalez = jsonFile["generalSettings"]["scalez"];
        esphptextsize = jsonFile["generalSettings"]["esphptextsize"];
        circleOutlines = jsonFile["generalSettings"]["circleOutlines"];
        circleRGBs = jsonFile["generalSettings"]["circleRGBs"];
        esphpsize = jsonFile["generalSettings"]["esphpsize"];
        ESP = jsonFile["generalSettings"]["ESP"];
        hatalpha = jsonFile["generalSettings"]["hatalpha"];
        hatradius = jsonFile["generalSettings"]["hatradius"];
        hatsegments = jsonFile["generalSettings"]["hatsegments"];
        slaim = jsonFile["generalSettings"]["slaim"];
        circleRGB = jsonFile["generalSettings"]["circleRGB"];
        circleOutline = jsonFile["generalSettings"]["circleOutline"];
        silentfov = jsonFile["generalSettings"]["silentfov"];
        silentfill = jsonFile["generalSettings"]["silentfill"];
        silentgradient = jsonFile["generalSettings"]["silentgradient"];
        silentvis = jsonFile["generalSettings"]["silentvis"];
        ifvisibleaim = jsonFile["generalSettings"]["ifvisibleaim"];
        jumpRGB = jsonFile["generalSettings"]["jumpRGB"];
        jumpcclr = ImVec4(jsonFile["generalSettings"]["jumpcclr"][0], jsonFile["generalSettings"]["jumpcclr"][1], jsonFile["generalSettings"]["jumpcclr"][2], jsonFile["generalSettings"]["jumpcclr"][3]);
        silentaimclr = ImVec4(jsonFile["generalSettings"]["silentaimclr"][0], jsonFile["generalSettings"]["silentaimclr"][1], jsonFile["generalSettings"]["silentaimclr"][2], jsonFile["generalSettings"]["silentaimclr"][3]);
        aimclr = ImVec4(jsonFile["generalSettings"]["aimclr"][0], jsonFile["generalSettings"]["aimclr"][1], jsonFile["generalSettings"]["aimclr"][2], jsonFile["generalSettings"]["aimclr"][3]);
        aimclrt = ImVec4(jsonFile["generalSettings"]["aimclrt"][0], jsonFile["generalSettings"]["aimclrt"][1], jsonFile["generalSettings"]["aimclrt"][2], jsonFile["generalSettings"]["aimclrt"][3]);
        stopm = jsonFile["generalSettings"]["stopm"];
        fastm = jsonFile["generalSettings"]["fastm"];
        ThirdPerson = jsonFile["generalSettings"]["ThirdPerson"];
        thirdfloat = jsonFile["generalSettings"]["thirdfloat"];
        hostme = jsonFile["generalSettings"]["hostme"];
        destroyenemy = jsonFile["generalSettings"]["destroyenemy"];
        aim = jsonFile["generalSettings"]["aim"];
        aimbot_visiblecheck = jsonFile["generalSettings"]["aimbot_visiblecheck"];
        aimbotfov = jsonFile["generalSettings"]["aimbotfov"];
        jitterspeed = jsonFile["generalSettings"]["jitterspeed"];
        aastatic = jsonFile["generalSettings"]["aastatic"];
        aajitter = jsonFile["generalSettings"]["aajitter"];
        aastaticxpos = jsonFile["generalSettings"]["aastaticxpos"];
        aastaticypos = jsonFile["generalSettings"]["aastaticypos"];
        aastaticzpos = jsonFile["generalSettings"]["aastaticzpos"];
        fly = jsonFile["generalSettings"]["fly"];
        flyspeed = jsonFile["generalSettings"]["flyspeed"];
        antiaim = jsonFile["generalSettings"]["antiaim"];
        x2 = jsonFile["generalSettings"]["x2"];
        y2 = jsonFile["generalSettings"]["y2"];
        z2 = jsonFile["generalSettings"]["z2"];
        opacityChams = jsonFile["generalSettings"]["opacityChams"];
        flatChams = jsonFile["generalSettings"]["flatChams"];
        flatChamsColor = ImVec4(jsonFile["generalSettings"]["flatChamsColor"][0], jsonFile["generalSettings"]["flatChamsColor"][1], jsonFile["generalSettings"]["flatChamsColor"][2], jsonFile["generalSettings"]["flatChamsColor"][3]);
        flatChamsRainbow = jsonFile["generalSettings"]["flatChamsRainbow"];
        flatChamsPulse = jsonFile["generalSettings"]["flatChamsPulse"];
        flatChamsWallhack = jsonFile["generalSettings"]["flatChamsWallhack"];

        texturedChams = jsonFile["generalSettings"]["texturedChams"];
        visibleTexturedChamsColor = ImVec4(jsonFile["generalSettings"]["visibleTexturedChamsColor"][0], jsonFile["generalSettings"]["visibleTexturedChamsColor"][1], jsonFile["generalSettings"]["visibleTexturedChamsColor"][2], jsonFile["generalSettings"]["visibleTexturedChamsColor"][3]);
        invisibleTexturedChamsColor = ImVec4(jsonFile["generalSettings"]["invisibleTexturedChamsColor"][0], jsonFile["generalSettings"]["invisibleTexturedChamsColor"][1], jsonFile["generalSettings"]["invisibleTexturedChamsColor"][2], jsonFile["generalSettings"]["invisibleTexturedChamsColor"][3]);
        visibleTexturedChamsRainbow = jsonFile["generalSettings"]["visibleTexturedChamsRainbow"];
        invisibleTexturedChamsRainbow = jsonFile["generalSettings"]["invisibleTexturedChamsRainbow"];
        visibleTexturedChamsPulse = jsonFile["generalSettings"]["visibleTexturedChamsPulse"];
        invisibleTexturedChamsPulse = jsonFile["generalSettings"]["invisibleTexturedChamsPulse"];

        wireframeChams = jsonFile["generalSettings"]["wireframeChams"];
        wireframeChamsColor = ImVec4(jsonFile["generalSettings"]["wireframeChamsColor"][0], jsonFile["generalSettings"]["wireframeChamsColor"][1], jsonFile["generalSettings"]["wireframeChamsColor"][2], jsonFile["generalSettings"]["wireframeChamsColor"][3]);
        wireframeChamsRainbow = jsonFile["generalSettings"]["wireframeChamsRainbow"];
        wireframeChamsPulse = jsonFile["generalSettings"]["wireframeChamsPulse"];
        wireframeWallhackChams = jsonFile["generalSettings"]["wireframeWallhackChams"];
        wireframeWidthChams = jsonFile["generalSettings"]["wireframeWidthChams"];

        shadingChams = jsonFile["generalSettings"]["shadingChams"];
        shadingChamsColor = ImVec4(jsonFile["generalSettings"]["shadingChamsColor"][0], jsonFile["generalSettings"]["shadingChamsColor"][1], jsonFile["generalSettings"]["shadingChamsColor"][2], jsonFile["generalSettings"]["shadingChamsColor"][3]);
        shadingWallhackChams = jsonFile["generalSettings"]["shadingWallhackChams"];

        outlineChams = jsonFile["generalSettings"]["outlineChams"];
        outlineChamsColor = ImVec4(jsonFile["generalSettings"]["outlineChamsColor"][0], jsonFile["generalSettings"]["outlineChamsColor"][1], jsonFile["generalSettings"]["outlineChamsColor"][2], jsonFile["generalSettings"]["outlineChamsColor"][3]);
        outlineChamsRainbow = jsonFile["generalSettings"]["outlineChamsRainbow"];
        outlineChamsPulse = jsonFile["generalSettings"]["outlineChamsPulse"];
        outlineWallhackChams = jsonFile["generalSettings"]["outlineWallhackChams"];
        outlineWidthChams = jsonFile["generalSettings"]["outlineWidthChams"];

        glowChams = jsonFile["generalSettings"]["glowChams"];
        glowChamsColor = ImVec4(jsonFile["generalSettings"]["glowChamsColor"][0], jsonFile["generalSettings"]["glowChamsColor"][1], jsonFile["generalSettings"]["glowChamsColor"][2], jsonFile["generalSettings"]["glowChamsColor"][3]);
        glowChamsRainbow = jsonFile["generalSettings"]["glowChamsRainbow"];
        glowChamsPulse = jsonFile["generalSettings"]["glowChamsPulse"];

        nightmode = jsonFile["generalSettings"]["nightmode"];
        worldChamsColor = ImVec4(jsonFile["generalSettings"]["worldChamsColor"][0], jsonFile["generalSettings"]["worldChamsColor"][1], jsonFile["generalSettings"]["worldChamsColor"][2], jsonFile["generalSettings"]["worldChamsColor"][3]);
        worldChamsRainbow = jsonFile["generalSettings"]["worldChamsRainbow"];
        worldChamsPulse = jsonFile["generalSettings"]["worldChamsPulse"];

        fillColorVec = ImVec4(jsonFile["generalSettings"]["fillColorVec"][0], jsonFile["generalSettings"]["fillColorVec"][1], jsonFile["generalSettings"]["fillColorVec"][2], jsonFile["generalSettings"]["fillColorVec"][3]);
        fillAlpha = jsonFile["generalSettings"]["fillAlpha"];
        esp::player::circle = jsonFile["esp"]["circle"];
        colors::esp::player::circleColor = ImVec4(jsonFile["colors"]["circleColor"][0], jsonFile["colors"]["circleColor"][1], jsonFile["colors"]["circleColor"][2], jsonFile["colors"]["circleColor"][3]);

        snowflakes = jsonFile["generalSettings"]["snowflakes"];
        esppreview = jsonFile["generalSettings"]["esppreview"];
        open4 = jsonFile["generalSettings"]["open4"];
        v1 = jsonFile["generalSettings"]["v1"];
        open5 = jsonFile["generalSettings"]["open5"];
        buttonp = jsonFile["generalSettings"]["buttonp"];
        linep = jsonFile["generalSettings"]["linep"];
        shopanywhere = jsonFile["generalSettings"]["shopanywhere"];
        spoofid = jsonFile["generalSettings"]["spoofid"];
        windowWidth = jsonFile["generalSettings"]["windowWidth"];
        windowHeight = jsonFile["generalSettings"]["windowHeight"];
        selectedConfigIndex = jsonFile["generalSettings"]["selectedConfigIndex"];
        selectedLanguage = jsonFile["generalSettings"]["selectedLanguage"];
        radarhack = jsonFile["generalSettings"]["radarhack"];
        antigrenade = jsonFile["generalSettings"]["antigrenade"];\

        if (key.starts_with(OBFUSCATE("PREMIUM_"))) {
            wallshot = jsonFile["generalSettings"]["wallshot"];
            buyhack = jsonFile["generalSettings"]["buyhack"];
            masskill = jsonFile["generalSettings"]["masskill"];
            enemyscale = jsonFile["generalSettings"]["enemyscale"];
            invsi = jsonFile["generalSettings"]["invsi"];
            movebef = jsonFile["generalSettings"]["movebef"];
        }

        LOGE(OBFUSCATE("LOADED"));
    } else {
        LOGE(OBFUSCATE("Error5"));
    }
}
