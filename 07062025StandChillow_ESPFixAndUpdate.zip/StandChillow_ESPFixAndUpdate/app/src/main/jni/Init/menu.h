inline GLuint LoadEspPreviewTexture() {
    static GLuint texture = 0;
    static bool loaded = false;

    if (!loaded) {
        int width, height;
        unsigned char* pixels = stbi_load_from_memory(
                _espPreview,
                _espPreview_size,
                &width,
                &height,
                nullptr,
                4
        );

        if (pixels) {
            glGenTextures(1, &texture);
            glBindTexture(GL_TEXTURE_2D, texture);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0,
                         GL_RGBA, GL_UNSIGNED_BYTE, pixels);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            stbi_image_free(pixels);
            loaded = true;
        }
    }
    return texture;
}

enum styleindx {
    DARK = 0,
    LIGHT = 1
};

void setStyle(styleindx style) {
    if (style == DARK) {
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 10.0f;
        style.FrameRounding = 10.3f;
        style.ScrollbarRounding = 4.0;
        style.TabBorderSize = 0.0f;

        auto &colors = ImGui::GetStyle().Colors;
        colors[ImGuiCol_WindowBg] = ImVec4{0.1f, 0.1f, 0.13f, 1.0f};
        colors[ImGuiCol_MenuBarBg] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_Border] = ImVec4{0.44f, 0.37f, 0.61f, 0.29f};
        colors[ImGuiCol_BorderShadow] = ImVec4{0.0f, 0.0f, 0.0f, 0.24f};
        colors[ImGuiCol_Text] = ImVec4{1.0f, 1.0f, 1.0f, 1.0f};
        colors[ImGuiCol_TextDisabled] = ImVec4{0.5f, 0.5f, 0.5f, 1.0f};
        colors[ImGuiCol_Header] = ImVec4{0.13f, 0.13f, 0.17, 1.0f};
        colors[ImGuiCol_HeaderHovered] = ImVec4{0.19f, 0.2f, 0.25f, 1.0f};
        colors[ImGuiCol_HeaderActive] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_Button] = ImVec4{0.13f, 0.13f, 0.17, 1.0f};
        colors[ImGuiCol_ButtonHovered] = ImVec4{0.19f, 0.2f, 0.25f, 1.0f};
        colors[ImGuiCol_ButtonActive] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_CheckMark] = ImVec4{0.74f, 0.58f, 0.98f, 1.0f};
        colors[ImGuiCol_PopupBg] = ImVec4{0.1f, 0.1f, 0.13f, 0.92f};
        colors[ImGuiCol_SliderGrab] = ImVec4{0.44f, 0.37f, 0.61f, 0.54f};
        colors[ImGuiCol_SliderGrabActive] = ImVec4{0.74f, 0.58f, 0.98f, 0.54f};
        colors[ImGuiCol_FrameBg] = ImVec4{0.13f, 0.13, 0.17, 1.0f};
        colors[ImGuiCol_FrameBgHovered] = ImVec4{0.19f, 0.2f, 0.25f, 1.0f};
        colors[ImGuiCol_FrameBgActive] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_Tab] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_TabHovered] = ImVec4{0.24, 0.24f, 0.32f, 1.0f};
        colors[ImGuiCol_TabActive] = ImVec4{0.2f, 0.22f, 0.27f, 1.0f};
        colors[ImGuiCol_TabUnfocused] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_TabUnfocusedActive] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_TitleBg] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_TitleBgActive] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_TitleBgCollapsed] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_ScrollbarBg] = ImVec4{0.1f, 0.1f, 0.13f, 1.0f};
        colors[ImGuiCol_ScrollbarGrab] = ImVec4{0.16f, 0.16f, 0.21f, 1.0f};
        colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4{0.19f, 0.2f, 0.25f, 1.0f};
        colors[ImGuiCol_ScrollbarGrabActive] = ImVec4{0.24f, 0.24f, 0.32f, 1.0f};
        colors[ImGuiCol_Separator] = ImVec4{0.44f, 0.37f, 0.61f, 1.0f};
        colors[ImGuiCol_SeparatorHovered] = ImVec4{0.74f, 0.58f, 0.98f, 1.0f};
        colors[ImGuiCol_SeparatorActive] = ImVec4{0.84f, 0.58f, 1.0f, 1.0f};
        colors[ImGuiCol_ResizeGrip] = ImVec4{0.44f, 0.37f, 0.61f, 0.29f};
        colors[ImGuiCol_ResizeGripHovered] = ImVec4{0.74f, 0.58f, 0.98f, 0.29f};
        colors[ImGuiCol_ResizeGripActive] = ImVec4{0.84f, 0.58f, 1.0f, 0.29f};

    } else if (style == LIGHT) {
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 7.0f;
        style.FrameRounding = 2.3f;
        style.ScrollbarRounding = 4.0;
        style.TabBorderSize = 0.0f;

        auto &colors = ImGui::GetStyle().Colors;
        colors[ImGuiCol_WindowBg] = ImVec4{1.0f, 1.0f, 1.0f, 1.0f};
        colors[ImGuiCol_MenuBarBg] = ImVec4{0.96f, 0.96f, 0.96f, 1.0f};
        colors[ImGuiCol_Border] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_BorderShadow] = ImVec4{0.0f, 0.0f, 0.0f, 0.0f};
        colors[ImGuiCol_Text] = ImVec4{0.0f, 0.0f, 0.0f, 1.0f};
        colors[ImGuiCol_TextDisabled] = ImVec4{0.5f, 0.5f, 0.5f, 1.0f};
        colors[ImGuiCol_Header] = ImVec4{0.9f, 0.9f, 0.9f, 1.0f};
        colors[ImGuiCol_HeaderHovered] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_HeaderActive] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_Button] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_ButtonHovered] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_ButtonActive] = ImVec4{0.7f, 0.7f, 0.7f, 1.0f};
        colors[ImGuiCol_CheckMark] = ImVec4{0.44f, 0.58f, 0.98f, 1.0f};
        colors[ImGuiCol_PopupBg] = ImVec4{1.0f, 1.0f, 1.0f, 0.92f};
        colors[ImGuiCol_SliderGrab] = ImVec4{0.7f, 0.7f, 0.8f, 0.7f};
        colors[ImGuiCol_SliderGrabActive] = ImVec4{0.44f, 0.58f, 0.98f, 0.7f};
        colors[ImGuiCol_FrameBg] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_FrameBgHovered] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_FrameBgActive] = ImVec4{0.7f, 0.7f, 0.7f, 1.0f};
        colors[ImGuiCol_Tab] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_TabHovered] = ImVec4{0.9f, 0.9f, 0.9f, 1.0f};
        colors[ImGuiCol_TabActive] = ImVec4{0.85f, 0.85f, 0.85f, 1.0f};
        colors[ImGuiCol_TabUnfocused] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_TabUnfocusedActive] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_TitleBg] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_TitleBgActive] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_TitleBgCollapsed] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_ScrollbarBg] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_ScrollbarGrab] = ImVec4{0.75f, 0.75f, 0.75f, 1.0f};
        colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_ScrollbarGrabActive] = ImVec4{0.9f, 0.9f, 0.9f, 1.0f};
        colors[ImGuiCol_Separator] = ImVec4{0.8f, 0.8f, 0.8f, 1.0f};
        colors[ImGuiCol_SeparatorHovered] = ImVec4{0.9f, 0.9f, 0.9f, 1.0f};
        colors[ImGuiCol_SeparatorActive] = ImVec4{1.0f, 1.0f, 1.0f, 1.0f};
        colors[ImGuiCol_ResizeGrip] = ImVec4{0.75f, 0.75f, 0.75f, 0.29f};
        colors[ImGuiCol_ResizeGripHovered] = ImVec4{0.8f, 0.8f, 0.8f, 0.29f};
        colors[ImGuiCol_ResizeGripActive] = ImVec4{0.9f, 0.9f, 0.9f, 0.29f};
    }
}

void RenderSnowFlakes() {
    if (!snowflakes) return;

    static int snowflakesCount = 0;
    static float timer = 0.0f;
    static std::vector<ImVec2> snowflakePositions;
    static std::vector<float> snowflakeSizes;
    static std::vector<float> snowflakeVelocities;

    timer += ImGui::GetIO().DeltaTime;
    if (timer > 0.6f) {
        snowflakePositions.push_back(ImVec2(rand() % (int)ImGui::GetIO().DisplaySize.x, 0));
        snowflakeSizes.push_back((float)(rand() % 5 + 1));
        snowflakeVelocities.push_back((rand() % 50 + 50) / 100.0f);
        snowflakesCount++;
        timer = 0.0f;
    }

    for (int i = 0; i < snowflakesCount; ++i) {
        ImVec2& position = snowflakePositions[i];
        float size = snowflakeSizes[i];
        float velocity = snowflakeVelocities[i];

        position.y += velocity * ImGui::GetIO().DeltaTime * 100.0f;
        ImGui::GetForegroundDrawList()->AddCircleFilled(position, size, ImColor(255, 255, 255));

        if (position.y > ImGui::GetIO().DisplaySize.y) {
            snowflakePositions.erase(snowflakePositions.begin() + i);
            snowflakeSizes.erase(snowflakeSizes.begin() + i);
            snowflakeVelocities.erase(snowflakeVelocities.begin() + i);
            snowflakesCount--;
            i--;
        }
    }
}

#define min(x,y) ((x)<(y)?x:y)
#define wh(a) ImColor(1.f,1.f,1.f,a)
void FX(ImDrawList* d, ImVec2 a, ImVec2 b, ImVec2 sz, float t) {
    static float fl;
    if ((rand() % 600) == 0) fl = t;
    if ((t - fl) > 0) { auto ft = 0.25f; }
    for (int i = 0; i < 2000; ++i) {
        unsigned h = ImGui::GetID(d + i + int(t / 4));
        auto f = fmodf(t + fmodf(h / 777.f, 99), 99);
        auto tx = h % (int) sz.x;
        auto ty = h % (int) sz.y;
        if (f < 1) {
            auto py = ty - 1000 * (1 - f);
            d->AddLine({a.x + tx, a.y + py}, {a.x + tx, a.y + min(py + 10, ty)}, (ImU32) -1);
        } else if (f < 1.2f)
            d->AddCircle({a.x + tx, a.y + ty}, (f - 1) * 10 + h % 5, wh(1 - (f - 1) * 5.f));
    }
}
void ShowSubscribeWindow() {
    ImGui::SetNextWindowPos(ImVec2(menu::glWidth / 2 - 250, menu::glHeight / 2 - 125));
    ImGui::SetNextWindowSize(ImVec2(500, 250), ImGuiCond_Once);

    if (ImGui::Begin(OBFUSCATE("  Выполните действия!"), nullptr, ImGuiWindowFlags_NoCollapse)) {
        RectangleShadowSettings shadowSettings;
        shadowSettings.rectSize = ImVec2(ImGui::GetWindowSize().x, ImGui::GetWindowSize().y);
        shadowSettings.sigma = 10;
        shadowSettings.padding = ImVec2(0, 0);
        shadowSettings.rectPos = shadowSettings.padding;
        shadowSettings.rings = 10;
        shadowSettings.spacingBetweenRings = 5;
        shadowSettings.samplesPerCornerSide = 20;
        shadowSettings.spacingBetweenSamples = 15;
        shadowSettings.shadowColor = ImVec4(1.0f, 1.0f, 1.0f, 0.33f);
        shadowSettings.shadowSize = ImVec2(15, 15);

        drawRectangleShadowVerticesAdaptive(shadowSettings);

        ImGui::Text(OBFUSCATE("Что-бы играть с софтом нужно подписаться\n на канал"));
        ImGui::Dummy(ImVec2(0, 20));

        float width = ImGui::GetContentRegionAvail().x;

        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.0f, 0.5f, 1.0f, 1.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 2.0f);

        if (ImGui::Button("Подписаться", ImVec2(width, 0))) {
            ImGui::SetNextWindowSize({windowWidth, windowHeight});
            ImGui::SetNextWindowPos(
                    {(menu::glWidth - windowWidth) / 2.0f, (menu::glHeight - windowHeight) / 2.0f});
            char command[256];
            snprintf(command, sizeof(command), "am start -a android.intent.action.VIEW -d %s", "https://t.me/MamixCheats");
            system(command);
            open5 = true;
        }

        ImGui::PopStyleVar();
        ImGui::PopStyleColor();
    }
    ImGui::End();
}

void RenderEspPreview() {
    if (esppreview) {
        ImGui::SetNextWindowSize(ImVec2(650, 816), ImGuiCond_Once);
        if (ImGui::Begin("Esp Preview", nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse)) {
            ImGui::Image((void*)(intptr_t)LoadEspPreviewTexture(), ImVec2(550, 716));
        }
        ImGui::End();
    }
}

void R3nderMenu() {
    RenderEspPreview();
    if (open4 && v1 == false && !key.empty()) {
        RenderSnowFlakes();
        auto* colors = ImGui::GetStyle().Colors;
        std::string djsorrow = OBFUSCATE("t.me/MamixCheats | StandChillow | ");

        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowBorderSize = 1.0f;
        style.Colors[ImGuiCol_Border] = ImVec4(1, 1, 1, 1);

        ImGui::Begin(std::string(djsorrow + ver).c_str(), nullptr, ImGuiWindowFlags_NoCollapse);

        RectangleShadowSettings shadowSettings;
        shadowSettings.rectSize = ImVec2(ImGui::GetWindowSize().x, ImGui::GetWindowSize().y);
        shadowSettings.sigma = 10;
        shadowSettings.padding = ImVec2(0, 0);
        shadowSettings.rectPos = shadowSettings.padding;
        shadowSettings.rings = 10;
        shadowSettings.spacingBetweenRings = 5;
        shadowSettings.samplesPerCornerSide = 20;
        shadowSettings.spacingBetweenSamples = 15;
        shadowSettings.shadowColor = ImVec4(1.0f, 1.0f, 1.0f, 0.33f);
        shadowSettings.shadowSize = ImVec2(15, 15);
        drawRectangleShadowVerticesAdaptive(shadowSettings);

        ImGui::BeginChild(OBFUSCATE("##leftChild"), ImVec2(ImGui::GetWindowSize().x / 6.25f, ImGui::GetContentRegionAvail().y));

        static int currentPage = 0;
        static int targetPage = 0;
        static float animProgress = 1.0f;
        static float prevAnimProgress = 1.0f;
        const float animDuration = 0.25f;
        static bool isTransitioning = false;
        float dt = ImGui::GetIO().DeltaTime;

        auto easeInOutCubic = [](float t) {
            return t < 0.5f ? 4 * t * t * t : 1 - pow(-2 * t + 2, 3) / 2;
        };

        if (currentPage != targetPage) {
            isTransitioning = true;
            prevAnimProgress = animProgress;
            animProgress = 0.0f;
            currentPage = targetPage;
        }

        if (isTransitioning) {
            animProgress += dt / animDuration;
            if (animProgress >= 1.0f) {
                animProgress = 1.0f;
                isTransitioning = false;
            }
        }

        ImGui::PushFont(menu::icons);

        auto renderTabButton = [&](const char* icon, int pageIndex) {
            bool isSelected = (targetPage == pageIndex);
            if (isSelected) {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.4f, 0.7f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.3f, 0.5f, 0.8f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.25f, 0.45f, 0.75f, 1.0f));
            }

            if (ImGui::Button(icon, ImVec2(120, 120))) {
                if (targetPage != pageIndex && !isTransitioning) {
                    targetPage = pageIndex;
                }
            }

            if (isSelected) {
                ImGui::PopStyleColor(3);

                ImVec2 lineStart = ImGui::GetItemRectMin();
                ImVec2 lineEnd = ImVec2(lineStart.x + 120, lineStart.y);
            }
        };

        renderTabButton(ICON_FA_USER, 0);
        renderTabButton(ICON_FA_EYE, 1);
        renderTabButton(ICON_FA_EYE_DROPPER, 2);
        renderTabButton(ICON_FA_GEAR, 3);

        ImGui::PopFont();
        ImGui::EndChild();

        ImGui::SameLine();
        ImGui::BeginChild(OBFUSCATE("##rightChild"), ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y));

        float easedProgress = easeInOutCubic(animProgress);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, easedProgress);

        if (currentPage == 0) {
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("Weapon"), OBFUSCATE("Оружие")))) {
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("WallShot"), OBFUSCATE("Стрельба через стены")), &wallshot);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("NoRecoil"), OBFUSCATE("Без отдачи")), &norecoil);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("FireRate"), OBFUSCATE("Скорострельность")), &firerate);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("InfAmmo"), OBFUSCATE("Бесконечные патроны")), &infammo);
                ImGui::Text(GetLang(OBFUSCATE("Thanks for playing with our software!"), OBFUSCATE("Спасибо за игру с нашим софтом!")));
            }
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("Main"), OBFUSCATE("Основное")))) {
                if (!key.starts_with(OBFUSCATE("PREMIUM_"))) {
                    ImGui::Text(GetLang(OBFUSCATE(
                                                "Want to play with more features?\nBuy a premium key that will last forever!"),
                                        OBFUSCATE(
                                                "Хотите играть с большим количеством функций?\nПокупайте премиум ключ который будет навсегда!")));
                    if (ImGui::Button(GetLang(OBFUSCATE("Buy!"), OBFUSCATE("Купить!")))) {
                        openUrlInBrowser(OBFUSCATE("https://t.me/standknife_key_bot"));
                    }
                }
                if (key.starts_with(OBFUSCATE("PREMIUM_"))) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Invisible"), OBFUSCATE("Невидимость")), &invsi);
                    if (invsi) {
                        hexPatches.invisibles.Modify();
                    } else {
                        hexPatches.invisibles.Restore();
                    }

                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Move before timer"), OBFUSCATE("Движение до таймера")), &movebef);
                    if (movebef) {
                        hexPatches.movebefore.Modify();
                    } else {
                        hexPatches.movebefore.Restore();
                    }
                    ImDesing::AnimatedCheckbox(GetLang("BigEnemy", "Большые противники"), &enemyscale);
                    if (enemyscale) {
                        ImGui::SliderInt(GetLang("X##bigenemy", "X##bigenemy"), &scalex, 1, 15);
                        ImGui::SliderInt(GetLang("Y##bigenemy", "Y##bigenemy"), &scaley, 1, 15);
                        ImGui::SliderInt(GetLang("Z##bigenemy", "Z##bigenemy"), &scalez, 1, 15);
                    }
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("RadarHack"), OBFUSCATE("Радар-хак")), &radarhack);
                if (radarhack) {
                    hexPatches.radar.Modify();
                } else {
                    hexPatches.radar.Restore();
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("AntiGrenade"), OBFUSCATE("Анти гранады")), &antigrenade);
                if (antigrenade) {
                    hexPatches.antig.Modify();
                } else {
                    hexPatches.antig.Restore();
                }
                /*ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Anti no-scope"), OBFUSCATE("Анти ноу-скоп")), &noscope);
                if (noscope) {
                    hexPatches.noscope.Modify();
                } else {
                    hexPatches.noscope.Restore();
                }*/
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Infinity grenades"), OBFUSCATE("Бесконеч. гранады")), &infgrenade);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Buy anywhere"), OBFUSCATE("Покупка везде")), &shopanywhere);
                if (shopanywhere) {
                    hexPatches.buyanywhct.Modify();
                    hexPatches.buyanywht.Modify();
                } else {
                    hexPatches.buyanywhct.Restore();
                    hexPatches.buyanywht.Restore();
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Shop hack"), OBFUSCATE("Взлом магазина")), &buyhack);
                if (buyhack) {
                    hexPatches.shophack.Modify();
                } else {
                    hexPatches.shophack.Restore();
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("InfinityDrop"), OBFUSCATE("Бесконечный выброс оружий")), &infdrop);
                if (infdrop) {
                    hexPatches.infinitydrop.Modify();
                } else {
                    hexPatches.infinitydrop.Restore();
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ArmsPosition"), OBFUSCATE("Позиция рук")), &ArmPos);
                if (ArmPos) {
                    ImGui::SliderFloat(GetLang(OBFUSCATE("X##armspos"), OBFUSCATE("X##armspos")), &xx, -300.f, 300.f);
                    ImGui::SliderFloat(GetLang(OBFUSCATE("Y##armspos"), OBFUSCATE("Y##armspos")), &yy, -300.f, 300.f);
                    ImGui::SliderFloat(GetLang(OBFUSCATE("Z##armspos"), OBFUSCATE("Z##armspos")), &zz, -300.f, 300.f);
                }

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("FovHack"), OBFUSCATE("Отдаление камеры")), &fovFeature);
                if (fovFeature) {
                    ImGui::SliderFloat(GetLang(OBFUSCATE(": Fov"), OBFUSCATE(": Fov")), &fovValue, 0.0f, 120.0f);
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Fly"), OBFUSCATE("Полёт")), &fly);
                if (fly) {
                    ImGui::SliderFloat(GetLang(OBFUSCATE(": Speed"), OBFUSCATE(": Скорость")), &flyspeed, 0.0f, 100.0f);
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ThirdPerson"), OBFUSCATE("3 Лицо")), &ThirdPerson);
                if (ThirdPerson) {
                    ImGui::SliderFloat(GetLang(OBFUSCATE(": Value"), OBFUSCATE(": Value")), &thirdfloat, 0.0f, 60.0f);
                }

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Bunnyhop"), OBFUSCATE("БанниХоп")), &bunnyhop);
                if (bunnyhop) {
                    ImGui::SliderFloat(GetLang(OBFUSCATE(": Value##speed"), OBFUSCATE(": Value##speed")), &bunnyvalue, 0.0f, 25.0f);
                }

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("AntiAim"), OBFUSCATE("Анти аим")), &antiaim);
                if (antiaim) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Static##antiaim"), OBFUSCATE("Статичный##antiaim")), &aastatic);
                    if (aastatic) {
                        aajitter = false;
                        ImGui::SliderFloat(GetLang(OBFUSCATE("X##antiaim"), OBFUSCATE("X##antiaim")), &aastaticxpos, -255, 255);
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Y##antiaim"), OBFUSCATE("Y##antiaim")), &aastaticypos, -255, 255);
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Z##antiaim"), OBFUSCATE("Z##antiaim")), &aastaticzpos, -255, 255);
                    }
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Better##antiaim"), OBFUSCATE("Динамичный##antiaim")), &aajitter);
                    if (aajitter) {
                        aastatic = false;
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Speed##antiaim"), OBFUSCATE("Speed##antiaim")), &jitterspeed, 0.0f, 80.0f);
                    }
                }

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Telekill"), OBFUSCATE("Телепортация себя к врагам")), &telekill);
                if (key.starts_with(OBFUSCATE("PREMIUM_"))) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Masskill"), OBFUSCATE("Телепортация врагов к себе")), &masskill);
                }
            }
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("SilentAim"), OBFUSCATE("Спокойный аим")))) {

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Enable##Silent"), OBFUSCATE("Включить##Silent")), &slaim);
                //    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Enable##aim"), OBFUSCATE("Включит##aim")), &aim);
                if (slaim) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Fov##Silent"), OBFUSCATE("Радиус##Silent")), &silentfov);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("RGB##Silent"), OBFUSCATE("Радужный##Silent")), &circleRGBs);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##Silent"), OBFUSCATE("Обводка##Silent")), &circleOutlines);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Fill##Silent"), OBFUSCATE("Запол.##Silent")), &silentfill);
                    ImGui::SameLine();
                    //ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Gradient##Silent"), OBFUSCATE("Градиент##Silent")), &silentgradient);
                    //mGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Visible check##Silent"), OBFUSCATE("Проверка видимости##Silent")), &silentvis);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##Silent"), OBFUSCATE("Цвет##Silent")), silentaimclr);
                    ImGui::SliderFloat(GetLang(OBFUSCATE("Aim Fov##Silent"), OBFUSCATE("Радиус прицеливания##Silent")), &silentfovsize, 5, 450);
                } else {
                    silentfov = false;
                }
            }

        }

        if (currentPage == 1) {
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("ESP"), OBFUSCATE("Есп")))) {
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Enable"), OBFUSCATE("Включить")), &esp::player::enable);
                if (esp::player::enable) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Line"), OBFUSCATE("ESP Line")), &esp::player::line);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##linecolor"), OBFUSCATE("Color##linecolor")),
                                          colors::esp::player::lineColor);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##line"), OBFUSCATE("Outline##line")),
                                               &esp::player::settings::lineoutline);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("RGB##line"), OBFUSCATE("RGB##line")), &esp::player::settings::lineRGB);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow##line"), OBFUSCATE("Glow##line")),
                                               &esp::player::settings::lineglow);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Box 2D"), OBFUSCATE("ESP Box 2D")), &esp::player::box);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##boxcolor"), OBFUSCATE("Color##boxcolor")),
                                          colors::esp::player::boxColor);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Fill##box2d"), OBFUSCATE("Fill##box2d")),
                                               &esp::player::settings::boxfilled);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##box2d"), OBFUSCATE("Outline##box2d")),
                                               &esp::player::settings::boxoutline);
                    if (esp::player::box) {
                        ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Gradient##box2d"), OBFUSCATE("Gradient##box2d")),
                                                   &esp::player::settings::boxgradient);
                        ImGui::SameLine();
                        ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("BoxRGB##box2d"), OBFUSCATE("BoxRGB##box2d")),
                                                   &esp::player::settings::boxRGB);
                        ImGui::SameLine();
                        ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("GradientRGB##box2d"), OBFUSCATE("GradientRGB##box2d")),
                                                   &esp::player::settings::boxGradientRGB);
                        ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow##box2d"), OBFUSCATE("Glow##box2d")),
                                                   &esp::player::settings::boxglow);
                        ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Corner##box2d"), OBFUSCATE("Corner##box2d")),
                                                   &esp::player::settings::boxCorner);

                        if (esp::player::settings::boxCorner)
                            ImGui::SliderFloat(GetLang(OBFUSCATE("Radius##box2d"), OBFUSCATE("Radius##box2d")),
                                               &esp::player::settings::cornerRadius, 1.0f,
                                               7.0f);

                    }
                    if (esp::player::settings::boxfilled) {
                        ImGui::Text(GetLang(OBFUSCATE("Fill"), OBFUSCATE("Заполнение")));
                        ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##fill"), OBFUSCATE("Цвет##fill")),
                                              fillColorVec);
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Alpha##box2d"), OBFUSCATE("Альфа##box2d")),
                                           &fillAlpha, 0.01f, 1.0f);
                    }
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Skeleton"), OBFUSCATE("ESP Skeleton")), &esp::player::skeleton);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##skeleton"), OBFUSCATE("Outline##skeleton")),
                                               &esp::player::settings::skeletonoutline);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##skeletoncolor"), OBFUSCATE("Цвет##skeletoncolor")),
                                          colors::esp::player::skeletonColor);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP ChinaHat"), OBFUSCATE("ESP ChinaHat")), &esp::player::chinahat);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##chinahatcolor"), OBFUSCATE("Цвет##chinahatcolor")),
                                          colors::esp::player::chinahatColor);
                    if (esp::player::chinahat) {
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Alpha##chinahat"), OBFUSCATE("Альфа##chinahat")), &hatalpha, 0.0f,
                                           0.255f);
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Size##chinahat"), OBFUSCATE("Размер##chinahat")), &hatradius, 0.20f,
                                           0.60f);
                        ImGui::SliderFloat(GetLang(OBFUSCATE("Segments##chinahat"), OBFUSCATE("Сегменты##chinahat")), &hatsegments, 10.0f,
                                           100.0f);


                    }
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Circle"), OBFUSCATE("ESP Circle")), &esp::player::circle);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##health"), OBFUSCATE("Цвет##health")),
                                          colors::esp::player::circleColor);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Nickname"), OBFUSCATE("ESP Nickname")), &esp::player::nickname);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##nickname"), OBFUSCATE("Outline##nickname")),
                                               &esp::player::settings::nicknameoutline);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Distance"), OBFUSCATE("ESP Distance")), &esp::player::distance);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##distance"), OBFUSCATE("Outline##distance")),
                                               &esp::player::settings::distanceoutline);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Weapon"), OBFUSCATE("ESP Weapon")), &esp::player::weapon);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##weapon"), OBFUSCATE("Outline##weapon")),
                                               &esp::player::settings::weaponoutline);
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("ESP Health"), OBFUSCATE("ESP Health")), &esp::player::health);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline##health"), OBFUSCATE("Outline##health")),
                                               &esp::player::settings::healthoutline);
                    ImGui::SameLine();
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow##health"), OBFUSCATE("Glow##health")),
                                               &esp::player::settings::healthglow);

                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Gradient##health"), OBFUSCATE("Gradient##health")),
                                               &esp::player::settings::healthgradient);

                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("Start##health"), OBFUSCATE("Начало##health")),
                                          colors::esp::player::healthGradientStartColor);
                    ImGui::SameLine();
                    ImDesing::ColorPicker(GetLang(OBFUSCATE("End##health"), OBFUSCATE("Конец##health")),
                                          colors::esp::player::healthGradientEndColor);

                }
            }
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("Chams"), OBFUSCATE("Чамсы")))) {

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Transparent mode"), OBFUSCATE("Прозрачный режим")), &opacityChams);

                /* ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Flat Chams"), OBFUSCATE("Плоские чамсы")), &flatChams);
                 ImGui::SameLine();
                 ImDesing::AddColorPicker(GetLang(OBFUSCATE("Color##flatChams"), OBFUSCATE("Цвет##flatChams")), *(ImVec4 *)&flatChamsColor, true,
                                         &flatChamsRainbow, &flatChamsPulse);
                 if (flatChams) {
                     ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Wallhack##flatChams"), OBFUSCATE("Wallhack##flatChams")), &flatChamsWallhack);
                 }*/

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Textured"), OBFUSCATE("Текстурированный")), &texturedChams);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Visible"), OBFUSCATE("Видимый")),
                                         *(ImVec4 *) &visibleTexturedChamsColor, true,
                                         &visibleTexturedChamsRainbow, &visibleTexturedChamsPulse);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Invisible"), OBFUSCATE("Невидимый")),
                                         *(ImVec4 *) &invisibleTexturedChamsColor, true,
                                         &invisibleTexturedChamsRainbow, &invisibleTexturedChamsPulse);

                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Wireframe"), OBFUSCATE("Каркас")), &wireframeChams);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Color##wireframe"), OBFUSCATE("Цвет##wireframe")),
                                         *(ImVec4 *) &wireframeChamsColor, true,
                                         &wireframeChamsRainbow, &wireframeChamsPulse);
                if (wireframeChams) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Wallhack##wireframe"), OBFUSCATE("Wallhack##wireframe")), &wireframeWallhackChams);
                    ImGui::SliderFloat(GetLang(OBFUSCATE("Width##wireframe"), OBFUSCATE("Ширина##wireframe")), &wireframeWidthChams, 1, 5,
                                       OBFUSCATE("%.1f"));
                }


                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Outline"), OBFUSCATE("Контур")), &outlineChams);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Color##outline"), OBFUSCATE("Цвет##outline")),
                                         *(ImVec4 *) &outlineChamsColor, true,
                                         &outlineChamsRainbow, &outlineChamsPulse);
                if (outlineChams) {
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Wallhack##outline"), OBFUSCATE("Wallhack##outline")), &outlineWallhackChams);
                    ImGui::SliderFloat(GetLang(OBFUSCATE("Width##outline"), OBFUSCATE("Ширина##outline")), &outlineWidthChams, 1, 5,
                                       OBFUSCATE("%.1f"));
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow"), OBFUSCATE("Глобальное освещение")), &glowChams);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Color##glow"), OBFUSCATE("Цвет##glow")),
                                         *(ImVec4 *) &glowChamsColor, true,
                                         &glowChamsRainbow, &glowChamsPulse);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("WorldColor"), OBFUSCATE("Мировой цвет")), &nightmode);
                ImGui::SameLine();
                ImDesing::AddColorPicker(GetLang(OBFUSCATE("Color##worldColor"), OBFUSCATE("Цвет##worldColor")),
                                         *(ImVec4 *) &worldChamsColor, true,
                                         &worldChamsRainbow, &worldChamsPulse);

            }
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("ColorSky"), OBFUSCATE("Цвет неба"))))
            {
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Enable##SkyColor"), OBFUSCATE("Включить##SkyColor")), &skyEnable);
                ImGui::SameLine();
                ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##SkyColor"), OBFUSCATE("Цвет##SkyColor")), skyColor);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Rgb##SkyColor"), OBFUSCATE("Радужный##SkyColor")), &skyRainbow);
            }
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("Other"), OBFUSCATE("Другое")))) {
                ImDesing::TextCentered(GetLang(OBFUSCATE("Player Line"), OBFUSCATE("Линия от игрока")));
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Enable##Player Line"), OBFUSCATE("Включить##Player Line")), &traceEnable);
                ImGui::SameLine();
                ImDesing::ColorPicker(GetLang(OBFUSCATE("Color##Player Line"), OBFUSCATE("Цвет##Player Line")), traceColor);
                if (ImGui::Button(GetLang(OBFUSCATE("Triangle"), OBFUSCATE("Треугольник")))) {
                    traceLine = false;
                    traceTriple = true;
                }
                ImGui::SameLine();
                if (ImGui::Button(GetLang(OBFUSCATE("Line"), OBFUSCATE("Линия")))) {
                    traceLine = true;
                    traceTriple = false;
                }
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow##Player Line"), OBFUSCATE("Глов##Player Line")), &lineglow);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Rgb##Player Line"), OBFUSCATE("Радужный##Player Line")), &traceRainbow);
                ImDesing::TextCentered(GetLang(OBFUSCATE("Circle after jump"), OBFUSCATE("Круг после прыжка")));
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Jump circle"), OBFUSCATE("Кружочек")), &JumpCircle);
                ImGui::SameLine();
                ImDesing::ColorPicker(GetLang(OBFUSCATE("Color"), OBFUSCATE("Цвет")), jumpcclr);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Glow"), OBFUSCATE("Глов")), &glowjumpc);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Pulse Color##Jump Circle"), OBFUSCATE("Пульсация цвета##Jump Circle")), &pulsecolorc);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Pulse##Jump Circle"), OBFUSCATE("Пульсация размера##Jump Circle")), &pulsejumpc);
                ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("RGB##Jump Circle"), OBFUSCATE("Радужный##Jump Circle")), &jumpRGB);
                ImGui::SliderFloat(GetLang(OBFUSCATE("Size##Jump Circle"), OBFUSCATE("Размер##Jump Circle")), &radiusc, 0.05f, 1.0f);
            }
        }
        if (currentPage == 2) {
            if (ImGui::CollapsingHeader(GetLang(OBFUSCATE("PlayerController"), OBFUSCATE("Сикретно")))) {
                if (!key.starts_with(OBFUSCATE("PREMIUM_"))) {
                    if (ImGui::Button(GetLang(OBFUSCATE("Поддержкать создателя"), OBFUSCATE("Поддержка создателя")))) {
                        openUrlInBrowser(OBFUSCATE("https://t.me/send?start=IVOLcCwL4mbF"));
                    }
                    ImGui::Text(GetLang(OBFUSCATE("Что-бы играть без спуф никнейма\n нужно купить платный ключ в\nботе @standknife_key_bot (навсегда)"), OBFUSCATE("Чтобы играть без спуф никнейма\n нужно купить платный ключ в\nботе @standknife_key_bot (навсегда)")));
                } else {
                    if (ImGui::Button(GetLang(OBFUSCATE("Kill enemy"), OBFUSCATE("Убить врагов")))) {
                        for (void* enemy : players)  {
                            DieViaServer(enemy);
                            Die(enemy);
                        }
                    }
                    ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("SpoofNickname"), OBFUSCATE("Спуф никнейм")), &hideid);
                    //ImDesing::AnimatedCheckbox(OBFUSCATE("SpoofID"), &spoofid);
                }

            }
        }

        if (currentPage == 3) {
            int configCount = sizeof(configNames) / sizeof(configNames[0]);
            ImGui::Combo(GetLang(OBFUSCATE("Config"), OBFUSCATE("Конфигурация")), &selectedConfigIndex, configNames, configCount);

            if (ImGui::Button(GetLang(OBFUSCATE("Save"), OBFUSCATE("Сохранить")))) {
                string configPath = WAY_FOR_CFG + "config_" + to_string(selectedConfigIndex + 1) + TYPE_CFG;
                saveCFG(selectedConfigIndex + 1);
            }
            ImGui::SameLine();
            if (ImGui::Button(GetLang(OBFUSCATE("Load"), OBFUSCATE("Загрузить")))) {
                string configPath = WAY_FOR_CFG + "config_" + to_string(selectedConfigIndex + 1) + TYPE_CFG;
                loadCFG(selectedConfigIndex + 1);
            }
            ImGui::Text(GetLang(OBFUSCATE("Open type"), OBFUSCATE("Тип открытия")));
            if (ImGui::Button(GetLang(OBFUSCATE("Line"), OBFUSCATE("Линия")))) {
                linep = true;
                buttonp = false;
            }
            ImGui::SameLine();
            if (ImGui::Button(GetLang(OBFUSCATE("Button"), OBFUSCATE("Кнопка")))) {
                linep = false;
                buttonp = true;
            }
            ImGui::Text(GetLang(OBFUSCATE("Menu Settings"), OBFUSCATE("Настройки меню")));
            ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Watermark"), OBFUSCATE("Водяной знак")), &showm);
            ImGui::SameLine();
            ImDesing::ColorPicker(GetLang(OBFUSCATE("Color"), OBFUSCATE("Цвет")), watermark_accent);
            ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("Rainbow"), OBFUSCATE("Радуга")), &watermarkRainbow);
            ImDesing::AnimatedCheckbox(GetLang(OBFUSCATE("SnowFlakes"), OBFUSCATE("Снежинки")), &snowflakes);

            ImGui::Text(GetLang(OBFUSCATE("Theme"), OBFUSCATE("Тема")));
            if (ImGui::Button(GetLang(OBFUSCATE("Light"), OBFUSCATE("Светлая")))) {
                setStyle(LIGHT);
            }
            ImGui::SameLine();
            if (ImGui::Button(GetLang(OBFUSCATE("Dark"), OBFUSCATE("Тёмная")))) {
                setStyle(DARK);
            }
            ImGui::Text(GetLang(OBFUSCATE("Язык"), OBFUSCATE("Lang")));
            if (ImGui::Button(GetLang(OBFUSCATE("Русский"), OBFUSCATE("Russian")))) {
                selectedLanguage = true;
            }
            ImGui::SameLine();
            if (ImGui::Button(GetLang(OBFUSCATE("Английский"), OBFUSCATE("English")))) {
                selectedLanguage = false;
            }
            if (eglstatus) {
                ImGui::Text(OBFUSCATE("Type render: EGL"));
            } else {
                ImGui::Text(OBFUSCATE("Type render: SurfaceView"));
            }
        }

        ImGui::PopStyleVar();
        ImGui::End();
    }
}

void RenderOpenButton() {
    if (!v1)
        if (linep) {
            ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x / 2 - 100 , ImGui::GetIO().DisplaySize.y - 60));
            ImGui::Begin(OBFUSCATE("##ponos"), NULL, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);
            if (ImGui::InvisibleButton(OBFUSCATE("##ponos"), ImVec2(400, 400))) {
                open4 = !open4;
            }

            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(ImGui::GetIO().DisplaySize.x / 2 - 100, ImGui::GetIO().DisplaySize.y - 15), ImVec2(ImGui::GetIO().DisplaySize.x / 2 + 100 , ImGui::GetIO().DisplaySize.y - 10), ImColor(255, 255, 255), 0, 10);
            ImGui::End();
        } else {
            ImGui::Begin(OBFUSCATE("#buttonmenu"), nullptr, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse);
            if (ImGui::Button(GetLang(OBFUSCATE("OPEN\nMENU"), OBFUSCATE("ОТКРЫТЬ\nМЕНЮ")))) {
                open4 = !open4;
            }
        }
}
void R3nderKey() {
    static bool showKB = false;
    static char input[315] = "";
    const float KEY_SIZE = 50.0f;
    const float SPACING = 5.0f;
    static ImVec2 kbWindowPos = ImVec2(0, 0);
    static bool isDraggingKB = false;
    static ImVec2 dragOffset;
    if (v1) {
        if (ImGui::Begin(OBFUSCATE(" "), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove)) {
            ImVec2 windowSize(700, 440);
            ImVec2 windowPos((menu::glWidth - windowSize.x) / 2, (menu::glHeight - windowSize.y) / 2);
            ImGui::SetWindowSize(windowSize);
            ImGui::SetWindowPos(windowPos);
            RectangleShadowSettings shadowSettings;
            shadowSettings.rectSize = ImVec2(ImGui::GetWindowSize().x, ImGui::GetWindowSize().y);
            shadowSettings.sigma = 10;
            shadowSettings.padding = ImVec2(0, 0);
            shadowSettings.rectPos = shadowSettings.padding;
            shadowSettings.rings = 10;
            shadowSettings.spacingBetweenRings = 5;
            shadowSettings.samplesPerCornerSide = 20;
            shadowSettings.spacingBetweenSamples = 15;
            shadowSettings.shadowColor = ImVec4(1.0f, 1.0f, 1.0f, 0.33f);
            shadowSettings.shadowSize = ImVec2(15, 15);
            drawRectangleShadowVerticesAdaptive(shadowSettings);
            ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x);
            ImGui::InputText("##input", input, sizeof(input));
            ImGui::PopItemWidth();
            float availableWidth = ImGui::GetContentRegionAvail().x;
            float btnHeight = ImGui::GetFrameHeight();
            float pasteBtnWidth = availableWidth - 80.0f;
            if (ImGui::Button(GetLang(OBFUSCATE("Paste"), OBFUSCATE("Вставить")), ImVec2(pasteBtnWidth, btnHeight))) {
                if (const char *clipboardText = getClipboardText().c_str()) {
                    memset(input, 0, sizeof(input));
                    strncpy(input, clipboardText, sizeof(input) - 1);
                }
            }
            ImGui::SameLine(0, 1.0f);
            ImGui::PushFont(menu::iconssmall);
            if (ImGui::Button(OBFUSCATE(ICON_FA_KEYBOARD), ImVec2(75.0f, btnHeight))) {
                showKB = !showKB;
                if (showKB) {
                    kbWindowPos = ImVec2((menu::glWidth - 600) * 0.5f, (menu::glHeight - 300) * 0.5f + 100);
                }
            }
            ImGui::PopFont();
            if (ImGui::Button(GetLang(OBFUSCATE("Get key"), OBFUSCATE("Получить ключ")), ImVec2(ImGui::GetContentRegionAvail().x, btnHeight))) {
                openUrlInBrowser(OBFUSCATE("https://ify.ac/1RtL"));
            }
            if (ImGui::Button(OBFUSCATE("Лучший софт беспл."), ImVec2(ImGui::GetContentRegionAvail().x, btnHeight))) {
                openUrlInBrowser("https://t.me/blackstandoff_bot?start=1204");
            }
            if (ImGui::Button(GetLang(OBFUSCATE("Done"), OBFUSCATE("Готово")), ImVec2(ImGui::GetContentRegionAvail().x, btnHeight)) || ImGui::IsKeyPressed(ImGuiKey_Enter)) {
                key = input;
                isValid = isKeyValid(key);
                if (key.starts_with(OBFUSCATE("PREMIUM_"))) {
                    hideid = false;
                }
                jint g1 = 0;
                if (isValid) {
                    v1 = false;
                    showKB = false;
                    ImGui::SetNextWindowSize({windowWidth, windowHeight});
                    ImGui::SetNextWindowPos({(menu::glWidth - windowWidth) / 2.0f, (menu::glHeight - windowHeight) / 2.0f});
                } else {
                    v2 = false;
                    pup++;
                }
            }
            if (pup > 0) {
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.0f, 0.0f, 1.0f));
                ImGui::Text(GetLang(OBFUSCATE("Invalid key! (click get key)"), OBFUSCATE("Ключ неверный! (нажмите получить ключ)")));
                ImGui::PopStyleColor();
            }
            if (!v2) {
                ImGui::Text(GetLang(OBFUSCATE("t.me/MamixCheats - key (link)"), OBFUSCATE("t.me/MamixCheats - ключ (ссылка)")));
            }
        }
        ImGui::End();
    }
    if (showKB) {
        ImGui::SetNextWindowPos(kbWindowPos, ImGuiCond_FirstUseEver);
        if (ImGui::Begin(GetLang(OBFUSCATE("Virtual Keyboard"), OBFUSCATE("Виртуальная клавиатура")), &showKB, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoScrollbar)) {
            if (ImGui::IsWindowHovered() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
                if (!isDraggingKB) {
                    dragOffset = ImGui::GetMousePos() - ImGui::GetWindowPos();
                    isDraggingKB = true;
                }
                kbWindowPos = ImGui::GetMousePos() - dragOffset;
                ImGui::SetWindowPos(kbWindowPos);
            } else {
                isDraggingKB = false;
            }
            RectangleShadowSettings kbShadowSettings;
            kbShadowSettings.rectSize = ImVec2(600, 260);
            kbShadowSettings.sigma = 10;
            kbShadowSettings.padding = ImVec2(0, 0);
            kbShadowSettings.rectPos = kbShadowSettings.padding;
            kbShadowSettings.rings = 10;
            kbShadowSettings.spacingBetweenRings = 5;
            kbShadowSettings.samplesPerCornerSide = 20;
            kbShadowSettings.spacingBetweenSamples = 15;
            kbShadowSettings.shadowColor = ImVec4(1.0f, 1.0f, 1.0f, 0.33f);
            kbShadowSettings.shadowSize = ImVec2(15, 15);
            drawRectangleShadowVerticesAdaptive(kbShadowSettings);
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(SPACING, SPACING));
            const char* rows[] = {"1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM_"};
            for (int i = 0; i < 4; i++) {
                float rowWidth = (strlen(rows[i]) * (KEY_SIZE + SPACING)) - SPACING;
                ImGui::SetCursorPosX((ImGui::GetWindowWidth() - rowWidth) * 0.5f);
                for (const char* c = rows[i]; *c; c++) {
                    if (ImGui::Button(std::string(1, *c).c_str(), ImVec2(KEY_SIZE, KEY_SIZE))) {
                        size_t len = strlen(input);
                        if (len < sizeof(input) - 1) {
                            input[len] = *c;
                            input[len + 1] = '\0';
                        }
                    }
                    ImGui::SameLine(0, SPACING);
                }
                ImGui::NewLine();
            }
            ImGui::PopStyleVar();
            float bottomRowWidth = KEY_SIZE * 2.0f + 200 + KEY_SIZE * 2.5f + 2 * SPACING;
            ImGui::SetCursorPosX((ImGui::GetWindowWidth() - bottomRowWidth) * 0.5f);
            if (ImGui::Button(GetLang(OBFUSCATE("<--"), OBFUSCATE("<--")), ImVec2(KEY_SIZE * 2.0f, KEY_SIZE))) {
                size_t len = strlen(input);
                if (len > 0) input[len - 1] = '\0';
            }
            ImGui::SameLine(0, SPACING);
            if (ImGui::Button(GetLang(OBFUSCATE("Space"), OBFUSCATE("Пробел")), ImVec2(200, KEY_SIZE))) {
                size_t len = strlen(input);
                if (len < sizeof(input) - 1) {
                    input[len] = ' ';
                    input[len + 1] = '\0';
                }
            }
            ImGui::SameLine(0, SPACING);
            if (ImGui::Button(GetLang(OBFUSCATE("Paste"), OBFUSCATE("Вставить")), ImVec2(KEY_SIZE * 2.5f, KEY_SIZE))) {
                if (const char* clipboardText = getClipboardText().c_str()) {
                    strncpy(input, clipboardText, sizeof(input) - 1);
                    input[sizeof(input) - 1] = '\0';
                }
            }
        }

        ImGui::End();
    }
}


