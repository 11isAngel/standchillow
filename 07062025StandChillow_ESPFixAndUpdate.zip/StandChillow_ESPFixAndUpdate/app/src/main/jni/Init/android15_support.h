#ifndef ANDROID15_SUPPORT_H
#define ANDROID15_SUPPORT_H

#include <android/input.h>
#include <mutex>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "imgui_impl_android.h"
#include "includes/Dobby/dobby.h"

namespace Android15Input {
    extern std::mutex input_mutex;

    typedef void (*InputA15_t)(void*, void*, void*, void*);
    static InputA15_t origInputA15 = nullptr;

    void myInputA15(void* thiz, void* ex_ab, void* ex_ac, void* ex_ad) {
        if (origInputA15) {
            origInputA15(thiz, ex_ab, ex_ac, ex_ad);
            input_mutex.lock();
            ImGui_ImplAndroid_HandleInputEvent((AInputEvent*)thiz);
            input_mutex.unlock();
        }
    }

    namespace {
        void (*old_InputMessage)(AInputEvent*, void*, void*);
        void new_InputMessage(AInputEvent* input_event, void* arg1, void* arg2) {
            if (old_InputMessage) {
                old_InputMessage(input_event, arg1, arg2);
                input_mutex.lock();
                ImGui_ImplAndroid_HandleInputEvent(input_event);
                input_mutex.unlock();
            }
        }

        int32_t (*old_consume)(void*, void*, bool, long, uint32_t*, AInputEvent**);
        int32_t new_consume(void* thiz, void* arg1, bool arg2, long arg3, uint32_t* arg4, AInputEvent** input_event) {
            if (!old_consume) return 0;
            auto result = old_consume(thiz, arg1, arg2, arg3, arg4, input_event);
            if (result != 0 || *input_event == nullptr) return result;
            input_mutex.lock();
            ImGui_ImplAndroid_HandleInputEvent(*input_event);
            input_mutex.unlock();
            return result;
        }
    }

    bool init_android15_support(const char* libinput_path) {
        void* sym_input = nullptr;
        
        const char* symbols[] = {
            "_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE",
            "_ZN7android13InputConsumer7consumeEPNS_26InputEventFactoryInterfaceEblPjPPNS_10InputEventE",
            "_ZN7android13InputConsumer15initializeEventEPNS_11MotionEventEPKNS_12InputMessageE",
            "_ZN7android13InputConsumer15processMotionEvENS_12InputMessageE",
            "_ZN7android13InputConsumer10processKeyENS_12InputMessageE"
        };

        for (const char* symbol : symbols) {
            sym_input = DobbySymbolResolver(libinput_path, symbol);
            if (sym_input) {
                LOGI("Found Android 15 input symbol: %s", symbol);
                DobbyHook(sym_input, (void*)myInputA15, (void**)&origInputA15);
                return true;
            }
        }

        void* libinput = dlopen(libinput_path, RTLD_NOW);
        if (libinput) {
            sym_input = dlsym(libinput, "_ZN7android13InputConsumer15initializeEventEPNS_11MotionEventEPKNS_12InputMessageE");
            if (sym_input) {
                DobbyHook(sym_input, (void*)myInputA15, (void**)&origInputA15);
                dlclose(libinput);
                return true;
            }
            dlclose(libinput);
        }

        return false;
    }
}

#endif // ANDROID15_SUPPORT_H 