#pragma once

#include <memory>
#include "../Obscured/ObscuredInt.h"

struct My_Patches {
    MemoryPatch ChamsBypass, invisibles, Ads, infinitydrop, dontret, movebefore, bypass, bypass1, bypass2, bypass3, bypass4, bypass5, aimlegit, aimhard, aimextreme, buyanywht, buyanywhct, shophack, antig, radar, noscope;
} hexPatches;

bool IsMatchEnding() {
    return matchisfinish;
}

std::string wpn = "t.me/MamixCheats";
std::vector<void*> players;
void* myPlayer = nullptr;
void* enemyPlayer = nullptr;
void* team = nullptr;
void* aimedplayer = nullptr;

struct CircleData {
    float timer = 0.0f;
    float alpha = 255.0f;
    float radius = 0.5f;
};

std::map<void*, CircleData> circleMap;

void (*old_GunControllerUpdate)(void* instance);
void GunControllerUpdate(void* instance) {
    if (!instance) return;

    if (norecoil) {
        float* recoilParam1 = (float*)((uint64_t)instance + 0x198);
        float* recoilParam2 = (float*)((uint64_t)instance + 0x19C);
        float* recoilParam3 = (float*)((uint64_t)instance + 0x1A0);

        if (recoilParam1 && recoilParam2 && recoilParam3) {
            *recoilParam1 = 0.01f;
            *recoilParam2 = 0.01f;
            *recoilParam3 = 0.01f;
        }

        void* gunParams = *(void**)((uint64_t)instance + 0x1B8);
        if (gunParams) {
            float* params[] = {
                    (float*)((uint64_t)gunParams + 0x94),
                    (float*)((uint64_t)gunParams + 0xA8),
                    (float*)((uint64_t)gunParams + 0xB8),
                    (float*)((uint64_t)gunParams + 0xBC),
                    (float*)((uint64_t)gunParams + 0xC0),
                    (float*)((uint64_t)gunParams + 0xC4),
                    (float*)((uint64_t)gunParams + 0xC8),
                    (float*)((uint64_t)gunParams + 0xCC),
                    (float*)((uint64_t)gunParams + 0xD0)
            };

            for (float* param : params) {
                if (param) *param = 0.01f;
            }
        }

        /*void* AccuracyData = *(void**)((uint64_t)instance + 0x180);
        if (AccuracyData) {
            float* accuracyParams[] = {
                (float*)((uint64_t)AccuracyData + 0x10),
                (float*)((uint64_t)AccuracyData + 0x14)
            };
            
            for (float* param : accuracyParams) {
                if (param) *param = 0.01f;
            }
        }*/

        void* HMRMIMIUHSP = *(void**)((uint64_t)instance + 0x128);
        if (HMRMIMIUHSP) {
            Vector2* vectors[] = {
                    (Vector2*)((uint64_t)HMRMIMIUHSP + 0x18),
                    (Vector2*)((uint64_t)HMRMIMIUHSP + 0x20),
                    (Vector2*)((uint64_t)HMRMIMIUHSP + 0x2C)
            };

            for (Vector2* vec : vectors) {
                if (vec) *vec = Vector2(0.0f, 0.0f);
            }

            void* GGKUUJMLHIK = *(void**)((uint64_t)HMRMIMIUHSP + 0x38);
            if (GGKUUJMLHIK) {
                float* params[] = {
                        (float*)((uint64_t)GGKUUJMLHIK + 0x10),
                        (float*)((uint64_t)GGKUUJMLHIK + 0x14),
                        (float*)((uint64_t)GGKUUJMLHIK + 0x18)
                };

                for (float* param : params) {
                    if (param) *param = 0.01f;
                }

                Vector2* vec = (Vector2*)((uint64_t)GGKUUJMLHIK + 0x1C);
                if (vec) *vec = Vector2(0.0f, 0.0f);
            }

            void* RecoilParameters = *(void**)((uint64_t)HMRMIMIUHSP + 0x48);
            if (RecoilParameters) {
                float* params[] = {
                        (float*)((uint64_t)RecoilParameters + 0x10),
                        (float*)((uint64_t)RecoilParameters + 0x14)
                };

                for (float* param : params) {
                    if (param) *param = 0.01f;
                }
            }
        }
    }

    if (wallshot) {
        void* gunParams = *(void**)((uint64_t)instance + 0x1B8);
        if (gunParams) {
            float* wallshotParam = (float*)((uint64_t)gunParams + 0xE4);
            if (wallshotParam) *wallshotParam = 999999.05f;
        }
    }

    if (firerate) {
        float* firerateParam = (float*)((uint64_t)instance + 0xF8);
        if (firerateParam) *firerateParam = 0.03f;
    }

    old_GunControllerUpdate(instance);
}

bool isValidPhoton(void* photonView) {
    if (!photonView) return false;

    uintptr_t baseAddr = (uintptr_t)photonView;
    int* ownerIdPtr = (int*)(baseAddr + 0x20);
    if (!ownerIdPtr) return false;

    int ownerId = *ownerIdPtr;
    if (ownerId <= 0) return false;

    return true;
}

void (*set_clearFlags)(void *camera, int value);
void (*set_backgroundColor)(void *camera, ImColor value);

void (*Old_Screen$$SetResolution)(...);
void New_Screen$$SetResolution()
{
    Old_Screen$$SetResolution(menu::glWidth, menu::glHeight, true);
}

int (*GetHealth)(void *photon);
void (*DieViaServer)(void* player);
void (*Die)(void* player);
void (*GLOVES)(void* _this, int);
int (*GetPlayerMoney)(void *photonplayer);
int (*GetPlayerHealth)(void *photonplayer);
int (*GetPlayerArmor)(void* photonplayer);
void (*SetPlayerArmor)(void* photonplayer, int value);
void (*SetPlayerHealth)(void* photonplayer, int value);
bool (*HasHelmet)(void* photonplayer);
void (*set_newposition)(void* transform, Vector3 newPosition);
void (*SetHelmet)(void* photonplayer, bool helmet);
Vector3(*get_right) (void*);
Vector3(*getAxis) (void*);
float (*GetDeltaTime)(void* nul);
Vector3(*get_forward) (void*);
Vector3(*get_forward1) (void *player);
void (*set_TpsView3)(void* player);
void (*set_FpsView3)(void* player);
void (*DestroyAll)(void* player);
void (*set_position)(void* transform, Vector3 newPosition);
bool (*isMine)(void* photonview);
void (*set_localScale)(void *transform, Vector3 newScale);
Vector3 (*get_position)(void* transform);
void* (*get_transform)(void* component);
void* (*get_photonbase)(void* player);
void* (*RMaterial)(void*);
void (*MShader)( void*,void*);
void *GunInst = nullptr;
void (*PLH$$Update)(...);
void* (*Type$$GetType)(Il2CppString* typeStr);
void* (*FindShader)(Il2CppString*);
void (*Material$$SetFloat)(void*, Il2CppString*, float);
void (*Material$$SetColor)(void*, Il2CppString*, Color);
void (*Material$$SetTexture)(void*, Il2CppString*, void*);
void* (*Renderer$$Material)(void*);
void (*Material$$Shader)( void*,void*);

Vector3 GetPlayerLocation(void *player) {
    if (!player) return Vector3();
    void* transform = get_transform(player);
    if (!transform) return Vector3();
    return get_position(transform);
}

static void *get_photon(void *player) {
    return *(void**)((uint64_t)player + 0x140);
}

inline bool isValidPointer(void* ptr) {
    return ptr && ((uintptr_t)ptr >= 0x10000);
}

bool isValidPlayer(void* pl) {
    return pl && (uintptr_t)pl > 0x10000 && get_photon(pl);
}

void *GetBones(void *player) {
    if (!player || (uintptr_t)player < 0x10000) return nullptr;
    void* bones = *(void **)((uint64_t) player + 0x30);
    if (!bones || (uintptr_t)bones < 0x10000) return nullptr;
    return bones;
}

void* get_neck(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return nullptr;
    void* bones = GetBones(player);
    if (!bones || (uintptr_t)bones < 0x10000) return nullptr;
    void* neck = *(void**)((uint64_t)bones + 0x20);
    if (!neck || (uintptr_t)neck < 0x10000) return nullptr;
    return neck;
}

void* get_hip(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return nullptr;
    void* bones = GetBones(player);
    if (!bones || (uintptr_t)bones < 0x10000) return nullptr;
    void* hip = *(void**)((uint64_t)bones + 0x80);
    if (!hip || (uintptr_t)hip < 0x10000) return nullptr;
    return hip;
}

void* get_head(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return nullptr;
    void* bones = GetBones(player);
    if (!bones || (uintptr_t)bones < 0x10000) return nullptr;
    void* head = *(void**)((uint64_t)bones + 0x18);
    if (!head || (uintptr_t)head < 0x10000) return nullptr;
    return head;
}

Vector3 GetPlayerBonePosition(void* player, uint64_t bone) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    void* bones = GetBones(player);
    if (!bones || (uintptr_t)bones < 0x10000) return Vector3();
    void* boneTransform = *(void**)((uint64_t)bones + bone);
    if (!boneTransform || (uintptr_t)boneTransform < 0x10000) return Vector3();
    void* transform = get_transform(boneTransform);
    if (!transform || (uintptr_t)transform < 0x10000) return Vector3();
    return get_position(transform);
}

Vector3 GetPlayerHead(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x18);
}

Vector3 GetPlayerNeck(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x20);
}

Vector3 GetPlayerHip(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x80);
}

Vector3 GetPlayerLeftLowerArm(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x50);
}

Vector3 GetPlayerLeftHand(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x58);
}

Vector3 GetPlayerRightHand(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x78);
}

Vector3 GetPlayerLeftUpperArm(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x48);
}

Vector3 GetPlayerRightLowerArm(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x70);
}

Vector3 GetPlayerRightUpperArm(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x68);
}

Vector3 GetPlayerLeftLowerLeg(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x90);
}

Vector3 GetPlayerLeftUpperLeg(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0x88);
}

Vector3 GetPlayerRightLowerLeg(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0xB0);
}

Vector3 GetPlayerRightUpperLeg(void* player) {
    if (!player || (uintptr_t)player < 0x10000) return Vector3();
    return GetPlayerBonePosition(player, 0xA8);
}

Il2CppString* GetName(void *photon) {
    if (!photon) return nullptr;
    return *(Il2CppString **)((uint64_t) photon + 0x18);
}

int GetPlayerTeam(void *player) {
    return *(int *)((uint64_t) player + 0x78);
}
bool (*IsPlayerDead)(void* player);
bool (*Linecast)(Vector3, Vector3, int);
Quaternion PlayerLook;

/*void* myPlayer = nullptr;
void* enemyPlayer = nullptr;
void* team = nullptr;
void *aimedplayer = nullptr;*/

struct RaycastHit {
    float Distance;
    Vector3 Point;
    Vector3 Normal;
    int FaceID;
};

enum CBDJDAALDAF {
    G22 = 11,
    USP = 12,
    P350 = 13,
    Deagle = 15,
    Tec9 = 16,
    FiveSeven = 17,
    UMP45 = 32,
    MP7 = 34,
    P90 = 35,
    AKR = 44,
    AKR12 = 45,
    M4 = 46,
    M16 = 47,
    FAMAS = 48,
    FnFal = 49,
    AWM = 51,
    M40 = 52,
    M110 = 53,
    SM1014 = 62,
    Knife = 70,
    KnifeBayonet = 71,
    KnifeKarambit = 72,
    jKommando = 73,
    KnifeButterfly = 75,
    GrenadeHE = 91,
    GrenadeSmoke = 92,
    GrenadeFlash = 93,
    Bomb = 100,
    Defuser = 101,
    DefuseKit = 102,
    Vest = 110,
    VestAndHelmet = 111,
};

float Distance(Vector3 a, Vector3 b) {
    return sqrt((b.x - a.x) * (b.x - a.x) +
                (b.y - a.y) * (b.y - a.y) +
                (b.z - a.z) * (b.z - a.z));
} // by @destroyhack

Vector3 (*WorldToScreenPoint)(void* camera, Vector3 poss) = nullptr;
void *(*get_camera)();

ImVec2 world2screen_c(Vector3 pos, bool &checker) {
    auto cam = get_camera();
    if (!cam) return {0,0};

    Vector3 worldPoint;
    if (WorldToScreenPoint) {
        worldPoint = WorldToScreenPoint(cam, pos);
    } else {
        return {0,0};
    }

    checker = worldPoint.z > 1;
    return ImVec2(worldPoint.x, menu::glHeight - worldPoint.y);
}

ImVec2 world2screen_i(Vector3 pos) {
    auto cam = get_camera();
    if (!cam) return {0,0};

    Vector3 worldPoint;
    if (WorldToScreenPoint) {
        worldPoint = WorldToScreenPoint(cam, pos);
    } else {
        return {0,0};
    }

    return {worldPoint.x, menu::glHeight - worldPoint.y};
}

void (*old_JoystickOnWalk)(void* a,void* b);
void JoystickOnWalk(void* a,void* b) {
    if (a && fly) {
        joystickinstance = a;
    }
    old_JoystickOnWalk(a,b);
}

void DrawLineToPlayer(void* myPlayer, ImVec4 lineColor) {
    if (!isValidPlayer(myPlayer)) return;

    bool onScreen = false;
    auto trans = get_transform(myPlayer);
    if (!trans) return;

    Vector3 myPlayerPosition = get_position(trans);
    if (myPlayerPosition == Vector3(0, 0, 0)) return;

    void* camera = get_camera();
    if (!camera) return;

    Vector3 screenPos = WorldToScreenPoint(camera, myPlayerPosition);
    if (screenPos.z <= 0) return;

    if (onScreen) {
        auto render = ImGui::GetBackgroundDrawList();
        if (!render) return;
    }
}

void (*StartPlant)(void *inst, Vector3 position, float yRotate);
void (*old_BombManagerUpdate)(void *instance);
void BombManagerUpdate(void *instance) {
    if (!instance) return;

    if (AutoWinCT) {
        void* transform = get_transform(myPlayer);
        if (!transform) return;
        Vector3 plantpos = get_position(transform);
        StartPlant(instance, Vector3(plantpos.x, plantpos.y+100, plantpos.z), 1.0f);
    }

    if (AutoWinT && isValidPlayer(enemyPlayer)) {
        void* transform = get_transform(enemyPlayer);
        if (!transform) return;
        Vector3 plantpos = get_position(transform);
        StartPlant(instance, Vector3(plantpos.x, plantpos.y+100, plantpos.z), 1.0f);
    }

    if (old_BombManagerUpdate) old_BombManagerUpdate(instance);
}

void Draw3DCircle(Vector3 pos, float radius, float stroke, ImColor color, float segments, bool filled = false, float fillopacity = 0, bool hasglow = false) {
    ImVec2 vCenter = world2screen_i(pos);

    for (float i = 0; i < segments; i++) {
        if (i < segments) {
            Vector3 pos1 = Vector3(pos.x + radius * cos(i * (PI * 2) / segments), pos.y, pos.z + radius * sin(i * (PI * 2) / segments));
            Vector3 pos2 = Vector3(pos.x + radius * cos((i + 1) * (PI * 2) / segments), pos.y, pos.z + radius * sin((i + 1) * (PI * 2) / segments));
            bool checker1;
            bool checker2;
            ImVec2 vPos = world2screen_c(pos1, checker1);
            ImVec2 vNextPos = world2screen_c(pos2, checker2);

            if (checker1 && checker2) {
                if (hasglow) {
                    ImDesing::DrawLineGlow(vPos, vNextPos, color, stroke, 25);
                } else {
                    ImGui::GetBackgroundDrawList()->AddLine(vPos, vNextPos, color, stroke);
                }

                if (filled) {
                    ImGui::GetBackgroundDrawList()->PathLineTo(vPos);
                    ImGui::GetBackgroundDrawList()->PathLineTo(vNextPos);
                }
            }
        }
    }
}

struct position_info_jump {
public:
    Vector3 pos;
    int animation = 255;
};
void (*Fire)(void *ctor, bool sound);
std::deque<position_info_jump>jump_circle_data;

void (*old_OnLand)(void* i, float dur);

void OnLand(void* i, float dur) {
    if (!i) {
        if (old_OnLand) old_OnLand(i, dur);
        return;
    }

    if (JumpCircle) {
        void* character = *(void**)((uintptr_t)i + 0xB0);
        if (character && isValidPointer(character)) {
            if (void* transform = get_transform(character)) {
                jump_circle_data.push_back({ get_position(transform) });
                if (jump_circle_data.size() > 5)
                    jump_circle_data.pop_front();
            }
        }
    }

    if (old_OnLand) old_OnLand(i, dur);
}

void RenderJumpCircle() {
    if (!JumpCircle) return;

    if (!isValidPlayer(myPlayer) || !isValidPhoton(get_photon(myPlayer))) {
        jump_circle_data.clear();
        return;
    }

    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    for (auto& data : jump_circle_data) {
        if (data.animation > 0)
            --data.animation;

        bool onScreen = false;
        auto screenPos = world2screen_c(data.pos, onScreen);
        if (!onScreen) continue;

        ImColor circleColor;
        if (jumpRGB) {
            auto c = Rainbow::GetColor();
            if (c.w == 0) continue;
            circleColor = ImColor(c.x, c.y, c.z, c.w);
        } else {
            circleColor = ImColor(jumpcclr.x, jumpcclr.y, jumpcclr.z, static_cast<float>(data.animation) / 255.0f);
        }

        Draw3DCircle(data.pos, radiusc, thiknessc, circleColor, 50, false, 5, glowjumpc);
    }
}

void RenderTrace() {
    if (!traceEnable) return;
    if (!isValidPlayer(myPlayer)) return;
    if (!isValidPhoton(get_photon(myPlayer))) return;
    if (!get_transform(myPlayer)) return;

    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    static vector<Vector3> movementHistory;
    void* transform = get_transform(myPlayer);
    if (!transform) return;

    Vector3 myPos = get_position(transform);
    if (myPos == Vector3(0, 0, 0)) return;

    movementHistory.push_back(myPos);
    if (movementHistory.size() > 100) {
        movementHistory.erase(movementHistory.begin());
    }

    void* camera = get_camera();
    if (!camera) return;

    for (int i = 0; i != movementHistory.size(); i++) {
        if (i < 3 || movementHistory[i] == movementHistory[i-1])
            continue;

        auto pos1 = WorldToScreenPoint(camera, movementHistory[i]);
        auto pos2 = WorldToScreenPoint(camera, movementHistory[i - 1]);

        if (pos1.z <= 0 || pos2.z <= 0)
            continue;

        pos1.y = menu::glHeight - pos1.y;
        pos2.y = menu::glHeight - pos2.y;

        if (traceTriple) {
            draw->AddCircleFilled(ImVec2((pos1.x + pos2.x) * 0.5f, (pos1.y + pos2.y) * 0.5f),
                                  sqrt(pow(pos2.x - pos1.x, 2) + pow(pos2.y - pos1.y, 2)) * 0.5f,
                                  traceRainbow ? ImGui::GetColorU32(Rainbow::GetColor()) : ImGui::GetColorU32(*(ImVec4*)traceColor),
                                  3);
        } else {
            if (lineglow) {
                ImDesing::DrawLineGlow(ImVec2(pos1.x, pos1.y), ImVec2(pos2.x, pos2.y),
                                       traceRainbow ? Rainbow::GetColor() : *(ImVec4*)traceColor, 3, 25);
            } else {
                draw->AddLine(ImVec2(pos1.x, pos1.y), ImVec2(pos2.x, pos2.y),
                              traceRainbow ? ImGui::GetColorU32(Rainbow::GetColor()) : ImGui::GetColorU32(*(ImVec4*)traceColor), 3);
            }
        }
    }
}


/*void (*ThrowGrenade)(void* _this, int weaponId, Vector3 position, Vector3 direction, float movemyPlayerntVelocity, int throwType);
void (*old_GrenadeManagerUpdate)(...);
void GrenadeManagerUpdate(void* instance) {
    if (!instance) return;

    if (nuke) {
        if (nuke_me && myPlayer) {
            void* transform = get_transform(myPlayer);
            if (transform) {
                Vector3 pos = get_position(transform);
                ThrowGrenade(instance, 91 + grenade_type, Vector3(pos.x, pos.y + 0.15f, pos.z), pos, 0.0f, 0);
            }
        }
        
        if (nuke_enemy && enemyPlayer) {
            void* transform = get_transform(enemyPlayer);
            if (transform) {
                Vector3 pos = get_position(transform);
                ThrowGrenade(instance, 91 + grenade_type, Vector3(pos.x, pos.y + 0.15f, pos.z), pos, 0.0f, 0);
            }
        }
        
        if (nuke_team && team) {
            void* transform = get_transform(team);
            if (transform) {
                Vector3 pos = get_position(transform);
                ThrowGrenade(instance, 91 + grenade_type, Vector3(pos.x, pos.y + 0.15f, pos.z), pos, 0.0f, 0);
            }
        }
    }
    
    old_GrenadeManagerUpdate(instance);
}
*/
//standknife bypass ACTk
void* chat_manager_instance = nullptr;

void (*SendToAll)(void* instance, Il2CppString* message);
void (*old_ChatManager_ctor)(...);
void ChatManager_ctor(void* instance) {
    if (instance) {
        chat_manager_instance = instance;
    }
    return old_ChatManager_ctor(instance);
}
void *masterisnstace = nullptr;
bool (*old_IsMasterClient)(void *master);
bool IsMasterClient(void *master) {
    if (hostme) return true;
    if (master) masterisnstace = master;
    return old_IsMasterClient(master);
}

int (*old_StopMatch)(void *master);
int StopMatch(void *master) {
    if (stopm) {
        return 1;
    }
    return old_StopMatch(master);
}
double (*old_FastMatch)(void *master);
double FastMatch(void *master) {
    if (fastm) {
        return 0;
    }
    return old_FastMatch(master);
}

void (*old_NoClip)(void *player, Vector3 value);
void NoClip(void *player, Vector3 value) {
    if (player && noclip) {
        value = Vector3(0, 0, 0);
    }
    return old_NoClip(player, value);
}

void clearPlayers() {
    try {
        if (players.empty() || !isValidPlayer(myPlayer)) return;

        int myTeam = GetPlayerTeam(myPlayer);
        std::vector<void*> enemies;

        for (auto pl : players) {
            try {
                if (!pl || (uintptr_t)pl < 0x10000) continue;
                if (!isValidPlayer(pl)) continue;
                void* photon = get_photon(pl);
                if (!isValidPhoton(photon)) continue;

                int team = GetPlayerTeam(pl);
                if (team != myTeam) enemies.push_back(pl);
            } catch (...) {
                continue;
            }
        }

        players = enemies;
    } catch (...) {
        players.clear();
    }
}

bool playerFind(void *pl) {
    if (!isValidPlayer(pl)) return false;

    try {
        for (int i = 0; i < players.size(); i++) {
            void* p = players[i];
            if (!p || (uintptr_t)p < 0x10000) continue;
            if (p == pl) return true;
        }
    } catch (...) {
        LOGI("playerFind catch — possible invalid pointer");
        return false;
    }

    return false;
}

bool IsPlayerVisible(void* player) {
    if (!isValidPlayer(player)) return false;
   // if (!isValidPhoton(get_photon(player))) return false;

    void* camera = get_camera();
    if (!camera || (uintptr_t)camera < 0x10000) return false;
    void* cameraTransform = get_transform(camera);
    if (!cameraTransform || (uintptr_t)cameraTransform < 0x10000) return false;

    Vector3 CameraPos = get_position(cameraTransform);
    if (CameraPos == Vector3(0, 0, 0)) return false;

    Vector3 headPos = GetPlayerHead(player);
    Vector3 hipPos = GetPlayerHip(player);
    Vector3 leftLowerArmPos = GetPlayerLeftLowerArm(player);
    Vector3 rightLowerArmPos = GetPlayerRightLowerArm(player);
    Vector3 leftLowerLegPos = GetPlayerLeftLowerLeg(player);
    Vector3 rightLowerLegPos = GetPlayerRightLowerLeg(player);

    if (headPos == Vector3(0, 0, 0) || hipPos == Vector3(0, 0, 0) ||
        leftLowerArmPos == Vector3(0, 0, 0) || rightLowerArmPos == Vector3(0, 0, 0) ||
        leftLowerLegPos == Vector3(0, 0, 0) || rightLowerLegPos == Vector3(0, 0, 0)) {
        return false;
    }

    bool CanSeeHead = !Linecast(CameraPos, headPos, 16384);
    bool CanSeeHip = !Linecast(CameraPos, hipPos, 16384);
    bool CanSeeLeftLowerArm = !Linecast(CameraPos, leftLowerArmPos, 16384);
    bool CanSeeRightLowerArm = !Linecast(CameraPos, rightLowerArmPos, 16384);
    bool CanSeeLeftLowerLeg = !Linecast(CameraPos, leftLowerLegPos, 16384);
    bool CanSeeRightLowerLeg = !Linecast(CameraPos, rightLowerLegPos, 16384);

    return CanSeeHead || CanSeeHip || CanSeeLeftLowerArm || CanSeeRightLowerArm || CanSeeLeftLowerLeg || CanSeeRightLowerLeg;
}

bool isFov(Vector2 vec1, Vector2 vec2, int radius) {
    int x = vec1.x;
    int y = vec1.y;

    int x0 = vec2.x;
    int y0 = vec2.y;

    if ((pow(x - x0, 2) + pow(y - y0, 2)) <= pow(radius, 2)) {
        return true;
    } else {
        return false;
    }
}

enum class InventoryId
{
    Gloves_Polymer = 3039,
    Gloves_Gangster = 3038,
    Gloves_Spectral = 3037,
    Gloves_Ironclad = 3036,
    Gloves_Utility = 3035,
    Gloves_Rebellion = 3034,
    Gloves_Stream = 3030,
    Gloves_Artificer = 3031,
    Gloves_DragonGlass = 3032,
    Gloves_Mimicry = 3033,
    Gloves_Flux = 3023,
    Gloves_Shatter = 3024,
    Gloves_Haunt = 3025,
    Gloves_Plague = 3026,
    Gloves_AcidVeil = 3027,
    Gloves_Immolation = 3028
};

const char* GetInventoryIdName(int id) {
    switch (id) {
        case 3039: return "Polymer Gloves";
        case 3038: return "Gangster Gloves";
        case 3037: return "Spectral Gloves";
        case 3036: return "Ironclad Gloves";
        case 3035: return "Utility Gloves";
        case 3034: return "Rebellion Gloves";
        case 3030: return "Stream Gloves";
        case 3031: return "Artificer Gloves";
        case 3032: return "Dragon Glass Gloves";
        case 3033: return "Mimicry Gloves";
        case 3023: return "Flux Gloves";
        case 3024: return "Shatter Gloves";
        case 3025: return "Haunt Gloves";
        case 3026: return "Plague Gloves";
        case 3027: return "Acid Veil Gloves";
        case 3028: return "Immolation Gloves";
        default: return "Unknown";
    }
}
Il2CppString* GetWeaponId(void* a) {
    if (!isValidPlayer(a)) return nullptr;
    if (!isValidPhoton(get_photon(myPlayer))) return nullptr;

    try {
        auto w1 = *(void**)((uint64_t)a + 0x150);
        if (!w1 || (uintptr_t)w1 < 0x10000) return nullptr;

        auto w2 = *(void**)((uint64_t)w1 + 0x90);
        if (!w2 || (uintptr_t)w2 < 0x10000) return nullptr;

        auto w3 = *(void**)((uint64_t)w2 + 0xC0);
        if (!w3 || (uintptr_t)w3 < 0x10000) return nullptr;

        auto w4 = *(Il2CppString**)((uint64_t)w3 + 0x20);
        if (!w4 || (uintptr_t)w4 < 0x10000) return nullptr;

        if (!w4->CString()) return nullptr;

        return w4;
    } catch (...) {
        LOGI("GetWeaponId exception");
        return nullptr;
    }
}

std::string getWeaponString(void* player) {
    if (!isValidPlayer(player)) return "G";
    if (!isValidPhoton(get_photon(myPlayer))) return "G";

    try {
        Il2CppString* weapon = GetWeaponId(player);
        if (!weapon || (uintptr_t)weapon < 0x10000) return "G";

        const char* weaponName = weapon->CString();
        if (!weaponName) return "G";

        static const std::unordered_map<std::string, char> weaponMap = {
                {"G22", 'A'}, {"USP", 'B'}, {"P350", 'C'}, {"Berettas", 'D'}, {"Tec9", 'E'}, {"FiveSeven", 'F'},
                {"Deagle", 'G'}, {"FabM", 'H'}, {"SM1014", 'I'}, {"SPAS", 'J'}, {"M60", 'K'}, {"MAC10", 'L'},
                {"UMP45", 'M'}, {"MP5", 'N'}, {"MP7", 'O'}, {"P90", 'P'}, {"FnFal", 'Q'}, {"FAMAS", 'R'},
                {"AKR", 'S'}, {"M4", 'T'}, {"M4A1", 'U'}, {"AKR12", 'V'}, {"M16", 'W'}, {"M40", 'X'},
                {"AWM", 'Y'}, {"M110", 'Z'}, {"Bomb", 'a'}, {"Knife", 'b'}, {"KnifeBayonet", 'c'}, {"KnifeKarambit", 'd'},
                {"jKommando", 'e'}, {"KnifeButterfly", 'f'}, {"FlipKnife", 'g'}, {"ScorpionKnife", 'h'},
                {"KunaiKnife", 'i'}, {"DaggerKnife", 'j'}, {"KnifeStilet", 'k'}, {"GrenadeSmoke", 'l'},
                {"GrenadeFlash", 'm'}, {"GrenadeHE", 'n'}, {"GrenadeMolotov", 'o'}, {"GrenadeIncendiary", 'p'}
        };

        auto it = weaponMap.find(weaponName);
        return std::string(1, (it != weaponMap.end() ? it->second : 'G'));
    } catch (...) {
        LOGI("getWeaponString exception");
        return "G";
    }
}

Vector3 NormalizeAngles(Vector3 angles){
    angles.x = Vector3::NormalizeAngle(angles.x);
    angles.y = Vector3::NormalizeAngle(angles.y);
    angles.z = Vector3::NormalizeAngle(angles.z);
    return angles;
}

Vector3 ToEulerRad(Quaternion q1){
    float sqw = q1.w * q1.w;
    float sqx = q1.x * q1.x;
    float sqy = q1.y * q1.y;
    float sqz = q1.z * q1.z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.x * q1.w - q1.y * q1.z;
    Vector3 v;

    if (test>0.4995f*unit) {
        v.y = 2.0f * atan2f (q1.y, q1.x);
        v.x = M_PI / 2.0f;
        v.z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }
    if (test<-0.4995f*unit) {
        v.y = -2.0f * atan2f (q1.y, q1.x);
        v.x = -M_PI / 2.0f;
        v.z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }
    Quaternion q(q1.w, q1.z, q1.x, q1.y);
    v.y = atan2f (2.0f * q.x * q.w + 2.0f * q.y * q.z, 1 - 2.0f * (q.z * q.z + q.w * q.w));
    v.x = asinf (2.0f * (q.x * q.z - q.w * q.y));
    v.z = atan2f (2.0f * q.x * q.y + 2.0f * q.z * q.w, 1 - 2.0f * (q.y * q.y + q.z * q.z));
    return NormalizeAngles(v * Rad2Deg);
}

void* GetView(void* a) {
    if (!a) return nullptr;
    return *(void **) ((uint64_t) a + 0xFC);
}

void (*old_PlayerControllerUpdate)(void* player);
void PlayerControllerUpdate(void* player) {
    if (!isValidPointer(player)) {
        if (old_PlayerControllerUpdate) old_PlayerControllerUpdate(player);
        return;
    }

    void* photon = get_photon(player);
    if (!isValidPointer(photon)) {
        if (old_PlayerControllerUpdate) old_PlayerControllerUpdate(player);
        return;
    }

    if (isMine(photon) && isValidPhoton(get_photon(player))) {
        if (isValidPlayer(player)) {
            myPlayer = player;
        }
    }

    if (!isValidPointer(myPlayer) || !isValidPlayer(myPlayer)) {
        if (old_PlayerControllerUpdate) old_PlayerControllerUpdate(player);
        return;
    }

    if (isValidPlayer(player) || isValidPhoton(get_photon(player))) {
        int playerTeam = GetPlayerTeam(player);
        int myTeam = GetPlayerTeam(myPlayer);

        if (playerTeam != myTeam) {
            enemyPlayer = player;
        } else {
            team = player;
        }
    }

    if (isValidPhoton(get_photon(myPlayer))) {
        if (ArmPos && myPlayer) {
            void *arms = *(void **) ((uint64_t) player + 0x100);
            if (arms) {
                Vector3 *armPosition = (Vector3 *) ((uint64_t) arms + 0xE0);
                bool *armFlag = (bool *) ((uint64_t) arms + 0x74);
                if (armPosition)
                    *armPosition = Vector3(xx * 0.01 / 10, yy * 0.01 / 10, zz * 0.01 / 10);
                if (armFlag) *armFlag = false;
            }
        }

        if (isValidPlayer(myPlayer) && ThirdPerson) {
            set_TpsView3(myPlayer);
        }

        if (fly && joystickinstance && get_camera() && isValidPlayer(myPlayer)) {
            xu = getAxis(joystickinstance).x;
            yu = getAxis(joystickinstance).y;
            auto transfer = (get_forward(get_transform(get_camera())) * yu +
                             get_right(get_transform(get_camera())) * xu) *
                            GetDeltaTime(nullptr) * flyspeed;
            flypos = flypos + transfer;
            set_position(get_transform(myPlayer), flypos);
        }

        if (antiaim && myPlayer) {
            void *aiming = *(void **) ((uint64_t) player + 0x110);
            if (aiming) {
                void *aimingData = *(void **) ((uint64_t) aiming + 0x78);
                if (aimingData) {
                    void *TransformTR = *(void **) ((uint64_t) aimingData + 0x60);
                    if (TransformTR) {
                        Vector3 *transformPos = (Vector3 *) ((uint64_t) TransformTR + 0x10);
                        Vector3 *transformRot = (Vector3 *) ((uint64_t) TransformTR + 0x1C);
                        if (transformPos) *transformPos = Vector3(x2, y2, z2);
                        if (transformRot) *transformRot = Vector3(x2, y2, z2);
                    }
                }
            }
            if (aastatic) {
                x2 = aastaticxpos;
                y2 = aastaticypos;
                z2 = aastaticzpos;
            }
            if (aajitter) {
                x2 += jitterspeed;
                y2 += jitterspeed;
                z2 += jitterspeed;
            }
        }

        if (bunnyhop && myPlayer) {
            void *movementcontroller = *(void **) ((uint64_t) player + 0xD8);
            if (movementcontroller) {
                void *translationParameters = *(void **) ((uint64_t) movementcontroller + 0x70);
                if (translationParameters) {
                    void *jumpParameters = *(void **) ((uint64_t) translationParameters + 0x48);
                    if (jumpParameters) {
                        float *bunnyParam = (float *) ((uint64_t) jumpParameters + 0xB8);
                        if (bunnyParam) *bunnyParam = bunnyvalue;
                    }
                }
            }
        }

        if (slaim && enemyPlayer && myPlayer) {
            void *enemyTransform = get_transform(enemyPlayer);
            void *myTransform = get_transform(myPlayer);
            if (enemyTransform && myTransform &&
                get_position(enemyTransform) != Vector3(0, 0, 0) &&
                get_position(myTransform) != Vector3(0, 0, 0)) {
                void *BipedMap = GetBones(enemyPlayer);
                if (BipedMap) {
                    void *aimedPlayerHead = *(void **) ((uint64_t) BipedMap + 0x18);
                    if (aimedPlayerHead) {
                        void *camera = get_camera();
                        void *camTransform = camera ? get_transform(camera) : nullptr;
                        if (camTransform && get_position(camTransform) != Vector3(0, 0, 0)) {
                            Vector3 target =
                                    get_position(aimedPlayerHead) - get_position(camTransform);
                            float aimAngle = Vector3::Angle(target,
                                                            get_forward(camTransform) * 100);
                            if (target != Vector3(0, 0, 0)) {
                                if (!silentvis || IsPlayerVisible(enemyPlayer)) {
                                    if (aimAngle <= silentfovsize / 700.0f)
                                        aimedplayer = enemyPlayer;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (masskill && enemyPlayer && myPlayer) {
            void *myTransform = get_transform(myPlayer);
            void *enemyTransform = get_transform(enemyPlayer);
            if (myTransform && enemyTransform &&
                get_position(myTransform) != Vector3(0, 0, 0)) {
                set_position(enemyTransform, get_position(myTransform) + Vector3(0, 0, 1));
            }
        }

        if (telekill && enemyPlayer && myPlayer) {
            void *myTransform = get_transform(myPlayer);
            void *enemyTransform = get_transform(enemyPlayer);
            if (myTransform && enemyTransform &&
                get_position(enemyTransform) != Vector3(0, 0, 0)) {
                set_position(myTransform, get_position(enemyTransform) + Vector3(0, 0, 1));
            }
        }

        if (enemyscale && enemyPlayer) {
            void *enemyTransform = get_transform(enemyPlayer);
            if (enemyTransform && get_position(enemyTransform) != Vector3(0, 0, 0))
                set_localScale(enemyTransform, Vector3(scalex, scaley, scalez));
        } else if (enemyPlayer) {
            void *enemyTransform = get_transform(enemyPlayer);
            if (enemyTransform && get_position(enemyTransform) != Vector3(0, 0, 0))
                set_localScale(enemyTransform, Vector3(1, 1, 1));
        }
    }

    void* camera = get_camera();
    if (skyEnable && camera) {
        set_clearFlags(camera, 2);
        ImColor colorToUse = skyRainbow ? ImColor(Rainbow::GetColor()) : ImColor(skyColor.x, skyColor.y, skyColor.z, skyColor.w);
        set_backgroundColor(camera, colorToUse);
    }

    if (isValidPlayer(player) && !playerFind(player) && isValidPhoton(get_photon(player))) {
        players.push_back(player);
        clearPlayers();
    }

    if (old_PlayerControllerUpdate) old_PlayerControllerUpdate(player);
}

void* (*old_CastBullet)(Vector3 startPosition, Vector3 direction, void* parameters);
void* CastBullet(Vector3 startPosition, Vector3 direction, void* parameters) {
    if (!slaim || !parameters) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    if (!isValidPlayer(myPlayer) || !isValidPhoton(get_photon(myPlayer))) {
        aimedplayer = nullptr;
        return old_CastBullet(startPosition, direction, parameters);
    }

    if (!isValidPlayer(aimedplayer) ||  !isValidPhoton(get_photon(myPlayer))) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    if (GetPlayerTeam(aimedplayer) == GetPlayerTeam(myPlayer)) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    void* camera = get_camera();
    if (!camera || (uintptr_t)camera < 0x10000) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    void* cameraTransform = get_transform(camera);
    if (!cameraTransform || (uintptr_t)cameraTransform < 0x10000) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    void* bipedmap = GetBones(aimedplayer);
    if (!bipedmap || (uintptr_t)bipedmap < 0x10000) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    void* aimedPlayerHead = *(void**)((uint64_t)bipedmap + 0x18);
    if (!aimedPlayerHead || (uintptr_t)aimedPlayerHead < 0x10000) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    Vector3 headPosition = get_position(aimedPlayerHead);
    if (headPosition == Vector3(0, 0, 0)) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    Vector3 target = headPosition - get_position(cameraTransform);
    if (target == Vector3(0, 0, 0)) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    float aimAngle = Vector3::Angle(target, get_forward(cameraTransform) * 100);
    if (aimAngle > silentfovsize / 700.0f) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    direction = Vector3::Normalized(headPosition - startPosition);
    return old_CastBullet(startPosition, direction, parameters);
}

void DrawCircle(Vector3 position, float radius, ImU32 color) {
    ImVec2 pos2D(position.x, position.z);
    auto draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;
    draw->AddCircle(pos2D, radius, color);
}

void* (*old_PlayerControllerLateUpdate)(void *instance);
void PlayerControllerLateUpdate(void* instance) {
    if (instance) {
        if (ThirdPerson) {
            void* camera = get_camera();
            if (camera) {
                void* transform = get_transform(camera);
                if (transform) {
                    Vector3 pos = get_position(transform);
                    Vector3 forward = get_forward(transform);
                    set_position(transform, pos - forward * thirdfloat);
                }
            }
        }
    }
    if (old_PlayerControllerLateUpdate) old_PlayerControllerLateUpdate(instance);
}

#define constructField(a,b,c) (*(a*) ((uint64_t) b + c))
void setSafeShort(void* a,bool b) {
    constructField(bool, a, 0xC) = (bool)b + constructField(bool, a, 0x8);
}
void setSafeFloat(void* a,bool b) {
    constructField(bool, a, 0xC) = b + constructField(bool, a, 0x8);
}

void* (*old_GrenadeControllerUpdate)(void *a);
void GrenadeControllerUpdate(void* a) {
    if (a && infgrenade) {
        void* fakePtr = reinterpret_cast<void*>(0x8000000dd);
        void* obj = *(void**)((uintptr_t)a + 0x11C);
        if (obj) {
            // *(bool*)((uintptr_t)obj + 0x9) = false;
            *(void**)((uintptr_t)obj + 0x11C) = fakePtr;
        }
    }
    if (old_GrenadeControllerUpdate) old_GrenadeControllerUpdate(a);
}

void* (*old_GameFinished)(void *instance);
void GameFinished(void* instance) {
    if (instance) {
        LOGI("GameFinished called. Instance: %p", instance);
        matchisfinish = true;
    }
    if (old_GameFinished) old_GameFinished(instance);
}

void* (*old_InitG)(void *instance, void* playerAttr, void* exitHandler, bool IsRankedMatch, bool isRejoining, bool isEventGameModeSession);
void InitG(void* instance, void* playerAttr, void* exitHandler, bool IsRankedMatch, bool isRejoining, bool isEventGameModeSession ) {
    if (instance) {
        LOGI("InitG called. Instance: %p", instance);
        matchisfinish = false;
    }
    if (old_InitG) old_InitG(instance, playerAttr, exitHandler, IsRankedMatch, isRejoining, isEventGameModeSession);
}

bool (*old_Grounded)(void *instance);
bool Grounded(void *instance) {
    if (!instance) {
        return old_Grounded ? old_Grounded(instance) : false;
    }

    if (airJump) {
        return true;
    }
    return old_Grounded ? old_Grounded(instance) : false;
}

bool (*old_InfGrenades)(void *instance);
bool InfGrenades(void *instance) {
    if (!instance) {
        return old_InfGrenades ? old_InfGrenades(instance) : false;
    }

    if (infgrenade) {
        return true;
    }
    return old_InfGrenades ? old_InfGrenades(instance) : false;
}

short (*old_MagazineCapacity)(void *instance);
short MagazineCapacity(void *instance) {
    if (!instance) {
        return old_MagazineCapacity ? old_MagazineCapacity(instance) : 0;
    }

    if (infammo) {
        return 10;
    }
    return old_MagazineCapacity ? old_MagazineCapacity(instance) : 0;
}

bool (*old_RespawnHack)(void *instance);
bool RespawnHack(void *instance) {
    if (!instance) {
        return old_RespawnHack ? old_RespawnHack(instance) : false;
    }

    if (respawnhack) {
        return true;
    }
    return old_RespawnHack ? old_RespawnHack(instance) : false;
}

void (*old_AttrCtor)(void* instance, Il2CppString* URLFQFOFPGK, Il2CppString* UJQQMPUIRPJ, void* JILNMHSSSRT, void* HHMKIITQSNL, bool HGNSHFIPUFH, bool FQFSUGTMFFL, bool GMMTRSFKSOM);
void AttrCtor(void* instance, Il2CppString* URLFQFOFPGK, Il2CppString* UJQQMPUIRPJ, void* JILNMHSSSRT, void* HHMKIITQSNL, bool HGNSHFIPUFH, bool FQFSUGTMFFL, bool GMMTRSFKSOM) {
    if (!instance) {
        if (old_AttrCtor) old_AttrCtor(instance, URLFQFOFPGK, UJQQMPUIRPJ, JILNMHSSSRT, HHMKIITQSNL, HGNSHFIPUFH, FQFSUGTMFFL, GMMTRSFKSOM);
        return;
    }

    if (hideid) {
        Il2CppString* customStr = nullptr;
        try {
            customStr = Il2CppString::CreateMonoString("t.me/MamixCheats");
        } catch (...) {
            LOGI("V1");
        }

        if (customStr) {
            UJQQMPUIRPJ = customStr;
            Il2CppString** strPtr = (Il2CppString**)((uintptr_t)instance + 0x18);
            if (strPtr) {
                *strPtr = customStr;
            }

            if (spoofid) {
                Il2CppString* devStr = nullptr;
                try {
                    devStr = Il2CppString::CreateMonoString("Dev");
                } catch (...) {
                    LOGI("V2");
                }

                if (devStr) {
                    URLFQFOFPGK = devStr;
                    Il2CppString** devStrPtr = (Il2CppString**)((uintptr_t)instance + 0x10);
                    if (devStrPtr) {
                        *devStrPtr = devStr;
                    }
                }
            }
        }
    }

    if (old_AttrCtor) old_AttrCtor(instance, URLFQFOFPGK, UJQQMPUIRPJ, JILNMHSSSRT, HHMKIITQSNL, HGNSHFIPUFH, FQFSUGTMFFL, GMMTRSFKSOM);
}

void (*old_FovHack1)(void *instance, float fov);
void FovHack1(void *instance, float fov) {
    if (!instance) {
        if (old_FovHack1) old_FovHack1(instance, fov);
        return;
    }

    if (fovFeature) {
        fov = fovValue;
    }
    if (old_FovHack1) old_FovHack1(instance, fov);
}

float (*old_FovHack2)(void *instance);
float FovHack2(void *instance) {
    if (!instance) {
        return old_FovHack2 ? old_FovHack2(instance) : 0.0f;
    }

    if (fovFeature) {
        return fovValue;
    }
    return old_FovHack2 ? old_FovHack2(instance) : 0.0f;
}



