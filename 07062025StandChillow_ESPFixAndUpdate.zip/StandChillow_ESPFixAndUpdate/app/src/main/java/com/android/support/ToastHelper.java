// File: com/android/support/ToastHelper.java
package com.android.support;

import android.app.Activity;
import android.widget.Toast;

public class ToastHelper {
    public static void show(final Activity activity, final String text, final int length) {
        activity.runOnUiThread(() -> Toast.makeText(activity, text, length).show());
    }
}
