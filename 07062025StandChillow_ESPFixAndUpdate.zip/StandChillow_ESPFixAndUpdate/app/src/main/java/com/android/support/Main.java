package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Main {
    public static String ver = "1.6.1";
    public static String paster = "Фууу лмчер + пастер + гий";

    public static void start(Context context) {
        System.loadLibrary("Mamix");
        if (context instanceof MainActivity) {
            MainActivity activity = (MainActivity) context;
            activity.initClipboardAccess(context);
        } else {
            Toast.makeText(context, "Invalid context", Toast.LENGTH_SHORT).show();
        }
    }

}
